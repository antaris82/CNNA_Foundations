# Results: parent-fan J-field gluing and holonomy

This diagnostic follows the local parent-fan plaquette skew-sector J-candidate.
It does **not** derive a global complex structure.  It tests whether the local
face-level candidates glue coherently across the parent-fan face net.

## Current run

```text
CNNA PARENT-FAN J-FIELD GLUING AND HOLONOMY DIAGNOSTIC
max_level=6, mode=linear, min_omega=1e-10

MODEL SUMMARIES
  real_growth: nodes=1093, completed=364, parent_nets=121, sibling_pseudo=30, random=30
  symmetrized_birth: nodes=1093, completed=364, parent_nets=121, sibling_pseudo=30, random=30
  no_backreaction: nodes=1093, completed=364, parent_nets=121, sibling_pseudo=30, random=30

SELECTED FULL-DTN GLUING SUMMARIES
  no_backreaction | parent_fan_net | aging | full: count=121, valid=0.000, K=0, J2=nan, plane=nan, J±=nan, Jfixed=nan, axis_abs=nan, Jcomm=nan, hol=nan, hol±=nan
  no_backreaction | parent_fan_net | handoff | full: count=121, valid=0.000, K=9.17998e-20, J2=nan, plane=nan, J±=nan, Jfixed=nan, axis_abs=nan, Jcomm=nan, hol=nan, hol±=nan
  no_backreaction | parent_fan_net | live | full: count=121, valid=1.000, K=0.0036013, J2=4.05e-09, plane=0.00263, J±=0.00266, Jfixed=0.668, axis_abs=0.999, Jcomm=0.00744, hol=2.3, hol±=8.91e-07
  no_backreaction | random_same_level_net | aging | full: count=30, valid=0.000, K=0, J2=nan, plane=nan, J±=nan, Jfixed=nan, axis_abs=nan, Jcomm=nan, hol=nan, hol±=nan
  no_backreaction | random_same_level_net | handoff | full: count=30, valid=0.000, K=1.32479e-20, J2=nan, plane=nan, J±=nan, Jfixed=nan, axis_abs=nan, Jcomm=nan, hol=nan, hol±=nan
  no_backreaction | random_same_level_net | live | full: count=30, valid=1.000, K=7.4455e-06, J2=6.54e-06, plane=0.00912, J±=0.00912, Jfixed=0.515, axis_abs=1.000, Jcomm=0.0258, hol=0.00366, hol±=0
  no_backreaction | sibling_pseudo_net | aging | full: count=30, valid=0.000, K=0, J2=nan, plane=nan, J±=nan, Jfixed=nan, axis_abs=nan, Jcomm=nan, hol=nan, hol±=nan
  no_backreaction | sibling_pseudo_net | handoff | full: count=30, valid=0.000, K=4.57025e-21, J2=nan, plane=nan, J±=nan, Jfixed=nan, axis_abs=nan, Jcomm=nan, hol=nan, hol±=nan
  no_backreaction | sibling_pseudo_net | live | full: count=30, valid=1.000, K=4.208e-06, J2=6.74e-07, plane=0.0118, J±=0.0118, Jfixed=0.0118, axis_abs=1.000, Jcomm=0.0334, hol=5.48e-06, hol±=5.48e-06
  real_growth | parent_fan_net | aging | full: count=121, valid=1.000, K=0.000110915, J2=4.14e-08, plane=0.00118, J±=0.00118, Jfixed=0.667, axis_abs=1.000, Jcomm=0.00334, hol=0.144, hol±=0
  real_growth | parent_fan_net | handoff | full: count=121, valid=1.000, K=0.000114368, J2=4.14e-08, plane=0.00221, J±=0.00221, Jfixed=0.668, axis_abs=1.000, Jcomm=0.00626, hol=0.0708, hol±=0
  real_growth | parent_fan_net | live | full: count=121, valid=1.000, K=0.00185628, J2=8.03e-09, plane=0.0018, J±=0.0018, Jfixed=0.668, axis_abs=1.000, Jcomm=0.0051, hol=1.15, hol±=6.41e-07
  real_growth | random_same_level_net | aging | full: count=30, valid=0.978, K=2.82345e-06, J2=0.000672, plane=0.00877, J±=0.00889, Jfixed=0.57, axis_abs=0.999, Jcomm=0.0248, hol=0.596, hol±=5.51e-06
  real_growth | random_same_level_net | handoff | full: count=30, valid=1.000, K=2.84906e-06, J2=4.96e-05, plane=0.0114, J±=0.0114, Jfixed=0.604, axis_abs=0.999, Jcomm=0.0323, hol=1.02, hol±=0.000101
  real_growth | random_same_level_net | live | full: count=30, valid=1.000, K=2.43846e-05, J2=3.67e-07, plane=0.0502, J±=0.055, Jfixed=0.595, axis_abs=0.969, Jcomm=0.142, hol=0.0596, hol±=3.65e-05
  real_growth | sibling_pseudo_net | aging | full: count=30, valid=1.000, K=3.51521e-07, J2=0.000975, plane=0.00606, J±=0.0061, Jfixed=0.0249, axis_abs=0.999, Jcomm=0.0171, hol=2.71e-05, hol±=6.48e-07
  real_growth | sibling_pseudo_net | handoff | full: count=30, valid=1.000, K=3.57336e-07, J2=0.000472, plane=0.016, J±=0.0171, Jfixed=0.0171, axis_abs=0.990, Jcomm=0.0451, hol=0.000195, hol±=0.000195
  real_growth | sibling_pseudo_net | live | full: count=30, valid=1.000, K=2.85503e-06, J2=1.02e-06, plane=0.0135, J±=0.0136, Jfixed=0.0136, axis_abs=0.998, Jcomm=0.0382, hol=4.47e-06, hol±=4.47e-06
  symmetrized_birth | parent_fan_net | aging | full: count=121, valid=1.000, K=4.00871e-06, J2=4.94e-06, plane=3.31e-06, J±=3.48e-06, Jfixed=0.667, axis_abs=1.000, Jcomm=9.36e-06, hol=0.675, hol±=0
  symmetrized_birth | parent_fan_net | handoff | full: count=121, valid=1.000, K=4.03911e-06, J2=4.85e-06, plane=3.36e-06, J±=3.53e-06, Jfixed=0.667, axis_abs=1.000, Jcomm=9.5e-06, hol=0.651, hol±=0
  symmetrized_birth | parent_fan_net | live | full: count=121, valid=1.000, K=7.06818e-06, J2=1.79e-06, plane=5.25e-06, J±=5.26e-06, Jfixed=0.667, axis_abs=1.000, Jcomm=1.48e-05, hol=0.579, hol±=0
  symmetrized_birth | random_same_level_net | aging | full: count=30, valid=0.778, K=6.35649e-09, J2=0.00149, plane=1.55e-05, J±=0.00035, Jfixed=0.625, axis_abs=1.000, Jcomm=4.36e-05, hol=0.467, hol±=0
  symmetrized_birth | random_same_level_net | handoff | full: count=30, valid=0.844, K=6.48583e-09, J2=0.00256, plane=1.55e-05, J±=0.0005, Jfixed=0.603, axis_abs=1.000, Jcomm=4.37e-05, hol=0.497, hol±=0
  symmetrized_birth | random_same_level_net | live | full: count=30, valid=0.978, K=4.65659e-08, J2=0.00046, plane=7.61e-05, J±=0.000222, Jfixed=0.6, axis_abs=1.000, Jcomm=0.000214, hol=0.541, hol±=0
  symmetrized_birth | sibling_pseudo_net | aging | full: count=30, valid=0.000, K=4.42856e-11, J2=nan, plane=nan, J±=nan, Jfixed=nan, axis_abs=1.000, Jcomm=nan, hol=3.86e-05, hol±=0
  symmetrized_birth | sibling_pseudo_net | handoff | full: count=30, valid=0.000, K=4.57309e-11, J2=nan, plane=nan, J±=nan, Jfixed=nan, axis_abs=1.000, Jcomm=nan, hol=3.93e-05, hol±=0
  symmetrized_birth | sibling_pseudo_net | live | full: count=30, valid=0.989, K=2.34463e-10, J2=0.012, plane=8.21e-06, J±=4.68e-05, Jfixed=4.68e-05, axis_abs=1.000, Jcomm=2.3e-05, hol=0, hol±=0

REAL-GROWTH LIVE ABLATIONS
  real_growth | parent_fan_net | live | common_mean_diagonal: count=121, valid=0.000, K=7.09332e-17, J2=nan, plane=nan, J±=nan, Jfixed=nan, axis_abs=nan, Jcomm=nan, hol=nan, hol±=nan
  real_growth | parent_fan_net | live | diagonal: count=121, valid=0.000, K=0, J2=nan, plane=nan, J±=nan, Jfixed=nan, axis_abs=nan, Jcomm=nan, hol=nan, hol±=nan
  real_growth | parent_fan_net | live | full: count=121, valid=1.000, K=0.00185628, J2=8.03e-09, plane=0.0018, J±=0.0018, Jfixed=0.668, axis_abs=1.000, Jcomm=0.0051, hol=1.15, hol±=6.41e-07
  real_growth | parent_fan_net | live | trace_scalar: count=121, valid=0.000, K=0, J2=nan, plane=nan, J±=nan, Jfixed=nan, axis_abs=nan, Jcomm=nan, hol=nan, hol±=nan

READING RULE
  Local J validity was already checked per face in the previous test.
  This test asks if same-parent face triples glue: small plane residuals,
  small signless J residuals, high absolute axis cosine, and small J-commutators.
  Holonomy here uses the minimal SO(3) connection between extracted axes;
  small holonomy means coherent/flat local J-field gluing, not absence of face-level K.
```

## Output files

- `J_field_face_rows.csv`
- `J_field_net_rows.csv`
- `J_field_summary_main.csv`
- `J_field_summary_by_level.csv`
- `model_summaries.csv`
- `SUMMARY.txt`

## Interpretation guide

A coherent local J-field carrier should show, for
`real_growth / parent_fan_net / live / full`:

```text
valid faces near 1
per-face J2 residual near 0
small plane residual across F12,F23,F31
small signless J residual across F12,F23,F31
high absolute axis cosine
small J-pair commutator
collapse or invalidation under diagonal/trace/common-commuting reductions
```

A small minimal-axis holonomy means the local J-field glues flatly across the
three parent-fan faces.  It does not erase the nonzero face-level commutator K;
it says the extracted J-planes themselves are mutually coherent.
