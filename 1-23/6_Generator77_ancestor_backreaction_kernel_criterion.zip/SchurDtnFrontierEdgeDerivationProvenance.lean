import CNNA.SchurDtnFrontierEdgeTableProvenance

namespace SchurDtnFrontierEdgeDerivationProvenance

abbrev Node := Fin 3
abbrev DirectedEdge := SchurDtnFrontierEdgeTableProvenance.DirectedEdge
abbrev CutGraphEdgeTableRecord :=
  SchurDtnFrontierEdgeTableProvenance.CutGraphEdgeTableRecord
abbrev CutGraphExtensionRecord :=
  SchurDtnFrontierEventActivationProvenance.CutGraphExtensionRecord
abbrev CutFrontierExtensionData :=
  SchurDtnGraphFrontierExtensionProvenance.CutFrontierExtensionData
abbrev CutGraphUniverseData :=
  SchurDtnCutGraphUniverseProvenance.CutGraphUniverseData
abbrev BoundaryResidualSupportData :=
  SchurDtnBoundaryResidualSupportProvenance.BoundaryResidualSupportData
abbrev DefectSystem := SectorResolutionGate.DefectSystem

structure CutGraphEdgeDerivationRecord where
  boundaryRoleNodes : List Node
  interiorRoleNodes : List Node
  uvBoundaryRoleNodes : List Node
  envBoundaryRoleNodes : List Node
  recordRoleNodes : List Node
  boundaryPort : Node
  sourcePort : Node
  targetNode : Node
  candidateEdgeTargets : List Node
  graphAdjacent : Node -> Node -> Bool
  interiorPort : Node
  interiorLoadNode : Node
  frontierAdjacent : Node -> Node -> Bool
  loadAdjacent : Node -> Node -> Bool
  adjacent : Node -> Node -> Bool


def derivedEdgesFromTargets
    (source : Node) (graphAdjacent : Node -> Node -> Bool) :
    List Node -> List DirectedEdge
  | [] => []
  | x :: xs =>
      if graphAdjacent source x then
        { source := source, target := x } ::
          derivedEdgesFromTargets source graphAdjacent xs
      else
        derivedEdgesFromTargets source graphAdjacent xs


def edgeTable (p : CutGraphEdgeDerivationRecord) : List DirectedEdge :=
  derivedEdgesFromTargets p.sourcePort p.graphAdjacent p.candidateEdgeTargets


def toEdgeTableRecord (p : CutGraphEdgeDerivationRecord) :
    CutGraphEdgeTableRecord :=
  { boundaryRoleNodes := p.boundaryRoleNodes,
    interiorRoleNodes := p.interiorRoleNodes,
    uvBoundaryRoleNodes := p.uvBoundaryRoleNodes,
    envBoundaryRoleNodes := p.envBoundaryRoleNodes,
    recordRoleNodes := p.recordRoleNodes,
    boundaryPort := p.boundaryPort,
    sourcePort := p.sourcePort,
    targetNode := p.targetNode,
    edgeTable := edgeTable p,
    interiorPort := p.interiorPort,
    interiorLoadNode := p.interiorLoadNode,
    frontierAdjacent := p.frontierAdjacent,
    loadAdjacent := p.loadAdjacent,
    adjacent := p.adjacent }


theorem toEdgeTableRecord_edgeTable
    (p : CutGraphEdgeDerivationRecord) :
    (toEdgeTableRecord p).edgeTable = edgeTable p := rfl


def eqAdj : Node -> Node -> Bool :=
  SchurDtnFrontierEdgeTableProvenance.eqAdj


def edge22 : DirectedEdge :=
  SchurDtnFrontierEdgeTableProvenance.edge22


def noDerivedEdgeRecordNode2 : CutGraphEdgeDerivationRecord :=
  { boundaryRoleNodes := [0],
    interiorRoleNodes := [1],
    uvBoundaryRoleNodes := [1],
    envBoundaryRoleNodes := [0],
    recordRoleNodes := [],
    boundaryPort := 2,
    sourcePort := 2,
    targetNode := 2,
    candidateEdgeTargets := [],
    graphAdjacent := eqAdj,
    interiorPort := 1,
    interiorLoadNode := 1,
    frontierAdjacent := eqAdj,
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


def wrongDerivedEdgeTargetRecordNode2 : CutGraphEdgeDerivationRecord :=
  { boundaryRoleNodes := [0],
    interiorRoleNodes := [1],
    uvBoundaryRoleNodes := [1],
    envBoundaryRoleNodes := [0],
    recordRoleNodes := [],
    boundaryPort := 2,
    sourcePort := 2,
    targetNode := 2,
    candidateEdgeTargets := [1],
    graphAdjacent := eqAdj,
    interiorPort := 1,
    interiorLoadNode := 1,
    frontierAdjacent := eqAdj,
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


def residualDerivedEdgeRecordNode2 : CutGraphEdgeDerivationRecord :=
  { boundaryRoleNodes := [0],
    interiorRoleNodes := [1],
    uvBoundaryRoleNodes := [1],
    envBoundaryRoleNodes := [0],
    recordRoleNodes := [],
    boundaryPort := 2,
    sourcePort := 2,
    targetNode := 2,
    candidateEdgeTargets := [2],
    graphAdjacent := eqAdj,
    interiorPort := 1,
    interiorLoadNode := 1,
    frontierAdjacent := eqAdj,
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


theorem no_derived_edge_table_node2 :
    edgeTable noDerivedEdgeRecordNode2 = [] := rfl


theorem wrong_target_derived_edge_table_node2 :
    edgeTable wrongDerivedEdgeTargetRecordNode2 = [] := rfl


theorem residual_derived_edge_table_node2 :
    edgeTable residualDerivedEdgeRecordNode2 = [edge22] := rfl


theorem no_derived_edge_record_eq_previous_node2 :
    toEdgeTableRecord noDerivedEdgeRecordNode2 =
      SchurDtnFrontierEdgeTableProvenance.inactiveEdgeTableRecordNode2 := rfl


theorem residual_derived_edge_record_eq_previous_node2 :
    toEdgeTableRecord residualDerivedEdgeRecordNode2 =
      SchurDtnFrontierEdgeTableProvenance.residualEdgeTableRecordNode2 := rfl


theorem no_derived_edge_not_present_node2 :
    SchurDtnFrontierEdgeTableProvenance.edgePresent
      (toEdgeTableRecord noDerivedEdgeRecordNode2) = false := rfl


theorem wrong_target_derived_edge_not_present_node2 :
    SchurDtnFrontierEdgeTableProvenance.edgePresent
      (toEdgeTableRecord wrongDerivedEdgeTargetRecordNode2) = false := rfl


theorem residual_derived_edge_present_node2 :
    SchurDtnFrontierEdgeTableProvenance.edgePresent
      (toEdgeTableRecord residualDerivedEdgeRecordNode2) = true := rfl


def noDerivedCutFrontierExtensionNode2 : CutFrontierExtensionData :=
  SchurDtnFrontierEventActivationProvenance.toCutFrontierExtensionData
    (SchurDtnFrontierEdgeTableProvenance.toCutGraphExtensionRecord
      (toEdgeTableRecord noDerivedEdgeRecordNode2))


def residualDerivedCutFrontierExtensionNode2 : CutFrontierExtensionData :=
  SchurDtnFrontierEventActivationProvenance.toCutFrontierExtensionData
    (SchurDtnFrontierEdgeTableProvenance.toCutGraphExtensionRecord
      (toEdgeTableRecord residualDerivedEdgeRecordNode2))


theorem no_derived_edge_frontier_candidates_node2 :
    SchurDtnGraphFrontierExtensionProvenance.frontierCandidateNodes
      noDerivedCutFrontierExtensionNode2 = [] := rfl


theorem residual_derived_edge_frontier_candidates_node2 :
    SchurDtnGraphFrontierExtensionProvenance.frontierCandidateNodes
      residualDerivedCutFrontierExtensionNode2 = [2] := rfl


def residualDerivedCutGraphUniverseNode2 : CutGraphUniverseData :=
  SchurDtnGraphFrontierExtensionProvenance.toCutGraphUniverseData
    residualDerivedCutFrontierExtensionNode2


theorem residual_derived_edge_universe_nodes_node2 :
    SchurDtnCutGraphUniverseProvenance.universeNodes
      residualDerivedCutGraphUniverseNode2 = [0, 1, 2] := rfl


def residualDerivedBoundarySupportNode2 : BoundaryResidualSupportData :=
  SchurDtnCutGraphUniverseProvenance.toBoundaryResidualSupportData
    residualDerivedCutGraphUniverseNode2


theorem residual_derived_edge_support_nodes_node2 :
    SchurDtnBoundaryResidualSupportProvenance.residualSupportNodes
      residualDerivedBoundarySupportNode2 = [2] := rfl


theorem residual_derived_edge_candidate_load_nodes_node2 :
    SchurDtnCutCandidateLoadProvenance.candidateLoadNodes
      (SchurDtnBoundaryResidualSupportProvenance.toCutCandidateLoadSupportData
        residualDerivedBoundarySupportNode2) = [1, 2] := rfl


def cutFrontierDerivedEdgeDefectSystem : DefectSystem Bool :=
  SchurDtnFrontierEdgeTableProvenance.cutFrontierEdgeTableDefectSystem


theorem cut_frontier_derived_edge_closure_status :
    cutFrontierDerivedEdgeDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      cutFrontierDerivedEdgeDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        cutFrontierDerivedEdgeDefectSystem) :=
  SchurDtnFrontierEdgeTableProvenance.cut_frontier_edge_table_closure_status


def symmetricDefectSystem : DefectSystem Bool :=
  SchurDtnFrontierEdgeTableProvenance.symmetricDefectSystem


theorem symmetric_frontier_derived_edge_status :
    symmetricDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem :=
  SchurDtnFrontierEdgeTableProvenance.symmetric_frontier_edge_table_status


def candidateEdgeTargetsStillNeedGraphBoundaryDerivation : Prop := True


theorem candidate_edge_targets_still_need_graph_boundary_derivation :
    candidateEdgeTargetsStillNeedGraphBoundaryDerivation :=
  True.intro

end SchurDtnFrontierEdgeDerivationProvenance
