import CNNA.FiniteHandoffSummary

/-
  FiniteCutCombinatorics.lean
  ---------------------------
  Endliche Cut-Kombinatorik -> CutSummary.

  Dieser Baustein ist der erste gekoppelte Adapter nach FiniteHandoffSummary.
  Er importiert die vorherige Summary-Schicht und liefert keine freie Wahl:
  alle Felder der CutSummary werden aus endlichen Listen und einer Bool-Inzidenz
  gezählt.

  Noch kein echtes Matrix-Schurkomplement. Der Zweck ist der kanonische
  kombinatorische Pfad:

    FiniteCut -> CutSummary -> HandoffData -> DefectVector.
-/

namespace FiniteCutCombinatorics

/-! ## 0. Endliche Zaehler -/

def countP {A : Type} (p : A -> Bool) : List A -> Nat
  | [] => 0
  | a :: as => (if p a then 1 else 0) + countP p as

theorem countP_nil {A : Type} (p : A -> Bool) :
    countP p [] = 0 := rfl

theorem countP_cons {A : Type} (p : A -> Bool) (a : A) (as : List A) :
    countP p (a :: as) = (if p a then 1 else 0) + countP p as := rfl

def pairCount {V : Type} (R : V -> V -> Bool) : List V -> List V -> Nat
  | [], _ => 0
  | x :: xs, ys => countP (fun y => R x y) ys + pairCount R xs ys

theorem pairCount_nil_left {V : Type} (R : V -> V -> Bool) (ys : List V) :
    pairCount R [] ys = 0 := rfl

theorem pairCount_cons_left {V : Type} (R : V -> V -> Bool)
    (x : V) (xs ys : List V) :
    pairCount R (x :: xs) ys =
      countP (fun y => R x y) ys + pairCount R xs ys := rfl

/-! ## 1. Endlicher Cut -/

structure FiniteCut (V : Type) where
  boundary : List V
  interior : List V
  uvBoundary : List V
  envBoundary : List V
  recordNodes : List V
  complementNodes : List V
  adjacent : V -> V -> Bool

/-- Rein kombinatorische Boundary-Interior-Inzidenz. -/
def boundaryInteriorIncidence {V : Type} (c : FiniteCut V) : Nat :=
  pairCount c.adjacent c.boundary c.interior

/-- Rein kombinatorische Boundary-Complement-Inzidenz. -/
def boundaryComplementIncidence {V : Type} (c : FiniteCut V) : Nat :=
  pairCount c.adjacent c.boundary c.complementNodes

/-- Rein kombinatorische Record-Boundary-Inzidenz. -/
def recordBoundaryIncidence {V : Type} (c : FiniteCut V) : Nat :=
  pairCount c.adjacent c.recordNodes c.boundary

/-- Summary-Spurplatzhalter: Boundary-Groesse plus Boundary-Interior-Inzidenz.
    Dies ist noch nicht der echte Schur-DtN-Trace, sondern der kanonische
    endliche Kombinatorik-Adapter fuer die naechste Schicht. -/
def dtnTraceProxy {V : Type} (c : FiniteCut V) : Nat :=
  c.boundary.length + boundaryInteriorIncidence c

def recordSignature {V : Type} (c : FiniteCut V) : Nat :=
  c.recordNodes.length + recordBoundaryIncidence c

def complementSignature {V : Type} (c : FiniteCut V) : Nat :=
  c.complementNodes.length + boundaryComplementIncidence c

/-- Minimaler Cut-Defekt auf Kombinatorikebene: kein Innenraum bedeutet, dass
    kein echter Interior-Schurblock vorhanden ist. -/
def cutKernelDefect {V : Type} (c : FiniteCut V) : Nat :=
  if c.interior.length = 0 then 1 else 0

/-! ## 2. Adapter zur gruenen Summary-Schicht -/

def toCutSummary {V : Type} (c : FiniteCut V) :
    FiniteHandoffSummary.CutSummary :=
  { boundarySize := c.boundary.length,
    interiorSize := c.interior.length,
    dtnTrace := dtnTraceProxy c,
    uvBoundaryLoad := c.uvBoundary.length,
    envBoundaryLoad := c.envBoundary.length,
    cutKernelDefect := cutKernelDefect c,
    recordSignature := recordSignature c,
    complementSignature := complementSignature c }

def toHandoffData {V : Type} (before after : FiniteCut V) :
    FiniteHandoffSummary.HandoffData :=
  FiniteHandoffSummary.toHandoffData (toCutSummary before) (toCutSummary after)

def toDefectVector {V : Type} (before after : FiniteCut V) : List Nat :=
  FiniteHandoffSummary.toDefectVector (toCutSummary before) (toCutSummary after)

theorem toCutSummary_boundarySize {V : Type} (c : FiniteCut V) :
    (toCutSummary c).boundarySize = c.boundary.length := rfl

theorem toCutSummary_interiorSize {V : Type} (c : FiniteCut V) :
    (toCutSummary c).interiorSize = c.interior.length := rfl

theorem toCutSummary_dtnTrace {V : Type} (c : FiniteCut V) :
    (toCutSummary c).dtnTrace = dtnTraceProxy c := rfl

theorem toCutSummary_uvLoad {V : Type} (c : FiniteCut V) :
    (toCutSummary c).uvBoundaryLoad = c.uvBoundary.length := rfl

theorem toCutSummary_envLoad {V : Type} (c : FiniteCut V) :
    (toCutSummary c).envBoundaryLoad = c.envBoundary.length := rfl

theorem cutKernelDefect_one_of_empty {V : Type} (c : FiniteCut V)
    (h : c.interior.length = 0) :
    cutKernelDefect c = 1 := by
  unfold cutKernelDefect
  rw [if_pos h]

theorem cutKernelDefect_zero_of_nonempty {V : Type} (c : FiniteCut V)
    (h : c.interior.length ≠ 0) :
    cutKernelDefect c = 0 := by
  unfold cutKernelDefect
  rw [if_neg h]

theorem toDefectVector_link {V : Type} (before after : FiniteCut V) :
    toDefectVector before after =
      FiniteHandoffSummary.toDefectVector
        (toCutSummary before) (toCutSummary after) := rfl

theorem toDefectVector_unfold {V : Type} (before after : FiniteCut V) :
    toDefectVector before after =
      [cutKernelDefect after,
       FiniteHandoffSummary.absDiff (dtnTraceProxy before) (dtnTraceProxy after),
       FiniteHandoffSummary.absDiff (recordSignature before) (recordSignature after),
       FiniteHandoffSummary.absDiff after.uvBoundary.length after.envBoundary.length,
       FiniteHandoffSummary.absDiff
         (complementSignature before) (complementSignature after)] := by
  unfold toDefectVector
  exact FiniteHandoffSummary.toDefectVector_unfold
    (toCutSummary before) (toCutSummary after)

/-! ## 3. Stabilitaetsbruecken -/

def SameDtnProxy {V : Type} (before after : FiniteCut V) : Prop :=
  dtnTraceProxy before = dtnTraceProxy after

def SameRecordSignature {V : Type} (before after : FiniteCut V) : Prop :=
  recordSignature before = recordSignature after

def SameComplementSignature {V : Type} (before after : FiniteCut V) : Prop :=
  complementSignature before = complementSignature after

def LoadsBalanced {V : Type} (after : FiniteCut V) : Prop :=
  after.uvBoundary.length = after.envBoundary.length

theorem dtn_defect_zero_of_same_proxy {V : Type} (before after : FiniteCut V)
    (h : SameDtnProxy before after) :
    FiniteHandoffSummary.dtnDefect (toHandoffData before after) = 0 := by
  unfold SameDtnProxy at h
  exact FiniteHandoffSummary.dtnDefect_zero_of_stable
    (toCutSummary before) (toCutSummary after) h

theorem balance_defect_zero_of_loads_balanced {V : Type}
    (before after : FiniteCut V) (h : LoadsBalanced after) :
    FiniteHandoffSummary.balanceDefect (toHandoffData before after) = 0 := by
  unfold LoadsBalanced at h
  unfold toHandoffData toCutSummary
  exact FiniteHandoffSummary.balanceDefect_zero_of_balanced
    (toCutSummary before) (toCutSummary after) h

end FiniteCutCombinatorics
