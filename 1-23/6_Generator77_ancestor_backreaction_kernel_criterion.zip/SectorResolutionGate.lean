import CNNA.JSignClosureCriterion

/-
  SectorResolutionGate.lean
  -------------------------
  Allgemeines Bindeglied:

    Pareto-Minset / Sektorkernel -> Lock-Kandidatenliste -> J-Sign-Closure.

  Diese Datei ersetzt die bisherigen reinen Beispiel-Listen `plusSector` und
  `twoSectors` nicht, sondern zeigt, wie sie aus einem DefectSystem-Minset
  entstehen: eine kanonische Sektormenge wird ueber eine Lock-Abbildung in eine
  Liste kohärenter Lock-Kandidaten gepusht. Das Closure-Kriterium wird dann
  genau auf diese Liste angewendet.

  Kein freier Tie-Break: Falls das Minset zwei entgegengesetzte Lock-Sektoren
  traegt, bleibt das J-Sign nicht geschlossen.
-/

namespace SectorResolutionGate

abbrev DefectSystem := CanonicalGrowthKernel.DefectSystem
abbrev LockCandidate := JLockingGate.LockCandidate

/-- Lock-Kandidatenliste, die aus der kanonischen Pareto-Sektormenge entsteht. -/
def lockCandidates {A : Type} (D : DefectSystem A)
    (lockOf : A -> LockCandidate) : List LockCandidate :=
  D.minSet.map lockOf

/-- J-Sign-Closure eines Defektsystems nach Pushforward seiner Minset-Sektoren
    in Lock-Kandidaten. -/
def hasResolvedJSign {A : Type} (D : DefectSystem A)
    (lockOf : A -> LockCandidate) : Prop :=
  JSignClosureCriterion.hasClosedJSign (lockCandidates D lockOf)

/-- Wenn die gepushte Lock-Liste exakt eine bereits geschlossene Liste ist,
    transferiert Closure entlang dieser Gleichheit. -/
theorem resolved_of_lockCandidates_eq {A : Type} (D : DefectSystem A)
    (lockOf : A -> LockCandidate) (cs : List LockCandidate)
    (hlist : lockCandidates D lockOf = cs)
    (hclosed : JSignClosureCriterion.hasClosedJSign cs) :
    hasResolvedJSign D lockOf := by
  unfold hasResolvedJSign
  rw [hlist]
  exact hclosed

/-- Analog fuer den negativen Fall: Wenn die gepushte Lock-Liste einer nicht
    geschlossenen Sektorliste entspricht, ist das Defektsystem nicht resolved. -/
theorem not_resolved_of_lockCandidates_eq {A : Type} (D : DefectSystem A)
    (lockOf : A -> LockCandidate) (cs : List LockCandidate)
    (hlist : lockCandidates D lockOf = cs)
    (hnot : ¬ JSignClosureCriterion.hasClosedJSign cs) :
    ¬ hasResolvedJSign D lockOf := by
  intro h
  unfold hasResolvedJSign at h
  rw [hlist] at h
  exact hnot h

/-! ## Miniport-Instanzen aus dem aktuellen Generator-Spine -/

/-- Der eindeutige Miniport-Sektor wird auf den positiven Lock geschickt. -/
def oneInteriorLockOf (_ : OneInteriorGrowthKernelExample.Attachment) :
    LockCandidate :=
  JLockingGate.plusLock

/-- Die aus dem eindeutigen Miniport-Minset gepushte Lock-Liste ist genau der
    positive Einzelsektor. -/
theorem oneInterior_lockCandidates_eq_plusSector :
    lockCandidates OneInteriorGrowthKernelExample.oneInteriorDefectSystem
      oneInteriorLockOf = JSignClosureCriterion.plusSector := by
  unfold lockCandidates oneInteriorLockOf JSignClosureCriterion.plusSector
  rw [OneInteriorGrowthKernelExample.oneInterior_minSet_singleton]
  rfl

/-- Der eindeutige Miniport-Sektor ist resolved im Sinn des J-Sign-Closure-
    Kriteriums. -/
theorem oneInterior_resolved_j_sign :
    hasResolvedJSign OneInteriorGrowthKernelExample.oneInteriorDefectSystem
      oneInteriorLockOf :=
  resolved_of_lockCandidates_eq
    OneInteriorGrowthKernelExample.oneInteriorDefectSystem
    oneInteriorLockOf
    JSignClosureCriterion.plusSector
    oneInterior_lockCandidates_eq_plusSector
    JSignClosureCriterion.plusSector_has_closed_j_sign

/-- Im symmetrischen Bool-Sektorsystem wird `false` auf den positiven und `true`
    auf den negativen Lock geschickt. Die Bool-Werte sind hier nur die zwei
    Sektoretiketten, nicht ein Tie-Break. -/
def symmetricLockOf : Bool -> LockCandidate
  | false => JLockingGate.plusLock
  | true => JLockingGate.minusLock

/-- Die aus dem symmetrischen Minset gepushte Lock-Liste ist genau das
    Plus/Minus-Sektorpaar. -/
theorem symmetric_lockCandidates_eq_twoSectors :
    lockCandidates OneInteriorGrowthKernelExample.symmetricTwoDefectSystem
      symmetricLockOf = JSignClosureCriterion.twoSectors := by
  unfold lockCandidates symmetricLockOf JSignClosureCriterion.twoSectors
  rw [OneInteriorGrowthKernelExample.symmetricTwo_minSet]
  rfl

/-- Der symmetrische Zwei-Sektorenfall ist nicht resolved: das J-Sign bleibt
    wegen des kanonischen Plus/Minus-Paars offen. -/
theorem symmetric_not_resolved_j_sign :
    ¬ hasResolvedJSign OneInteriorGrowthKernelExample.symmetricTwoDefectSystem
      symmetricLockOf :=
  not_resolved_of_lockCandidates_eq
    OneInteriorGrowthKernelExample.symmetricTwoDefectSystem
    symmetricLockOf
    JSignClosureCriterion.twoSectors
    symmetric_lockCandidates_eq_twoSectors
    JSignClosureCriterion.twoSectors_no_closed_j_sign

/-- Direkter Spine-Satz: eindeutiger Kernel und resolved J-Sign fallen im
    Miniport zusammen. -/
theorem oneInterior_kernel_and_resolved_j_sign :
    OneInteriorGrowthKernelExample.oneInteriorDefectSystem.kernel = 1 ∧
    hasResolvedJSign OneInteriorGrowthKernelExample.oneInteriorDefectSystem
      oneInteriorLockOf :=
  And.intro OneInteriorGrowthKernelExample.oneInterior_kernel_one
    oneInterior_resolved_j_sign

/-- Direkter Spine-Satz: Sektorkernel der Masse 2 und nicht-resolved J-Sign
    fallen im symmetrischen Fall zusammen. -/
theorem symmetric_kernel_and_not_resolved_j_sign :
    OneInteriorGrowthKernelExample.symmetricTwoDefectSystem.kernel = 2 ∧
    ¬ hasResolvedJSign OneInteriorGrowthKernelExample.symmetricTwoDefectSystem
      symmetricLockOf :=
  And.intro OneInteriorGrowthKernelExample.symmetricTwo_kernel_two
    symmetric_not_resolved_j_sign

end SectorResolutionGate
