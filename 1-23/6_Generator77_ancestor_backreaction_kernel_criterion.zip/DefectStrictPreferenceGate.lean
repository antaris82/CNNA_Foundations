import CNNA.SymmetryBreakingClosureGate

/-
  DefectStrictPreferenceGate.lean
  --------------------------------
  Gate zwischen abstraktem symmetry-breaking datum und echter Defektordnung.

  Diese Datei setzt keinen Selector. Sie zeigt an einem minimalen Bool-Sektor:

    Wenn der parameterfreie Defekt eines Sektors strikt kleiner ist als der
    Defekt des gespiegelten Sektors, dann kollabiert das kanonische Pareto-Minset
    auf ein Singleton. Dadurch resolved der Growth->Lock-Pushforward das formale
    J-Sign-Kriterium.

  Das ist nicht die Ableitung der Defektasymmetrie aus Schur-DtN-Daten. Es ist
  das Closure-Gate, das sagt: Sobald die Schur-DtN-Komplementdaten einen echten
  Defektabstand liefern, ist kein freier Tie-Break mehr noetig.
-/

namespace DefectStrictPreferenceGate

abbrev DefectSystem := SectorResolutionGate.DefectSystem
abbrev CirculationSign := GrowthSectorResolutionBridge.CirculationSign

/-- Minimaler Zwei-Sektor-Test: `false` hat Defekt 0, `true` hat Defekt 1.
    Die Bool-Werte sind nur Sektoretiketten. -/
def strictBoolDefect : Bool -> List Nat
  | false => [0]
  | true => [1]

/-- Zwei Kandidaten, aber mit parameterfreiem strikt unterscheidendem Defekt. -/
def strictBoolDefectSystem : DefectSystem Bool :=
  { candidates := [false, true],
    defect := strictBoolDefect }

/-- Der strikt bessere Sektor ist das eindeutige Pareto-Minimum. -/
theorem strictBool_minSet_singleton :
    strictBoolDefectSystem.minSet = [false] := rfl

/-- Der kanonische Kernel hat daher Masse 1. -/
theorem strictBool_kernel_one :
    strictBoolDefectSystem.kernel = 1 :=
  CanonicalGrowthKernel.DefectSystem.unique_kernel_one
    strictBoolDefectSystem false strictBool_minSet_singleton

/-- Der bevorzugte Sektor hat Sektorgewicht 1. -/
theorem strictBool_sector_false_one :
    strictBoolDefectSystem.sector false = 1 :=
  CanonicalGrowthKernel.unique_min_sector_one
    strictBoolDefectSystem.defect strictBoolDefectSystem.candidates
    false strictBool_minSet_singleton

/-- Der gespiegelte, defekt-schlechtere Sektor hat Sektorgewicht 0. -/
theorem strictBool_sector_true_zero :
    strictBoolDefectSystem.sector true = 0 :=
  CanonicalGrowthKernel.unique_min_sector_zero
    strictBoolDefectSystem.defect strictBoolDefectSystem.candidates
    false true strictBool_minSet_singleton (by decide)

/-- Derselbe Growth->Sign->Lock-Adapter wie im symmetrischen Fall: false traegt
    Plus, true traegt Minus. Der Unterschied liegt nicht im Adapter, sondern
    allein im Defekt-Minset. -/
def strictBoolSectorMap : GrowthSectorResolutionBridge.GrowthSectorMap Bool :=
  { signOf := fun b =>
      match b with
      | false => GrowthSectorResolutionBridge.CirculationSign.plus
      | true => GrowthSectorResolutionBridge.CirculationSign.minus }

/-- Wegen des strikt besseren Defekts pusht das Minset nur auf den Plus-Lock. -/
theorem strictBool_locks_eq_plusSector :
    strictBoolSectorMap.lockCandidates strictBoolDefectSystem =
      JSignClosureCriterion.plusSector := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    strictBoolSectorMap
    GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.plusSector
  rw [strictBool_minSet_singleton]
  rfl

/-- Strikter Defektabstand resolved das formale J-Sign-Kriterium ohne
    Selector, ohne Gewicht und ohne Label-Tie-Break. -/
theorem strictBool_resolved_j_sign :
    strictBoolSectorMap.hasResolvedJSign strictBoolDefectSystem := by
  change JSignClosureCriterion.hasClosedJSign
    (strictBoolSectorMap.lockCandidates strictBoolDefectSystem)
  rw [strictBool_locks_eq_plusSector]
  exact JSignClosureCriterion.plusSector_has_closed_j_sign

/-- Die Defektasymmetrie ist genau ein symmetry-breaking datum im formalen Sinn:
    das kanonische Minset ist ein Singleton. -/
def strictBoolBreakingDatum :
    SymmetryBreakingClosureGate.SymmetryBreakingDatum strictBoolDefectSystem :=
  { selected := false,
    minSet_singleton := strictBool_minSet_singleton }

/-- Derselbe resolved-Status folgt auch ueber das allgemeine
    SymmetryBreakingClosureGate. -/
theorem strictBool_resolved_by_breaking_datum :
    strictBoolSectorMap.hasResolvedJSign strictBoolDefectSystem :=
  SymmetryBreakingClosureGate.growth_resolved_of_symmetry_breaking_datum
    strictBoolSectorMap strictBoolDefectSystem strictBoolBreakingDatum

/-- Der streng bevorzugte Pushforward ist nicht flip-geschlossen. -/
theorem strictBool_not_flip_closed :
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (strictBoolSectorMap.lockCandidates strictBoolDefectSystem) := by
  intro hclosed
  rw [strictBool_locks_eq_plusSector] at hclosed
  exact SymmetryBreakingClosureGate.plusSector_not_closed_under_flip hclosed

/-- Kompakter Status: strikte Defektasymmetrie fuehrt zum eindeutigen Kernel,
    zum resolved J-Sign-Kriterium und bricht die Flip-Abgeschlossenheit. -/
theorem strict_defect_preference_closure_status :
    strictBoolDefectSystem.kernel = 1 ∧
    strictBoolSectorMap.hasResolvedJSign strictBoolDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (strictBoolSectorMap.lockCandidates strictBoolDefectSystem) :=
  And.intro strictBool_kernel_one
    (And.intro strictBool_resolved_j_sign strictBool_not_flip_closed)

/-- Statusmarker: Offen bleibt, die konkrete Defektasymmetrie aus
    Schur-DtN-Komplementdaten abzuleiten. -/
def derivedStrictDefectGapStillOpen : Prop := True

theorem derived_strict_defect_gap_still_open :
    derivedStrictDefectGapStillOpen :=
  True.intro

end DefectStrictPreferenceGate
