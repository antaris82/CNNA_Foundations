import CNNA.SchurDtnFrontierEdgeDerivationProvenance

namespace SchurDtnFrontierTargetProvenance

abbrev Node := Fin 3
abbrev CutGraphEdgeDerivationRecord :=
  SchurDtnFrontierEdgeDerivationProvenance.CutGraphEdgeDerivationRecord
abbrev DirectedEdge := SchurDtnFrontierEdgeTableProvenance.DirectedEdge
abbrev CutFrontierExtensionData :=
  SchurDtnGraphFrontierExtensionProvenance.CutFrontierExtensionData
abbrev CutGraphUniverseData :=
  SchurDtnCutGraphUniverseProvenance.CutGraphUniverseData
abbrev BoundaryResidualSupportData :=
  SchurDtnBoundaryResidualSupportProvenance.BoundaryResidualSupportData
abbrev DefectSystem := SectorResolutionGate.DefectSystem

structure CutGraphTargetProvenanceRecord where
  boundaryRoleNodes : List Node
  interiorRoleNodes : List Node
  uvBoundaryRoleNodes : List Node
  envBoundaryRoleNodes : List Node
  recordRoleNodes : List Node
  universeNodes : List Node
  boundaryPort : Node
  sourcePort : Node
  graphAdjacent : Node -> Node -> Bool
  interiorPort : Node
  interiorLoadNode : Node
  frontierAdjacent : Node -> Node -> Bool
  loadAdjacent : Node -> Node -> Bool
  adjacent : Node -> Node -> Bool


def contains (x : Node) : List Node -> Bool
  | [] => false
  | y :: ys => if x == y then true else contains x ys


def roleNodes (p : CutGraphTargetProvenanceRecord) : List Node :=
  p.boundaryRoleNodes ++ p.interiorRoleNodes ++ p.uvBoundaryRoleNodes ++
    p.envBoundaryRoleNodes ++ p.recordRoleNodes


def targetOutsideRoles (p : CutGraphTargetProvenanceRecord) (x : Node) : Bool :=
  if contains x (roleNodes p) then false else true


def residualTargetNodes (p : CutGraphTargetProvenanceRecord) :
    List Node -> List Node
  | [] => []
  | x :: xs =>
      if targetOutsideRoles p x then
        x :: residualTargetNodes p xs
      else
        residualTargetNodes p xs


def candidateEdgeTargets (p : CutGraphTargetProvenanceRecord) : List Node :=
  residualTargetNodes p p.universeNodes


def toEdgeDerivationRecord (p : CutGraphTargetProvenanceRecord) :
    CutGraphEdgeDerivationRecord :=
  { boundaryRoleNodes := p.boundaryRoleNodes,
    interiorRoleNodes := p.interiorRoleNodes,
    uvBoundaryRoleNodes := p.uvBoundaryRoleNodes,
    envBoundaryRoleNodes := p.envBoundaryRoleNodes,
    recordRoleNodes := p.recordRoleNodes,
    boundaryPort := p.boundaryPort,
    sourcePort := p.sourcePort,
    targetNode := p.boundaryPort,
    candidateEdgeTargets := candidateEdgeTargets p,
    graphAdjacent := p.graphAdjacent,
    interiorPort := p.interiorPort,
    interiorLoadNode := p.interiorLoadNode,
    frontierAdjacent := p.frontierAdjacent,
    loadAdjacent := p.loadAdjacent,
    adjacent := p.adjacent }


theorem toEdgeDerivationRecord_candidateEdgeTargets
    (p : CutGraphTargetProvenanceRecord) :
    (toEdgeDerivationRecord p).candidateEdgeTargets =
      candidateEdgeTargets p := rfl


theorem toEdgeDerivationRecord_targetNode
    (p : CutGraphTargetProvenanceRecord) :
    (toEdgeDerivationRecord p).targetNode = p.boundaryPort := rfl


def eqAdj : Node -> Node -> Bool :=
  SchurDtnFrontierEdgeDerivationProvenance.eqAdj


def edge22 : DirectedEdge :=
  SchurDtnFrontierEdgeDerivationProvenance.edge22


def zeroTargetProvenanceNode2 : CutGraphTargetProvenanceRecord :=
  { boundaryRoleNodes := [0],
    interiorRoleNodes := [1],
    uvBoundaryRoleNodes := [1],
    envBoundaryRoleNodes := [0],
    recordRoleNodes := [],
    universeNodes := [0, 1],
    boundaryPort := 2,
    sourcePort := 2,
    graphAdjacent := eqAdj,
    interiorPort := 1,
    interiorLoadNode := 1,
    frontierAdjacent := eqAdj,
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


def residualTargetProvenanceNode2 : CutGraphTargetProvenanceRecord :=
  { boundaryRoleNodes := [0],
    interiorRoleNodes := [1],
    uvBoundaryRoleNodes := [1],
    envBoundaryRoleNodes := [0],
    recordRoleNodes := [],
    universeNodes := [0, 1, 2],
    boundaryPort := 2,
    sourcePort := 2,
    graphAdjacent := eqAdj,
    interiorPort := 1,
    interiorLoadNode := 1,
    frontierAdjacent := eqAdj,
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


theorem zero_target_role_nodes_node2 :
    roleNodes zeroTargetProvenanceNode2 = [0, 1, 1, 0] := rfl


theorem residual_target_role_nodes_node2 :
    roleNodes residualTargetProvenanceNode2 = [0, 1, 1, 0] := rfl


theorem zero_target_candidate_edge_targets_node2 :
    candidateEdgeTargets zeroTargetProvenanceNode2 = [] := rfl


theorem residual_target_candidate_edge_targets_node2 :
    candidateEdgeTargets residualTargetProvenanceNode2 = [2] := rfl


theorem zero_target_edge_derivation_record_eq_previous_node2 :
    toEdgeDerivationRecord zeroTargetProvenanceNode2 =
      SchurDtnFrontierEdgeDerivationProvenance.noDerivedEdgeRecordNode2 := rfl


theorem residual_target_edge_derivation_record_eq_previous_node2 :
    toEdgeDerivationRecord residualTargetProvenanceNode2 =
      SchurDtnFrontierEdgeDerivationProvenance.residualDerivedEdgeRecordNode2 := rfl


theorem zero_target_derived_edge_table_node2 :
    SchurDtnFrontierEdgeDerivationProvenance.edgeTable
      (toEdgeDerivationRecord zeroTargetProvenanceNode2) = [] := rfl


theorem residual_target_derived_edge_table_node2 :
    SchurDtnFrontierEdgeDerivationProvenance.edgeTable
      (toEdgeDerivationRecord residualTargetProvenanceNode2) = [edge22] := rfl


theorem zero_target_edge_not_present_node2 :
    SchurDtnFrontierEdgeTableProvenance.edgePresent
      (SchurDtnFrontierEdgeDerivationProvenance.toEdgeTableRecord
        (toEdgeDerivationRecord zeroTargetProvenanceNode2)) = false := rfl


theorem residual_target_edge_present_node2 :
    SchurDtnFrontierEdgeTableProvenance.edgePresent
      (SchurDtnFrontierEdgeDerivationProvenance.toEdgeTableRecord
        (toEdgeDerivationRecord residualTargetProvenanceNode2)) = true := rfl


def zeroTargetCutFrontierExtensionNode2 : CutFrontierExtensionData :=
  SchurDtnFrontierEdgeDerivationProvenance.noDerivedCutFrontierExtensionNode2


def residualTargetCutFrontierExtensionNode2 : CutFrontierExtensionData :=
  SchurDtnFrontierEdgeDerivationProvenance.residualDerivedCutFrontierExtensionNode2


theorem zero_target_frontier_candidates_node2 :
    SchurDtnGraphFrontierExtensionProvenance.frontierCandidateNodes
      zeroTargetCutFrontierExtensionNode2 = [] := rfl


theorem residual_target_frontier_candidates_node2 :
    SchurDtnGraphFrontierExtensionProvenance.frontierCandidateNodes
      residualTargetCutFrontierExtensionNode2 = [2] := rfl


def residualTargetCutGraphUniverseNode2 : CutGraphUniverseData :=
  SchurDtnGraphFrontierExtensionProvenance.toCutGraphUniverseData
    residualTargetCutFrontierExtensionNode2


theorem residual_target_universe_nodes_node2 :
    SchurDtnCutGraphUniverseProvenance.universeNodes
      residualTargetCutGraphUniverseNode2 = [0, 1, 2] := rfl


def residualTargetBoundarySupportNode2 : BoundaryResidualSupportData :=
  SchurDtnCutGraphUniverseProvenance.toBoundaryResidualSupportData
    residualTargetCutGraphUniverseNode2


theorem residual_target_support_nodes_node2 :
    SchurDtnBoundaryResidualSupportProvenance.residualSupportNodes
      residualTargetBoundarySupportNode2 = [2] := rfl


theorem residual_target_candidate_load_nodes_node2 :
    SchurDtnCutCandidateLoadProvenance.candidateLoadNodes
      (SchurDtnBoundaryResidualSupportProvenance.toCutCandidateLoadSupportData
        residualTargetBoundarySupportNode2) = [1, 2] := rfl


def cutFrontierTargetProvenanceDefectSystem : DefectSystem Bool :=
  SchurDtnFrontierEdgeDerivationProvenance.cutFrontierDerivedEdgeDefectSystem


theorem cut_frontier_target_provenance_closure_status :
    cutFrontierTargetProvenanceDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      cutFrontierTargetProvenanceDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        cutFrontierTargetProvenanceDefectSystem) :=
  SchurDtnFrontierEdgeDerivationProvenance.cut_frontier_derived_edge_closure_status


def symmetricDefectSystem : DefectSystem Bool :=
  SchurDtnFrontierEdgeDerivationProvenance.symmetricDefectSystem


theorem symmetric_frontier_target_provenance_status :
    symmetricDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem :=
  SchurDtnFrontierEdgeDerivationProvenance.symmetric_frontier_derived_edge_status


def targetUniverseStillNeedsCutGraphDerivation : Prop := True


theorem target_universe_still_needs_cut_graph_derivation :
    targetUniverseStillNeedsCutGraphDerivation :=
  True.intro

end SchurDtnFrontierTargetProvenance
