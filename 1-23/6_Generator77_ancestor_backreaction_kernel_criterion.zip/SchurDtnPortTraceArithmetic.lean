import CNNA.SchurDtnPortResidualArithmetic

namespace SchurDtnPortTraceArithmetic

abbrev Node := Fin 3
abbrev FiniteCut := FiniteGraphLaplacianBlocks.FiniteCut Node
abbrev CertifiedSchurBlocks := DirichletInverseWitness.CertifiedSchurBlocks Node
abbrev SchurSummary := SchurDtnSummary.SchurSummary Node
abbrev DefectSystem := SectorResolutionGate.DefectSystem

structure ScalarPortBlock where
  LBB : Nat
  LBI : Nat
  R : Nat
  LIB : Nat
  LII : Nat
  leftWitness : LII * R = 1
  rightWitness : R * LII = 1


def schurCorrection (b : ScalarPortBlock) : Nat :=
  b.LBI * b.R * b.LIB


def schurDtnTrace (b : ScalarPortBlock) : Nat :=
  FiniteHandoffSummary.absDiff b.LBB (schurCorrection b)


def scalarOnePortBlock (LBB LBI LIB : Nat) : ScalarPortBlock :=
  { LBB := LBB,
    LBI := LBI,
    R := 1,
    LIB := LIB,
    LII := 1,
    leftWitness := rfl,
    rightWitness := rfl }


theorem scalar_one_port_trace_unfold (LBB LBI LIB : Nat) :
    schurDtnTrace (scalarOnePortBlock LBB LBI LIB) =
      FiniteHandoffSummary.absDiff LBB (LBI * 1 * LIB) := rfl


def zeroPortBlock : ScalarPortBlock :=
  scalarOnePortBlock 0 0 0


def residualPortBlock : ScalarPortBlock :=
  scalarOnePortBlock 1 0 0


theorem zero_port_trace_zero :
    schurDtnTrace zeroPortBlock = 0 := rfl


theorem residual_port_trace_one :
    schurDtnTrace residualPortBlock = 1 := rfl


structure SchurDtnTracePortData (V : Type) where
  boundary : List V
  interior : List V
  uvBoundary : List V
  envBoundary : List V
  recordNodes : List V
  candidatePortNodes : List V
  beforePortBlock : V -> ScalarPortBlock
  afterPortBlock : V -> ScalarPortBlock
  adjacent : V -> V -> Bool


def beforePortTrace {V : Type} (p : SchurDtnTracePortData V) (x : V) : Nat :=
  schurDtnTrace (p.beforePortBlock x)


def afterPortTrace {V : Type} (p : SchurDtnTracePortData V) (x : V) : Nat :=
  schurDtnTrace (p.afterPortBlock x)


def toResidualPortData {V : Type} (p : SchurDtnTracePortData V) :
    SchurDtnPortResidualArithmetic.SchurDtnResidualPortData V :=
  { boundary := p.boundary,
    interior := p.interior,
    uvBoundary := p.uvBoundary,
    envBoundary := p.envBoundary,
    recordNodes := p.recordNodes,
    candidatePortNodes := p.candidatePortNodes,
    beforePortTrace := beforePortTrace p,
    afterPortTrace := afterPortTrace p,
    adjacent := p.adjacent }


theorem toResidual_beforePortTrace {V : Type}
    (p : SchurDtnTracePortData V) :
    (toResidualPortData p).beforePortTrace = beforePortTrace p := rfl


theorem toResidual_afterPortTrace {V : Type}
    (p : SchurDtnTracePortData V) :
    (toResidualPortData p).afterPortTrace = afterPortTrace p := rfl


def edge01 (x y : Node) : Bool :=
  ((x == 0) && (y == 1)) || ((x == 1) && (y == 0))


def zeroBlockAt (_x : Node) : ScalarPortBlock :=
  zeroPortBlock


def minusAfterBlockAt (x : Node) : ScalarPortBlock :=
  if x == 2 then residualPortBlock else zeroPortBlock


def beforeTracePortData : SchurDtnTracePortData Node :=
  { boundary := [0],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    candidatePortNodes := [0, 1, 2],
    beforePortBlock := zeroBlockAt,
    afterPortBlock := zeroBlockAt,
    adjacent := edge01 }


def plusAfterTracePortData : SchurDtnTracePortData Node :=
  beforeTracePortData


def minusAfterTracePortData : SchurDtnTracePortData Node :=
  { boundary := [0],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    candidatePortNodes := [0, 1, 2],
    beforePortBlock := zeroBlockAt,
    afterPortBlock := minusAfterBlockAt,
    adjacent := edge01 }


theorem before_trace_port_trace_node0 :
    beforePortTrace beforeTracePortData 0 = 0 := rfl


theorem before_trace_port_trace_node1 :
    beforePortTrace beforeTracePortData 1 = 0 := rfl


theorem before_trace_port_trace_node2 :
    beforePortTrace beforeTracePortData 2 = 0 := rfl


theorem plus_after_trace_port_trace_node2 :
    afterPortTrace plusAfterTracePortData 2 = 0 := rfl


theorem minus_after_trace_port_trace_node0 :
    afterPortTrace minusAfterTracePortData 0 = 0 := rfl


theorem minus_after_trace_port_trace_node1 :
    afterPortTrace minusAfterTracePortData 1 = 0 := rfl


theorem minus_after_trace_port_trace_node2 :
    afterPortTrace minusAfterTracePortData 2 = 1 := rfl


def beforeResidualPortData :
    SchurDtnPortResidualArithmetic.SchurDtnResidualPortData Node :=
  toResidualPortData beforeTracePortData


def plusAfterResidualPortData :
    SchurDtnPortResidualArithmetic.SchurDtnResidualPortData Node :=
  toResidualPortData plusAfterTracePortData


def minusAfterResidualPortData :
    SchurDtnPortResidualArithmetic.SchurDtnResidualPortData Node :=
  toResidualPortData minusAfterTracePortData


theorem before_residual_port_nodes_empty :
    SchurDtnPortResidualArithmetic.dtnPortNodes
      beforeResidualPortData = [] := rfl


theorem plus_residual_port_nodes_empty :
    SchurDtnPortResidualArithmetic.dtnPortNodes
      plusAfterResidualPortData = [] := rfl


theorem minus_residual_port_nodes_from_schur_trace_arithmetic :
    SchurDtnPortResidualArithmetic.dtnPortNodes
      minusAfterResidualPortData = [2] := rfl


def beforePortData : SchurDtnPortSupportProvenance.SchurDtnPortData Node :=
  SchurDtnPortResidualArithmetic.toPortData beforeResidualPortData


def plusAfterPortData : SchurDtnPortSupportProvenance.SchurDtnPortData Node :=
  SchurDtnPortResidualArithmetic.toPortData plusAfterResidualPortData


def minusAfterPortData : SchurDtnPortSupportProvenance.SchurDtnPortData Node :=
  SchurDtnPortResidualArithmetic.toPortData minusAfterResidualPortData


theorem before_dtn_port_nodes_from_trace_arithmetic :
    beforePortData.dtnPortNodes = [] := rfl


theorem plus_dtn_port_nodes_from_trace_arithmetic :
    plusAfterPortData.dtnPortNodes = [] := rfl


theorem minus_dtn_port_nodes_from_trace_arithmetic :
    minusAfterPortData.dtnPortNodes = [2] := rfl


theorem before_support_nodes_from_trace_arithmetic :
    SchurDtnPortSupportProvenance.supportNodes beforePortData = [0, 1] := rfl


theorem plus_support_nodes_from_trace_arithmetic :
    SchurDtnPortSupportProvenance.supportNodes plusAfterPortData = [0, 1] := rfl


theorem minus_support_nodes_from_trace_arithmetic :
    SchurDtnPortSupportProvenance.supportNodes minusAfterPortData =
      [0, 1, 2] := rfl


def beforeCut : FiniteCut :=
  SchurDtnPortSupportProvenance.toFiniteCut beforePortData


def plusAfterCut : FiniteCut :=
  SchurDtnPortSupportProvenance.toFiniteCut plusAfterPortData


def minusAfterCut : FiniteCut :=
  SchurDtnPortSupportProvenance.toFiniteCut minusAfterPortData


theorem before_cut_complement_empty :
    beforeCut.complementNodes = [] := rfl


theorem plus_cut_complement_empty :
    plusAfterCut.complementNodes = [] := rfl


theorem minus_cut_complement_from_trace_arithmetic :
    minusAfterCut.complementNodes = [2] := rfl


theorem before_complement_signature_zero :
    FiniteCutCombinatorics.complementSignature beforeCut = 0 := rfl


theorem plus_complement_signature_zero :
    FiniteCutCombinatorics.complementSignature plusAfterCut = 0 := rfl


theorem minus_complement_signature_one :
    FiniteCutCombinatorics.complementSignature minusAfterCut = 1 := rfl


def beforeBlocks : CertifiedSchurBlocks :=
  SchurDtnPortSupportProvenance.certifiedBlocks beforeCut


def plusAfterBlocks : CertifiedSchurBlocks :=
  SchurDtnPortSupportProvenance.certifiedBlocks plusAfterCut


def minusAfterBlocks : CertifiedSchurBlocks :=
  SchurDtnPortSupportProvenance.certifiedBlocks minusAfterCut


def beforeSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary beforeBlocks


def plusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary plusAfterBlocks


def minusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary minusAfterBlocks


def plusComputedDefectVector : List Nat :=
  DirichletInverseWitness.toDefectVector beforeBlocks plusAfterBlocks


def minusComputedDefectVector : List Nat :=
  DirichletInverseWitness.toDefectVector beforeBlocks minusAfterBlocks


theorem plus_computed_defect_vector_zero :
    plusComputedDefectVector = [0, 0, 0, 0, 0] := rfl


theorem minus_computed_defect_vector_from_trace_arithmetic :
    minusComputedDefectVector = [0, 0, 0, 0, 1] := rfl


def traceArithmeticDefectSystem : DefectSystem Bool :=
  SchurStrictPreferenceBridge.schurCutHandoffDefectSystem
    beforeSummary plusAfterSummary minusAfterSummary


theorem trace_arithmetic_false_defect :
    traceArithmeticDefectSystem.defect false = [0, 0, 0, 0, 0] := rfl


theorem trace_arithmetic_true_defect :
    traceArithmeticDefectSystem.defect true = [0, 0, 0, 0, 1] := rfl


theorem trace_arithmetic_minSet_singleton :
    traceArithmeticDefectSystem.minSet = [false] := rfl


theorem trace_arithmetic_kernel_one :
    traceArithmeticDefectSystem.kernel = 1 :=
  CanonicalGrowthKernel.DefectSystem.unique_kernel_one
    traceArithmeticDefectSystem false trace_arithmetic_minSet_singleton


def traceArithmeticSchurStrictPreference :
    SchurStrictPreferenceBridge.SchurStrictPreference
      beforeSummary plusAfterSummary minusAfterSummary :=
  { minSet_singleton := trace_arithmetic_minSet_singleton }


theorem trace_arithmetic_resolved_j_sign :
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      traceArithmeticDefectSystem :=
  SchurStrictPreferenceBridge.resolved_of_schur_strict_preference
    beforeSummary plusAfterSummary minusAfterSummary
    traceArithmeticSchurStrictPreference


theorem trace_arithmetic_locks_eq_plusSector :
    SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      traceArithmeticDefectSystem = JSignClosureCriterion.plusSector := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    SchurStrictPreferenceBridge.schurSectorMap
    CutStrictPreferenceBridge.cutSectorMap
    HandoffStrictPreferenceBridge.handoffSectorMap
    GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.plusSector
  rw [trace_arithmetic_minSet_singleton]
  rfl


theorem trace_arithmetic_not_flip_closed :
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        traceArithmeticDefectSystem) := by
  intro hclosed
  rw [trace_arithmetic_locks_eq_plusSector] at hclosed
  exact SymmetryBreakingClosureGate.plusSector_not_closed_under_flip hclosed


theorem trace_arithmetic_closure_status :
    traceArithmeticDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      traceArithmeticDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        traceArithmeticDefectSystem) :=
  And.intro trace_arithmetic_kernel_one
    (And.intro trace_arithmetic_resolved_j_sign
      trace_arithmetic_not_flip_closed)


def symmetricMinusAfterTracePortData : SchurDtnTracePortData Node :=
  plusAfterTracePortData


def symmetricMinusAfterResidualPortData :
    SchurDtnPortResidualArithmetic.SchurDtnResidualPortData Node :=
  toResidualPortData symmetricMinusAfterTracePortData


def symmetricMinusAfterPortData :
    SchurDtnPortSupportProvenance.SchurDtnPortData Node :=
  SchurDtnPortResidualArithmetic.toPortData symmetricMinusAfterResidualPortData


def symmetricMinusAfterCut : FiniteCut :=
  SchurDtnPortSupportProvenance.toFiniteCut symmetricMinusAfterPortData


def symmetricMinusAfterBlocks : CertifiedSchurBlocks :=
  SchurDtnPortSupportProvenance.certifiedBlocks symmetricMinusAfterCut


def symmetricMinusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary symmetricMinusAfterBlocks


def symmetricDefectSystem : DefectSystem Bool :=
  SchurStrictPreferenceBridge.schurCutHandoffDefectSystem
    beforeSummary plusAfterSummary symmetricMinusAfterSummary


theorem symmetric_trace_false_defect :
    symmetricDefectSystem.defect false = [0, 0, 0, 0, 0] := rfl


theorem symmetric_trace_true_defect :
    symmetricDefectSystem.defect true = [0, 0, 0, 0, 0] := rfl


theorem symmetric_trace_minSet_pair :
    symmetricDefectSystem.minSet = [false, true] := rfl


theorem symmetric_trace_kernel_two :
    symmetricDefectSystem.kernel = 2 :=
  CanonicalGrowthKernel.DefectSystem.two_sector_kernel
    symmetricDefectSystem false true symmetric_trace_minSet_pair


theorem symmetric_trace_locks_eq_twoSectors :
    SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      symmetricDefectSystem = JSignClosureCriterion.twoSectors := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    SchurStrictPreferenceBridge.schurSectorMap
    CutStrictPreferenceBridge.cutSectorMap
    HandoffStrictPreferenceBridge.handoffSectorMap
    GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.twoSectors
  rw [symmetric_trace_minSet_pair]
  rfl


theorem symmetric_trace_not_resolved_j_sign :
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem := by
  change ¬ JSignClosureCriterion.hasClosedJSign
    (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      symmetricDefectSystem)
  rw [symmetric_trace_locks_eq_twoSectors]
  exact JSignClosureCriterion.twoSectors_no_closed_j_sign


theorem symmetric_trace_status :
    symmetricDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem :=
  And.intro symmetric_trace_kernel_two
    symmetric_trace_not_resolved_j_sign


def scalarPortBlockEntriesStillNeedGraphSchurProvenance : Prop := True


theorem scalar_port_block_entries_still_need_graph_schur_provenance :
    scalarPortBlockEntriesStillNeedGraphSchurProvenance :=
  True.intro

end SchurDtnPortTraceArithmetic
