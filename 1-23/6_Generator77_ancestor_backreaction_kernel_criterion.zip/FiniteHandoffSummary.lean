/-
  FiniteHandoffSummary.lean
  -------------------------
  Endlicher Schnitt und Handoff-Summary -> HandoffData.

  Status: naechster Adapter nach HandoffDefectSystem.lean.
  Diese Datei berechnet noch kein echtes Matrix-Schurkomplement. Sie kapselt
  den parameterfreien Uebergang von endlichen Cut-Summaries zu denjenigen
  Nat-Summaries, die HandoffDefectSystem.lean als Defektdaten verwendet.

  Kein Selector, kein Gewicht, keine Temperatur, kein Bias, kein Label-Tie-Break.
  Der naechste tiefere Schritt ist die konkrete Schur-DtN-Berechnung der Felder
  dtnTrace, Load, Record und Complement aus einem endlichen Approximanten.
-/

namespace FiniteHandoffSummary

/-! ## 0. Gemeinsame Handoff-Basis -/

def absDiff (a b : Nat) : Nat :=
  if a <= b then b - a else a - b

theorem absDiff_self (a : Nat) : absDiff a a = 0 := by
  unfold absDiff
  simp

structure HandoffData where
  dtnBefore : Nat
  dtnAfter : Nat
  uvLoad : Nat
  envLoad : Nat
  cutDefect : Nat
  recordDefect : Nat
  complementDefect : Nat

def dtnDefect (h : HandoffData) : Nat :=
  absDiff h.dtnBefore h.dtnAfter

def balanceDefect (h : HandoffData) : Nat :=
  absDiff h.uvLoad h.envLoad

def defectVector (h : HandoffData) : List Nat :=
  [h.cutDefect,
   dtnDefect h,
   h.recordDefect,
   balanceDefect h,
   h.complementDefect]

/-! ## 1. Endliche Cut-Summary -/

structure CutSummary where
  boundarySize : Nat
  interiorSize : Nat
  dtnTrace : Nat
  uvBoundaryLoad : Nat
  envBoundaryLoad : Nat
  cutKernelDefect : Nat
  recordSignature : Nat
  complementSignature : Nat

def recordDefect (before after : CutSummary) : Nat :=
  absDiff before.recordSignature after.recordSignature

def complementDefect (before after : CutSummary) : Nat :=
  absDiff before.complementSignature after.complementSignature

def toHandoffData (before after : CutSummary) : HandoffData :=
  { dtnBefore := before.dtnTrace,
    dtnAfter := after.dtnTrace,
    uvLoad := after.uvBoundaryLoad,
    envLoad := after.envBoundaryLoad,
    cutDefect := after.cutKernelDefect,
    recordDefect := recordDefect before after,
    complementDefect := complementDefect before after }

def toDefectVector (before after : CutSummary) : List Nat :=
  defectVector (toHandoffData before after)

theorem toHandoffData_dtnBefore (before after : CutSummary) :
    (toHandoffData before after).dtnBefore = before.dtnTrace := rfl

theorem toHandoffData_dtnAfter (before after : CutSummary) :
    (toHandoffData before after).dtnAfter = after.dtnTrace := rfl

theorem toHandoffData_uvLoad (before after : CutSummary) :
    (toHandoffData before after).uvLoad = after.uvBoundaryLoad := rfl

theorem toHandoffData_envLoad (before after : CutSummary) :
    (toHandoffData before after).envLoad = after.envBoundaryLoad := rfl

theorem toDefectVector_unfold (before after : CutSummary) :
    toDefectVector before after =
      [after.cutKernelDefect,
       absDiff before.dtnTrace after.dtnTrace,
       absDiff before.recordSignature after.recordSignature,
       absDiff after.uvBoundaryLoad after.envBoundaryLoad,
       absDiff before.complementSignature after.complementSignature] := rfl

/-! ## 2. Stabilitaets-Gates auf Summary-Ebene -/

def DtnStable (before after : CutSummary) : Prop :=
  before.dtnTrace = after.dtnTrace

def LoadBalanced (after : CutSummary) : Prop :=
  after.uvBoundaryLoad = after.envBoundaryLoad

def RecordStable (before after : CutSummary) : Prop :=
  before.recordSignature = after.recordSignature

def ComplementStable (before after : CutSummary) : Prop :=
  before.complementSignature = after.complementSignature

theorem dtnDefect_zero_of_stable (before after : CutSummary)
    (h : DtnStable before after) :
    dtnDefect (toHandoffData before after) = 0 := by
  unfold DtnStable at h
  unfold dtnDefect toHandoffData
  rw [h]
  exact absDiff_self after.dtnTrace

theorem balanceDefect_zero_of_balanced (before after : CutSummary)
    (h : LoadBalanced after) :
    balanceDefect (toHandoffData before after) = 0 := by
  unfold LoadBalanced at h
  unfold balanceDefect toHandoffData
  rw [h]
  exact absDiff_self after.envBoundaryLoad

theorem recordDefect_zero_of_stable (before after : CutSummary)
    (h : RecordStable before after) :
    recordDefect before after = 0 := by
  unfold RecordStable at h
  unfold recordDefect
  rw [h]
  exact absDiff_self after.recordSignature

theorem complementDefect_zero_of_stable (before after : CutSummary)
    (h : ComplementStable before after) :
    complementDefect before after = 0 := by
  unfold ComplementStable at h
  unfold complementDefect
  rw [h]
  exact absDiff_self after.complementSignature

/-! ## 3. Perfekte Fortsetzung als Null-Defekt -/

def perfectAfter (before : CutSummary) (load : Nat) : CutSummary :=
  { boundarySize := before.boundarySize,
    interiorSize := before.interiorSize,
    dtnTrace := before.dtnTrace,
    uvBoundaryLoad := load,
    envBoundaryLoad := load,
    cutKernelDefect := 0,
    recordSignature := before.recordSignature,
    complementSignature := before.complementSignature }

theorem perfectAfter_defect_zero (before : CutSummary) (load : Nat) :
    toDefectVector before (perfectAfter before load) = [0, 0, 0, 0, 0] := by
  unfold toDefectVector defectVector toHandoffData perfectAfter
  unfold dtnDefect balanceDefect recordDefect complementDefect
  simp [absDiff]

/-! ## 4. Candidate-System fuer den naechsten Growth-Schritt -/

structure FiniteHandoffSystem (A : Type) where
  candidates : List A
  before : CutSummary
  after : A -> CutSummary

def FiniteHandoffSystem.data {A : Type}
    (s : FiniteHandoffSystem A) (a : A) : HandoffData :=
  toHandoffData s.before (s.after a)

def FiniteHandoffSystem.defect {A : Type}
    (s : FiniteHandoffSystem A) (a : A) : List Nat :=
  defectVector (s.data a)

theorem FiniteHandoffSystem.defect_unfold {A : Type}
    (s : FiniteHandoffSystem A) (a : A) :
    s.defect a = toDefectVector s.before (s.after a) := rfl

theorem FiniteHandoffSystem.defect_fixed_tuple {A : Type}
    (s : FiniteHandoffSystem A) (a : A) :
    s.defect a =
      [(s.after a).cutKernelDefect,
       absDiff s.before.dtnTrace (s.after a).dtnTrace,
       absDiff s.before.recordSignature (s.after a).recordSignature,
       absDiff (s.after a).uvBoundaryLoad (s.after a).envBoundaryLoad,
       absDiff s.before.complementSignature (s.after a).complementSignature] := rfl

theorem FiniteHandoffSystem.perfect_candidate_zero {A : Type}
    (s : FiniteHandoffSystem A) (a : A) (load : Nat)
    (h : s.after a = perfectAfter s.before load) :
    s.defect a = [0, 0, 0, 0, 0] := by
  rw [FiniteHandoffSystem.defect_unfold, h]
  exact perfectAfter_defect_zero s.before load

end FiniteHandoffSummary
