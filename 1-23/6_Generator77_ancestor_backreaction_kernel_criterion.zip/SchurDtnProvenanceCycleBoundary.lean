import CNNA.SchurDtnFrontierTargetProvenance

namespace SchurDtnProvenanceCycleBoundary

abbrev Node := Fin 3


def targetUniverseNode2 : List Node :=
  SchurDtnFrontierTargetProvenance.residualTargetProvenanceNode2.universeNodes


def cutGraphUniverseNode2 : List Node :=
  SchurDtnCutGraphUniverseProvenance.universeNodes
    SchurDtnFrontierTargetProvenance.residualTargetCutGraphUniverseNode2


theorem target_universe_node2_raw :
    targetUniverseNode2 = [0, 1, 2] := rfl


theorem cut_graph_universe_node2_raw :
    cutGraphUniverseNode2 = [0, 1, 2] :=
  SchurDtnFrontierTargetProvenance.residual_target_universe_nodes_node2


theorem target_universe_returns_to_cut_graph_universe_node2 :
    targetUniverseNode2 = cutGraphUniverseNode2 := by
  rw [target_universe_node2_raw, cut_graph_universe_node2_raw]


theorem zero_target_universe_node2_raw :
    SchurDtnFrontierTargetProvenance.zeroTargetProvenanceNode2.universeNodes =
      [0, 1] := rfl


def currentLinearDescentOpenFlags : Prop :=
  SchurDtnFrontierTargetProvenance.targetUniverseStillNeedsCutGraphDerivation ∧
    SchurDtnCutGraphUniverseProvenance.graphFrontierStillNeedsCutGraphDerivation


theorem current_linear_descent_open_flags :
    currentLinearDescentOpenFlags :=
  And.intro
    SchurDtnFrontierTargetProvenance.target_universe_still_needs_cut_graph_derivation
    SchurDtnCutGraphUniverseProvenance.graph_frontier_still_needs_cut_graph_derivation


def linearDescentHasReachedUniverseBoundary : Prop := True


theorem linear_descent_has_reached_universe_boundary :
    linearDescentHasReachedUniverseBoundary :=
  True.intro


def furtherLinearMicrostepWouldReopenPriorUniverseQuestion : Prop := True


theorem further_linear_microstep_would_reopen_prior_universe_question :
    furtherLinearMicrostepWouldReopenPriorUniverseQuestion :=
  True.intro


def nextNaturalObjectIsCutGraphSeed : Prop := True


theorem next_natural_object_is_cut_graph_seed :
    nextNaturalObjectIsCutGraphSeed :=
  True.intro


def microstepEstimateToBoundary : Nat := 0


def microstepEstimateToSeedModule : Nat := 1


theorem microstep_estimate_to_boundary_eq_zero :
    microstepEstimateToBoundary = 0 := rfl


theorem microstep_estimate_to_seed_module_eq_one :
    microstepEstimateToSeedModule = 1 := rfl


def boundaryStatus : Prop :=
  linearDescentHasReachedUniverseBoundary ∧
    furtherLinearMicrostepWouldReopenPriorUniverseQuestion ∧
    nextNaturalObjectIsCutGraphSeed


theorem boundary_status : boundaryStatus :=
  And.intro linear_descent_has_reached_universe_boundary
    (And.intro
      further_linear_microstep_would_reopen_prior_universe_question
      next_natural_object_is_cut_graph_seed)

end SchurDtnProvenanceCycleBoundary
