import CNNA.AbstractAddressTypeGrowthCriterion

namespace CanonicalPortNumberingCriterion

abbrev Node := Fin 3
abbrev CurrentAddress := SchurDtnDerivedAddressSeed.Address
abbrev AbstractAddressSeed := AbstractAddressTypeGrowthCriterion.AbstractAddressSeed
abbrev CurrentSeedCriterion := AbstractAddressTypeGrowthCriterion.CurrentSeedCriterion

structure LocalPortRoles (A : Type) where
  cutRoot : A
  selectedVisible : A
  frontierResidual : A


def nodeOfByRoles {A : Type} [BEq A] (r : LocalPortRoles A) (a : A) : Node :=
  if a == r.cutRoot then 0
  else if a == r.selectedVisible then 1
  else if a == r.frontierResidual then 2
  else 0


def currentPortRoles : LocalPortRoles CurrentAddress :=
  { cutRoot := SchurDtnDerivedAddressSeed.cutRoot,
    selectedVisible := SchurDtnDerivedAddressSeed.selectedChild,
    frontierResidual := SchurDtnDerivedAddressSeed.frontierPortAddress }


def canonicalNodeOfCurrent : CurrentAddress -> Node :=
  nodeOfByRoles currentPortRoles


theorem canonical_cut_root_node_zero :
    canonicalNodeOfCurrent SchurDtnDerivedAddressSeed.cutRoot = 0 := rfl


theorem canonical_selected_visible_node_one :
    canonicalNodeOfCurrent SchurDtnDerivedAddressSeed.selectedChild = 1 := rfl


theorem canonical_frontier_residual_node_two :
    canonicalNodeOfCurrent SchurDtnDerivedAddressSeed.frontierPortAddress = 2 := by
  change canonicalNodeOfCurrent
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) = 2
  rfl


theorem canonical_nodeOf_matches_current_on_roles :
    canonicalNodeOfCurrent SchurDtnDerivedAddressSeed.cutRoot = 0 ∧
    canonicalNodeOfCurrent SchurDtnDerivedAddressSeed.selectedChild = 1 ∧
    canonicalNodeOfCurrent SchurDtnDerivedAddressSeed.frontierPortAddress = 2 :=
  And.intro canonical_cut_root_node_zero
    (And.intro canonical_selected_visible_node_one
      canonical_frontier_residual_node_two)


def currentCanonicalAbstractSeed : AbstractAddressSeed CurrentAddress :=
  { cutRoot := SchurDtnDerivedAddressSeed.cutRoot,
    selectedAddress := SchurDtnDerivedAddressSeed.selectedChild,
    frontierAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    sourceAddress := SchurDtnDerivedAddressSeed.cutRoot,
    targetAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    visibleRoles := SchurDtnDerivedAddressSeed.roleAddresses,
    beforeRank := 0,
    afterRank := 1,
    nodeOf := canonicalNodeOfCurrent }


theorem canonical_current_frontier_outside_visible :
    AbstractAddressTypeGrowthCriterion.outsideVisible
      currentCanonicalAbstractSeed.visibleRoles
      currentCanonicalAbstractSeed.frontierAddress = true := rfl


theorem canonical_current_source_node_zero :
    currentCanonicalAbstractSeed.nodeOf
      currentCanonicalAbstractSeed.cutRoot = 0 := rfl


theorem canonical_current_frontier_node_two :
    currentCanonicalAbstractSeed.nodeOf
      currentCanonicalAbstractSeed.frontierAddress = 2 :=
  canonical_frontier_residual_node_two


def currentCanonicalSeedCriterion :
    CurrentSeedCriterion currentCanonicalAbstractSeed :=
  { source_is_cut_root := rfl,
    target_is_frontier := rfl,
    rank_increases := rfl,
    frontier_outside_visible := canonical_current_frontier_outside_visible,
    source_node_zero := canonical_current_source_node_zero,
    frontier_node_two := canonical_current_frontier_node_two,
    cut_root_is_local := rfl,
    frontier_is_local := rfl }


theorem current_canonical_seed_to_generic_seed :
    AbstractAddressTypeGrowthCriterion.toGenericLocalSeed
      currentCanonicalAbstractSeed =
      GenericAddressGrowthCriterion.activeGenericSeed := rfl


theorem current_canonical_seed_to_local_rule :
    AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
      currentCanonicalAbstractSeed =
      GrowthEdgeProvenance.activeAddressGrowthRule := rfl


theorem canonical_port_numbering_growth_active :
    GrowthEdgeProvenance.growthActive
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentCanonicalAbstractSeed) = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_growth_active
    currentCanonicalSeedCriterion


theorem canonical_port_numbering_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentCanonicalAbstractSeed) 0 2 = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_forward_edge
    currentCanonicalSeedCriterion


theorem canonical_port_numbering_backward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentCanonicalAbstractSeed) 2 0 = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_backward_edge
    currentCanonicalSeedCriterion


theorem canonical_port_numbering_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  GrowthEdgeProvenance.derived_growth_status


def canonicalPortNumberingStillLocalRoleOrder : Prop := True


theorem canonical_port_numbering_still_local_role_order :
    canonicalPortNumberingStillLocalRoleOrder :=
  True.intro

end CanonicalPortNumberingCriterion
