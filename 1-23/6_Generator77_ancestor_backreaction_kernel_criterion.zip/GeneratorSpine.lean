import CNNA.SchurDtnDerivedSeedRebase
import CNNA.ConcreteSymmetricCutG1Test
import CNNA.ConcreteGrowthIrreversibilityG1Test
import CNNA.GrowthEdgeProvenance
import CNNA.LocalGrowthEdgeCriterion
import CNNA.AddressGrowthEdgeCriterion
import CNNA.GenericAddressGrowthCriterion
import CNNA.AbstractAddressTypeGrowthCriterion
import CNNA.CanonicalPortNumberingCriterion
import CNNA.CanonicalRoleOrderCriterion
import CNNA.CanonicalFillOrderCriterion
import CNNA.FillEndpointDerivationCriterion
import CNNA.FillDynamicsRankCriterion
import CNNA.FrontierRankProfileCriterion
import CNNA.FrontierPhaseCertificateCriterion
import CNNA.FrontierEventPhaseBridgeCriterion
import CNNA.FillOrbitBasinCriterion
import CNNA.FillOrbitEndpointCodeCriterion
import CNNA.FillOrbitCycleBridgeCriterion
import CNNA.CycleCirculationGate
import CNNA.SchurCutSpectralTowerCriterion
import CNNA.AncestorBackreactionKernelCriterion

namespace GeneratorSpine

def currentActiveModuleCount : Nat := 24

def currentSupportModuleCount : Nat := 44

def currentTotalModuleCount : Nat := 68


theorem derived_seed_target_record_matches_support_witness :
    SchurDtnDerivedAddressSeed.residualAddressTargetRecord =
      SchurDtnFrontierTargetProvenance.residualTargetProvenanceNode2 :=
  SchurDtnDerivedSeedRebase.primary_target_record_eq_legacy


theorem derived_seed_defect_system_is_primary :
    SchurDtnDerivedSeedRebase.primaryDefectSystem =
      SchurDtnFrontierTargetProvenance.cutFrontierTargetProvenanceDefectSystem :=
  SchurDtnDerivedSeedRebase.primary_defect_system_eq_legacy


theorem derived_seed_candidate_targets :
    SchurDtnFrontierTargetProvenance.candidateEdgeTargets
      SchurDtnDerivedAddressSeed.residualAddressTargetRecord = [2] :=
  SchurDtnDerivedSeedRebase.primary_candidate_targets


theorem derived_seed_edge_present :
    SchurDtnFrontierEdgeTableProvenance.edgePresent
      (SchurDtnFrontierEdgeDerivationProvenance.toEdgeTableRecord
        (SchurDtnFrontierTargetProvenance.toEdgeDerivationRecord
          SchurDtnDerivedAddressSeed.residualAddressTargetRecord)) = true :=
  SchurDtnDerivedSeedRebase.primary_edge_present


theorem derived_seed_closes_j_sign :
    SchurDtnDerivedSeedRebase.primaryDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      SchurDtnDerivedSeedRebase.primaryDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        SchurDtnDerivedSeedRebase.primaryDefectSystem) :=
  SchurDtnDerivedSeedRebase.primary_closure_status


theorem derived_seed_symmetric_case_unresolved :
    SchurDtnDerivedSeedRebase.symmetricDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      SchurDtnDerivedSeedRebase.symmetricDefectSystem :=
  SchurDtnDerivedSeedRebase.symmetric_status


theorem concrete_symmetric_cut_g1_static_unresolved :
    ConcreteSymmetricCutG1Test.symmetricConcreteDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      ConcreteSymmetricCutG1Test.symmetricConcreteDefectSystem :=
  ConcreteSymmetricCutG1Test.symmetric_concrete_status


theorem concrete_symmetric_cut_g1_does_not_break_sign :
    ConcreteSymmetricCutG1Test.staticSymmetricConcreteCutDoesNotBreakSign :=
  ConcreteSymmetricCutG1Test.static_symmetric_concrete_cut_does_not_break_sign


theorem concrete_growth_irreversibility_g1_closes_conditionally :
    ConcreteGrowthIrreversibilityG1Test.growthIrreversibilityDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      ConcreteGrowthIrreversibilityG1Test.growthIrreversibilityDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        ConcreteGrowthIrreversibilityG1Test.growthIrreversibilityDefectSystem) :=
  ConcreteGrowthIrreversibilityG1Test.growth_irreversibility_status


theorem concrete_reversible_growth_g1_does_not_break_sign :
    ConcreteGrowthIrreversibilityG1Test.reversibleControlDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      ConcreteGrowthIrreversibilityG1Test.reversibleControlDefectSystem :=
  ConcreteGrowthIrreversibilityG1Test.reversible_control_status


theorem local_growth_edge_is_derived_from_address_rule :
    GrowthEdgeProvenance.localGrowthEdgeDerivedFromAddressRule :=
  GrowthEdgeProvenance.local_growth_edge_derived_from_address_rule


theorem local_growth_edge_g1_closes :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  GrowthEdgeProvenance.derived_growth_status


theorem inactive_growth_edge_g1_does_not_break_sign :
    GrowthEdgeProvenance.inactiveControlDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.inactiveControlDefectSystem :=
  GrowthEdgeProvenance.inactive_control_status


theorem local_growth_criterion_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      GrowthEdgeProvenance.activeAddressGrowthRule 0 2 = true :=
  LocalGrowthEdgeCriterion.active_criterion_forward_edge


theorem local_growth_criterion_backward_edge :
    GrowthEdgeProvenance.growthAdjacent
      GrowthEdgeProvenance.activeAddressGrowthRule 2 0 = true :=
  LocalGrowthEdgeCriterion.active_criterion_backward_edge


theorem local_growth_criterion_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  LocalGrowthEdgeCriterion.active_criterion_closes_g1


theorem local_growth_criterion_remains_node2_local :
    LocalGrowthEdgeCriterion.criterionStillLocalNode2 :=
  LocalGrowthEdgeCriterion.criterion_still_local_node2


theorem address_growth_criterion_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      GrowthEdgeProvenance.activeAddressGrowthRule 0 2 = true :=
  AddressGrowthEdgeCriterion.active_address_criterion_forward_edge


theorem address_growth_criterion_backward_edge :
    GrowthEdgeProvenance.growthAdjacent
      GrowthEdgeProvenance.activeAddressGrowthRule 2 0 = true :=
  AddressGrowthEdgeCriterion.active_address_criterion_backward_edge


theorem address_growth_criterion_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  AddressGrowthEdgeCriterion.active_address_criterion_closes_g1


theorem address_growth_criterion_remains_local_seed :
    AddressGrowthEdgeCriterion.addressCriterionStillLocalSeed :=
  AddressGrowthEdgeCriterion.address_criterion_still_local_seed


theorem generic_address_growth_criterion_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (GenericAddressGrowthCriterion.toLocalGrowthRule
        GenericAddressGrowthCriterion.activeGenericSeed) 0 2 = true :=
  GenericAddressGrowthCriterion.active_generic_seed_forward_edge


theorem generic_address_growth_criterion_backward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (GenericAddressGrowthCriterion.toLocalGrowthRule
        GenericAddressGrowthCriterion.activeGenericSeed) 2 0 = true :=
  GenericAddressGrowthCriterion.active_generic_seed_backward_edge


theorem generic_address_growth_criterion_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  GenericAddressGrowthCriterion.active_generic_seed_closes_g1


theorem generic_address_growth_criterion_remains_current_address_type :
    GenericAddressGrowthCriterion.genericCriterionStillCurrentAddressType :=
  GenericAddressGrowthCriterion.generic_criterion_still_current_address_type


theorem abstract_address_type_growth_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        AbstractAddressTypeGrowthCriterion.currentAbstractSeed) 0 2 = true :=
  AbstractAddressTypeGrowthCriterion.current_abstract_seed_forward_edge


theorem abstract_address_type_growth_backward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        AbstractAddressTypeGrowthCriterion.currentAbstractSeed) 2 0 = true :=
  AbstractAddressTypeGrowthCriterion.current_abstract_seed_backward_edge


theorem abstract_address_type_growth_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  AbstractAddressTypeGrowthCriterion.current_abstract_seed_closes_g1


theorem abstract_address_type_growth_remains_node_numbered :
    AbstractAddressTypeGrowthCriterion.abstractCriterionStillNodeNumbered :=
  AbstractAddressTypeGrowthCriterion.abstract_criterion_still_node_numbered


theorem canonical_port_numbering_role_nodes :
    CanonicalPortNumberingCriterion.canonicalNodeOfCurrent
      SchurDtnDerivedAddressSeed.cutRoot = 0 ∧
    CanonicalPortNumberingCriterion.canonicalNodeOfCurrent
      SchurDtnDerivedAddressSeed.selectedChild = 1 ∧
    CanonicalPortNumberingCriterion.canonicalNodeOfCurrent
      SchurDtnDerivedAddressSeed.frontierPortAddress = 2 :=
  CanonicalPortNumberingCriterion.canonical_nodeOf_matches_current_on_roles


theorem canonical_port_numbering_growth_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        CanonicalPortNumberingCriterion.currentCanonicalAbstractSeed) 0 2 = true :=
  CanonicalPortNumberingCriterion.canonical_port_numbering_forward_edge


theorem canonical_port_numbering_growth_backward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        CanonicalPortNumberingCriterion.currentCanonicalAbstractSeed) 2 0 = true :=
  CanonicalPortNumberingCriterion.canonical_port_numbering_backward_edge


theorem canonical_port_numbering_growth_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  CanonicalPortNumberingCriterion.canonical_port_numbering_closes_g1


theorem canonical_port_numbering_remains_local_role_order :
    CanonicalPortNumberingCriterion.canonicalPortNumberingStillLocalRoleOrder :=
  CanonicalPortNumberingCriterion.canonical_port_numbering_still_local_role_order


theorem canonical_role_order_role_nodes :
    CanonicalRoleOrderCriterion.currentRoleOrderNodeOf
      SchurDtnDerivedAddressSeed.cutRoot = 0 ∧
    CanonicalRoleOrderCriterion.currentRoleOrderNodeOf
      SchurDtnDerivedAddressSeed.selectedChild = 1 ∧
    CanonicalRoleOrderCriterion.currentRoleOrderNodeOf
      SchurDtnDerivedAddressSeed.frontierPortAddress = 2 :=
  CanonicalRoleOrderCriterion.current_role_order_nodes


theorem canonical_role_order_matches_port_numbering :
    CanonicalRoleOrderCriterion.currentRoleOrderNodeOf =
      CanonicalPortNumberingCriterion.canonicalNodeOfCurrent :=
  CanonicalRoleOrderCriterion.current_role_order_nodeOf_eq_canonical_nodeOf


theorem canonical_role_order_growth_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        CanonicalRoleOrderCriterion.currentRoleOrderAbstractSeed) 0 2 = true :=
  CanonicalRoleOrderCriterion.canonical_role_order_forward_edge


theorem canonical_role_order_growth_backward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        CanonicalRoleOrderCriterion.currentRoleOrderAbstractSeed) 2 0 = true :=
  CanonicalRoleOrderCriterion.canonical_role_order_backward_edge


theorem canonical_role_order_growth_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  CanonicalRoleOrderCriterion.canonical_role_order_closes_g1


theorem canonical_role_order_remains_local_interface_roles :
    CanonicalRoleOrderCriterion.canonicalRoleOrderStillLocalInterfaceRoles :=
  CanonicalRoleOrderCriterion.canonical_role_order_still_local_interface_roles


theorem canonical_fill_order_role_nodes :
    CanonicalFillOrderCriterion.currentFillRankNodeOf
      SchurDtnDerivedAddressSeed.cutRoot = 0 ∧
    CanonicalFillOrderCriterion.currentFillRankNodeOf
      SchurDtnDerivedAddressSeed.selectedChild = 1 ∧
    CanonicalFillOrderCriterion.currentFillRankNodeOf
      SchurDtnDerivedAddressSeed.frontierPortAddress = 2 :=
  And.intro CanonicalFillOrderCriterion.current_fill_cut_root_node_zero
    (And.intro CanonicalFillOrderCriterion.current_fill_selected_node_one
      CanonicalFillOrderCriterion.current_fill_frontier_node_two)


theorem canonical_fill_order_matches_role_order :
    CanonicalFillOrderCriterion.currentFillRankNodeOf =
      CanonicalRoleOrderCriterion.currentRoleOrderNodeOf :=
  CanonicalFillOrderCriterion.current_fill_rank_nodeOf_eq_role_order_nodeOf


theorem canonical_fill_order_growth_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        CanonicalFillOrderCriterion.currentFillAbstractSeed) 0 2 = true :=
  CanonicalFillOrderCriterion.canonical_fill_order_forward_edge


theorem canonical_fill_order_reversal_frontier_rank_changes :
    CanonicalFillOrderCriterion.reversalChangesFillFrontierRank :=
  CanonicalFillOrderCriterion.reversal_changes_fill_frontier_rank


theorem canonical_fill_order_remains_local_endpoint_classification :
    CanonicalFillOrderCriterion.fillOrderStillLocalEndpointClassification :=
  CanonicalFillOrderCriterion.fill_order_still_local_endpoint_classification


theorem fill_endpoint_derivation_role_endpoints :
    FillEndpointDerivationCriterion.currentDerivedEndpointOfRole =
      CanonicalFillOrderCriterion.fillEndpointOfRole :=
  FillEndpointDerivationCriterion.current_derived_endpoint_eq_fill_endpoint


theorem fill_endpoint_derivation_nodeOf_matches_fill_order :
    FillEndpointDerivationCriterion.currentDerivedFillRankNodeOf =
      CanonicalFillOrderCriterion.currentFillRankNodeOf :=
  FillEndpointDerivationCriterion.current_derived_fill_nodeOf_eq_fill_order_nodeOf


theorem fill_endpoint_derivation_role_nodes :
    FillEndpointDerivationCriterion.currentDerivedFillRankNodeOf
      SchurDtnDerivedAddressSeed.cutRoot = 0 ∧
    FillEndpointDerivationCriterion.currentDerivedFillRankNodeOf
      SchurDtnDerivedAddressSeed.selectedChild = 1 ∧
    FillEndpointDerivationCriterion.currentDerivedFillRankNodeOf
      SchurDtnDerivedAddressSeed.frontierPortAddress = 2 :=
  And.intro
    FillEndpointDerivationCriterion.current_derived_fill_cut_root_node_zero
    (And.intro
      FillEndpointDerivationCriterion.current_derived_fill_selected_node_one
      FillEndpointDerivationCriterion.current_derived_fill_frontier_node_two)


theorem fill_endpoint_derivation_growth_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        FillEndpointDerivationCriterion.currentDerivedFillAbstractSeed) 0 2 = true :=
  FillEndpointDerivationCriterion.derived_fill_endpoint_forward_edge


theorem fill_endpoint_derivation_reversal_frontier_rank_rejected :
    FillEndpointDerivationCriterion.derivedFillReversalRejectsFrontierZero :=
  FillEndpointDerivationCriterion.derived_fill_reversal_rejects_frontier_zero


theorem fill_endpoint_derivation_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  FillEndpointDerivationCriterion.derived_fill_endpoint_closes_g1


theorem fill_endpoint_derivation_remains_local_cut_fill_data :
    FillEndpointDerivationCriterion.endpointDerivationStillLocalCutFillData :=
  FillEndpointDerivationCriterion.endpoint_derivation_still_local_cut_fill_data


theorem fill_dynamics_rank_endpoint_matches_cut_fill_endpoint :
    FillDynamicsRankCriterion.currentDynamicEndpointOfRole =
      FillEndpointDerivationCriterion.currentDerivedEndpointOfRole :=
  FillDynamicsRankCriterion.current_dynamic_endpoint_eq_cut_fill_endpoint


theorem fill_dynamics_rank_endpoint_matches_fill_endpoint :
    FillDynamicsRankCriterion.currentDynamicEndpointOfRole =
      CanonicalFillOrderCriterion.fillEndpointOfRole :=
  FillDynamicsRankCriterion.current_dynamic_endpoint_eq_fill_endpoint


theorem fill_dynamics_rank_nodeOf_matches_fill_order :
    FillDynamicsRankCriterion.currentDynamicFillRankNodeOf =
      CanonicalFillOrderCriterion.currentFillRankNodeOf :=
  FillDynamicsRankCriterion.current_dynamic_fill_nodeOf_eq_fill_order_nodeOf


theorem fill_dynamics_rank_role_nodes :
    FillDynamicsRankCriterion.currentDynamicFillRankNodeOf
      SchurDtnDerivedAddressSeed.cutRoot = 0 ∧
    FillDynamicsRankCriterion.currentDynamicFillRankNodeOf
      SchurDtnDerivedAddressSeed.selectedChild = 1 ∧
    FillDynamicsRankCriterion.currentDynamicFillRankNodeOf
      SchurDtnDerivedAddressSeed.frontierPortAddress = 2 :=
  And.intro
    FillDynamicsRankCriterion.current_dynamic_fill_cut_root_node_zero
    (And.intro
      FillDynamicsRankCriterion.current_dynamic_fill_selected_node_one
      FillDynamicsRankCriterion.current_dynamic_fill_frontier_node_two)


theorem fill_dynamics_rank_growth_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        FillDynamicsRankCriterion.currentDynamicFillAbstractSeed) 0 2 = true :=
  FillDynamicsRankCriterion.dynamic_fill_rank_forward_edge


theorem fill_dynamics_rank_reversal_frontier_rank_rejected :
    FillDynamicsRankCriterion.dynamicFillRankReversalRejectsFrontierZero :=
  FillDynamicsRankCriterion.dynamic_fill_rank_reversal_rejects_frontier_zero


theorem fill_dynamics_rank_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  FillDynamicsRankCriterion.dynamic_fill_rank_closes_g1


theorem fill_dynamics_rank_remains_local_three_phase_profile :
    FillDynamicsRankCriterion.dynamicRankStillLocalThreePhaseProfile :=
  FillDynamicsRankCriterion.dynamic_rank_still_local_three_phase_profile


theorem frontier_rank_profile_rank_matches_dynamic_rank :
    FrontierRankProfileCriterion.currentFrontierProfileRank =
      FillDynamicsRankCriterion.dynamicRankFromCutFillData
        FillEndpointDerivationCriterion.currentCutFillEndpointData :=
  FrontierRankProfileCriterion.current_frontier_profile_rank_eq_dynamic_rank


theorem frontier_rank_profile_endpoint_matches_dynamic_endpoint :
    FrontierRankProfileCriterion.currentFrontierProfileEndpoint =
      FillDynamicsRankCriterion.dynamicEndpointFromCutFillData
        FillEndpointDerivationCriterion.currentCutFillEndpointData :=
  FrontierRankProfileCriterion.current_frontier_profile_endpoint_eq_dynamic_endpoint


theorem frontier_rank_profile_nodeOf_matches_dynamic_nodeOf :
    FrontierRankProfileCriterion.currentFrontierProfileNodeOf =
      FillDynamicsRankCriterion.currentDynamicFillRankNodeOf :=
  FrontierRankProfileCriterion.current_frontier_profile_nodeOf_eq_dynamic_nodeOf


theorem frontier_rank_profile_nodeOf_matches_fill_order :
    FrontierRankProfileCriterion.currentFrontierProfileNodeOf =
      CanonicalFillOrderCriterion.currentFillRankNodeOf :=
  FrontierRankProfileCriterion.current_frontier_profile_nodeOf_eq_fill_order_nodeOf


theorem frontier_rank_profile_phases :
    FrontierRankProfileCriterion.phaseFromFrontierProfile
      FrontierRankProfileCriterion.currentFrontierRankProfile
      SchurDtnDerivedAddressSeed.cutRoot =
      FrontierRankProfileCriterion.FillPhase.source ∧
    FrontierRankProfileCriterion.phaseFromFrontierProfile
      FrontierRankProfileCriterion.currentFrontierRankProfile
      SchurDtnDerivedAddressSeed.selectedChild =
      FrontierRankProfileCriterion.FillPhase.transit ∧
    FrontierRankProfileCriterion.phaseFromFrontierProfile
      FrontierRankProfileCriterion.currentFrontierRankProfile
      SchurDtnDerivedAddressSeed.frontierPortAddress =
      FrontierRankProfileCriterion.FillPhase.activeFrontier :=
  And.intro
    FrontierRankProfileCriterion.current_phase_cut_root_source
    (And.intro
      FrontierRankProfileCriterion.current_phase_selected_transit
      FrontierRankProfileCriterion.current_phase_frontier_active)


theorem frontier_rank_profile_role_nodes :
    FrontierRankProfileCriterion.currentFrontierProfileNodeOf
      SchurDtnDerivedAddressSeed.cutRoot = 0 ∧
    FrontierRankProfileCriterion.currentFrontierProfileNodeOf
      SchurDtnDerivedAddressSeed.selectedChild = 1 ∧
    FrontierRankProfileCriterion.currentFrontierProfileNodeOf
      SchurDtnDerivedAddressSeed.frontierPortAddress = 2 :=
  And.intro
    FrontierRankProfileCriterion.current_frontier_profile_cut_root_node_zero
    (And.intro
      FrontierRankProfileCriterion.current_frontier_profile_selected_node_one
      FrontierRankProfileCriterion.current_frontier_profile_frontier_node_two)


theorem frontier_rank_profile_growth_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        FrontierRankProfileCriterion.currentFrontierProfileAbstractSeed) 0 2 = true :=
  FrontierRankProfileCriterion.frontier_profile_forward_edge


theorem frontier_rank_profile_reversal_frontier_rank_rejected :
    FrontierRankProfileCriterion.frontierProfileReversalRejectsFrontierZero :=
  FrontierRankProfileCriterion.frontier_profile_reversal_rejects_frontier_zero


theorem frontier_rank_profile_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  FrontierRankProfileCriterion.frontier_profile_closes_g1


theorem frontier_rank_profile_remains_local_phase_classifier :
    FrontierRankProfileCriterion.frontierProfileStillLocalPhaseClassifier :=
  FrontierRankProfileCriterion.frontier_profile_still_local_phase_classifier


theorem frontier_phase_certificate_phases :
    FrontierPhaseCertificateCriterion.certifiedPhase
      FrontierPhaseCertificateCriterion.currentFrontierPhaseCertificate
      SchurDtnDerivedAddressSeed.cutRoot =
      FrontierRankProfileCriterion.FillPhase.source ∧
    FrontierPhaseCertificateCriterion.certifiedPhase
      FrontierPhaseCertificateCriterion.currentFrontierPhaseCertificate
      SchurDtnDerivedAddressSeed.selectedChild =
      FrontierRankProfileCriterion.FillPhase.transit ∧
    FrontierPhaseCertificateCriterion.certifiedPhase
      FrontierPhaseCertificateCriterion.currentFrontierPhaseCertificate
      SchurDtnDerivedAddressSeed.frontierPortAddress =
      FrontierRankProfileCriterion.FillPhase.activeFrontier :=
  And.intro
    FrontierPhaseCertificateCriterion.current_certificate_phase_cut_root_source
    (And.intro
      FrontierPhaseCertificateCriterion.current_certificate_phase_selected_transit
      FrontierPhaseCertificateCriterion.current_certificate_phase_frontier_active)


theorem frontier_phase_certificate_ranks :
    FrontierPhaseCertificateCriterion.certifiedRank
      FrontierPhaseCertificateCriterion.currentFrontierPhaseCertificate
      SchurDtnDerivedAddressSeed.cutRoot = 0 ∧
    FrontierPhaseCertificateCriterion.certifiedRank
      FrontierPhaseCertificateCriterion.currentFrontierPhaseCertificate
      SchurDtnDerivedAddressSeed.selectedChild = 1 ∧
    FrontierPhaseCertificateCriterion.certifiedRank
      FrontierPhaseCertificateCriterion.currentFrontierPhaseCertificate
      SchurDtnDerivedAddressSeed.frontierPortAddress = 2 :=
  And.intro
    FrontierPhaseCertificateCriterion.current_certificate_rank_cut_root_zero
    (And.intro
      FrontierPhaseCertificateCriterion.current_certificate_rank_selected_one
      FrontierPhaseCertificateCriterion.current_certificate_rank_frontier_two)


theorem frontier_phase_certificate_nodeOf_matches_frontier_profile :
    FrontierPhaseCertificateCriterion.currentCertifiedNodeOf =
      FrontierRankProfileCriterion.currentFrontierProfileNodeOf :=
  FrontierPhaseCertificateCriterion.current_certified_nodeOf_eq_frontier_profile_nodeOf


theorem frontier_phase_certificate_nodeOf_matches_fill_order :
    FrontierPhaseCertificateCriterion.currentCertifiedNodeOf =
      CanonicalFillOrderCriterion.currentFillRankNodeOf :=
  FrontierPhaseCertificateCriterion.current_certified_nodeOf_eq_fill_order_nodeOf


theorem frontier_phase_certificate_role_nodes :
    FrontierPhaseCertificateCriterion.currentCertifiedNodeOf
      SchurDtnDerivedAddressSeed.cutRoot = 0 ∧
    FrontierPhaseCertificateCriterion.currentCertifiedNodeOf
      SchurDtnDerivedAddressSeed.selectedChild = 1 ∧
    FrontierPhaseCertificateCriterion.currentCertifiedNodeOf
      SchurDtnDerivedAddressSeed.frontierPortAddress = 2 :=
  And.intro
    FrontierPhaseCertificateCriterion.current_certificate_cut_root_node_zero
    (And.intro
      FrontierPhaseCertificateCriterion.current_certificate_selected_node_one
      FrontierPhaseCertificateCriterion.current_certificate_frontier_node_two)


theorem frontier_phase_certificate_growth_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        FrontierPhaseCertificateCriterion.currentCertificateAbstractSeed) 0 2 = true :=
  FrontierPhaseCertificateCriterion.certificate_profile_forward_edge


theorem frontier_phase_certificate_reversal_frontier_rank_rejected :
    FrontierPhaseCertificateCriterion.frontierPhaseCertificateReversalRejectsFrontierZero :=
  FrontierPhaseCertificateCriterion.frontier_phase_certificate_reversal_rejects_frontier_zero


theorem frontier_phase_certificate_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  FrontierPhaseCertificateCriterion.frontier_phase_certificate_closes_g1


theorem frontier_phase_certificate_remains_local_witness_record :
    FrontierPhaseCertificateCriterion.frontierPhaseCertificateStillLocalWitnessRecord :=
  FrontierPhaseCertificateCriterion.frontier_phase_certificate_still_local_witness_record


theorem frontier_event_phase_bridge_residual_event_active :
    SchurDtnFrontierEventActivationProvenance.eventActive
      SchurDtnFrontierEventActivationProvenance.residualExtensionRecordNode2 =
      true :=
  FrontierEventPhaseBridgeCriterion.residual_event_active


theorem frontier_event_phase_bridge_matches_frontier_phase :
    SchurDtnFrontierEventActivationProvenance.eventActive
      SchurDtnFrontierEventActivationProvenance.residualExtensionRecordNode2 =
    FrontierRankProfileCriterion.activeFrontierPhase
      FrontierRankProfileCriterion.currentFrontierRankProfile
      SchurDtnDerivedAddressSeed.frontierPortAddress :=
  FrontierEventPhaseBridgeCriterion.residual_event_matches_current_active_frontier_phase


theorem frontier_event_phase_bridge_inside_control :
    SchurDtnFrontierEventActivationProvenance.eventActive
      SchurDtnFrontierEventActivationProvenance.insideTargetRecordNode2 =
    FrontierRankProfileCriterion.activeFrontierPhase
      FrontierRankProfileCriterion.currentFrontierRankProfile
      SchurDtnDerivedAddressSeed.selectedChild :=
  FrontierEventPhaseBridgeCriterion.inside_event_matches_current_selected_non_frontier_phase


theorem frontier_event_phase_bridge_inactive_control_exposes_gap :
    FrontierEventPhaseBridgeCriterion.inactiveEventShowsEdgePresentNotInPhase :=
  FrontierEventPhaseBridgeCriterion.inactive_event_shows_edge_present_not_in_phase


theorem frontier_event_phase_bridge_nodeOf_matches_fill_order :
    FrontierEventPhaseBridgeCriterion.currentEventBackedNodeOf =
      CanonicalFillOrderCriterion.currentFillRankNodeOf :=
  FrontierEventPhaseBridgeCriterion.current_event_backed_nodeOf_eq_fill_order_nodeOf


theorem frontier_event_phase_bridge_growth_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        FrontierEventPhaseBridgeCriterion.currentEventBackedAbstractSeed) 0 2 = true :=
  FrontierEventPhaseBridgeCriterion.event_backed_phase_forward_edge


theorem frontier_event_phase_bridge_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  FrontierEventPhaseBridgeCriterion.event_backed_phase_closes_g1


theorem frontier_event_phase_bridge_remains_current_compatibility_layer :
    FrontierEventPhaseBridgeCriterion.eventPhaseBridgeStillCurrentCompatibilityLayer :=
  FrontierEventPhaseBridgeCriterion.event_phase_bridge_still_current_compatibility_layer


theorem fill_orbit_basin_frontier_flows_to_selected :
    CanonicalFillOrderCriterion.localFillMap 2
      (FillOrbitBasinCriterion.currentFillValue
        SchurDtnDerivedAddressSeed.frontierPortAddress) =
      FillOrbitBasinCriterion.currentFillValue
        SchurDtnDerivedAddressSeed.selectedChild :=
  FillOrbitBasinCriterion.current_frontier_fill_value_flows_to_selected_value


theorem fill_orbit_basin_frontier_code_separation :
    FillOrbitBasinCriterion.frontierFlowsToSelectedButEndpointCodeIsTwo :=
  FillOrbitBasinCriterion.frontier_flows_to_selected_but_endpoint_code_is_two


theorem fill_orbit_basin_residual_event_has_orbit_witness :
    FillOrbitBasinCriterion.residualEventHasOrbitWitness :=
  FillOrbitBasinCriterion.residual_event_has_orbit_witness


theorem fill_orbit_basin_nodeOf_matches_fill_order :
    FillOrbitBasinCriterion.currentOrbitNodeOf =
      CanonicalFillOrderCriterion.currentFillRankNodeOf :=
  FillOrbitBasinCriterion.current_orbit_nodeOf_eq_fill_order_nodeOf


theorem fill_orbit_basin_growth_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        FillOrbitBasinCriterion.currentOrbitAbstractSeed) 0 2 = true :=
  FillOrbitBasinCriterion.orbit_basin_forward_edge


theorem fill_orbit_basin_closes_g1_path :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  FillOrbitBasinCriterion.orbit_basin_closes_g1_path


theorem fill_orbit_basin_keeps_inactive_event_gap :
    FrontierEventPhaseBridgeCriterion.inactiveEventShowsEdgePresentNotInPhase :=
  FillOrbitBasinCriterion.orbit_basin_keeps_inactive_event_gap


theorem fill_orbit_basin_remains_local_diagnostic :
    FillOrbitBasinCriterion.fillOrbitBasinStillLocalDiagnostic :=
  FillOrbitBasinCriterion.fill_orbit_basin_still_local_diagnostic


theorem fill_orbit_endpoint_code_dynamic_separation :
    FillOrbitEndpointCodeCriterion.frontierInflowDynamicSeparation :=
  FillOrbitEndpointCodeCriterion.current_frontier_inflow_dynamic_separation


theorem fill_orbit_endpoint_code_legacy_attractor_code :
    FillOrbitEndpointCodeCriterion.frontierInflowUsesLegacyAttractorCode :=
  FillOrbitEndpointCodeCriterion.frontier_inflow_uses_legacy_attractor_code


theorem fill_orbit_endpoint_code_nodeOf_matches_orbit_basin :
    FillOrbitEndpointCodeCriterion.currentNodeOfFromOrbitFlow =
      FillOrbitBasinCriterion.currentOrbitNodeOf :=
  FillOrbitEndpointCodeCriterion.current_orbit_flow_nodeOf_eq_orbit_nodeOf


theorem fill_orbit_endpoint_code_nodeOf_matches_fill_order :
    FillOrbitEndpointCodeCriterion.currentNodeOfFromOrbitFlow =
      CanonicalFillOrderCriterion.currentFillRankNodeOf :=
  FillOrbitEndpointCodeCriterion.current_orbit_flow_nodeOf_eq_fill_order_nodeOf


theorem fill_orbit_endpoint_code_growth_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        FillOrbitEndpointCodeCriterion.currentOrbitFlowAbstractSeed) 0 2 = true :=
  FillOrbitEndpointCodeCriterion.orbit_flow_forward_edge


theorem fill_orbit_endpoint_code_closes_g1_path :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  FillOrbitEndpointCodeCriterion.orbit_flow_closes_g1_path


theorem fill_orbit_endpoint_code_remains_local_semantics_bridge :
    FillOrbitEndpointCodeCriterion.fillOrbitEndpointCodeStillLocalSemanticsBridge :=
  FillOrbitEndpointCodeCriterion.fill_orbit_endpoint_code_still_local_semantics_bridge


theorem fill_orbit_cycle_bridge_local_path_zero :
    Circulation.csum FillOrbitCycleBridgeCriterion.orbitCmp
      FillOrbitCycleBridgeCriterion.currentAddressFlowPath = 0 :=
  FillOrbitCycleBridgeCriterion.current_address_flow_path_circulation_zero


theorem fill_orbit_cycle_bridge_closure_cycle_nonzero :
    Circulation.csum FillOrbitCycleBridgeCriterion.orbitCmp
      FillOrbitCycleBridgeCriterion.currentClosedCycleWithReturnToCutRoot = -1 :=
  FillOrbitCycleBridgeCriterion.current_closed_cycle_with_return_circulation_neg_one


theorem fill_orbit_cycle_bridge_reversed_cycle_positive :
    Circulation.csum FillOrbitCycleBridgeCriterion.orbitCmp
      FillOrbitCycleBridgeCriterion.reversedClosedOrbitCycle = 1 :=
  FillOrbitCycleBridgeCriterion.reversed_closed_orbit_cycle_circulation_one


theorem fill_orbit_cycle_bridge_line_not_orientation :
    FillOrbitCycleBridgeCriterion.localFlowLineNotCycleOrientation :=
  FillOrbitCycleBridgeCriterion.local_flow_line_not_cycle_orientation


theorem fill_orbit_cycle_bridge_frontier_inflow_no_path_circulation :
    FillOrbitCycleBridgeCriterion.frontierInflowAndLocalPathHaveNoCirculation :=
  FillOrbitCycleBridgeCriterion.frontier_inflow_and_local_path_have_no_circulation


theorem fill_orbit_cycle_bridge_nonzero_requires_closure :
    FillOrbitCycleBridgeCriterion.nonzeroCirculationRequiresCycleClosure :=
  FillOrbitCycleBridgeCriterion.nonzero_circulation_requires_cycle_closure


theorem fill_orbit_cycle_bridge_closure_still_global_input :
    FillOrbitCycleBridgeCriterion.cycleClosureStillGlobalGluingInput :=
  FillOrbitCycleBridgeCriterion.cycle_closure_still_global_gluing_input


theorem fill_orbit_cycle_bridge_remains_diagnostic :
    FillOrbitCycleBridgeCriterion.fillOrbitCycleBridgeStillDiagnostic :=
  FillOrbitCycleBridgeCriterion.fill_orbit_cycle_bridge_still_diagnostic


theorem cycle_circulation_gate_triangle_nonzero :
    Circulation.csum Circulation.cmpH
      CycleCirculationGate.growthTriangle = 1 :=
  CycleCirculationGate.triangle_circulation


theorem cycle_circulation_gate_triangle_gradient_zero :
    Circulation.csum
      (CycleCirculationGate.gradOf Circulation.height)
      CycleCirculationGate.growthTriangle = 0 :=
  CycleCirculationGate.triangle_circulation_is_coboundary.2


theorem cycle_circulation_gate_triangle_is_coboundary :
    Circulation.csum Circulation.cmpH
      CycleCirculationGate.growthTriangle = 1 ∧
    Circulation.csum
      (CycleCirculationGate.gradOf Circulation.height)
      CycleCirculationGate.growthTriangle = 0 :=
  CycleCirculationGate.triangle_circulation_is_coboundary


theorem cycle_circulation_gate_kappa_axis_bound :
    Circulation.csum Circulation.cmpH
      CycleCirculationGate.growthTriangle = 1 ∧
    Circulation.csum CycleCirculationGate.cmpHKappa
      CycleCirculationGate.growthTriangle = -1 ∧
    Circulation.csum Circulation.cmpH
      CycleCirculationGate.growthTriangle ≠
    Circulation.csum CycleCirculationGate.cmpHKappa
      CycleCirculationGate.growthTriangle :=
  CycleCirculationGate.orientation_axis_bound


theorem cycle_circulation_gate_no_go :
    Circulation.csum Circulation.cmpH
      CycleCirculationGate.growthTriangle = 1 ∧
    Circulation.csum
      (CycleCirculationGate.gradOf Circulation.height)
      CycleCirculationGate.growthTriangle = 0 ∧
    Circulation.csum Circulation.cmpH
      CycleCirculationGate.growthTriangle ≠
    Circulation.csum CycleCirculationGate.cmpHKappa
      CycleCirculationGate.growthTriangle :=
  CycleCirculationGate.cycle_gate_no_go


theorem cycle_circulation_gate_height_coboundary_marker :
    CycleCirculationGate.circulationFromHeightIsAlwaysCoboundary :=
  CycleCirculationGate.circulation_from_height_is_always_coboundary


theorem schur_cut_spectral_tower_condition_profile :
    SchurCutSpectralTowerCriterion.conditionNumberProfile =
      [1, 3, 7, 15, 31, 63, 127, 255] :=
  SchurCutSpectralTowerCriterion.condition_number_profile_matches_binary_schur_cut_register


theorem schur_cut_spectral_tower_min_denominator_profile :
    SchurCutSpectralTowerCriterion.minEigenDenominatorProfile =
      SchurCutSpectralTowerCriterion.conditionNumberProfile :=
  SchurCutSpectralTowerCriterion.min_eigen_denominator_profile_matches_condition_profile


theorem schur_cut_spectral_tower_soft_count_profile :
    SchurCutSpectralTowerCriterion.softBelowTenthCountProfile =
      [0, 0, 0, 1, 3, 7, 15, 31] :=
  SchurCutSpectralTowerCriterion.soft_below_tenth_count_profile_matches_register


theorem schur_cut_spectral_tower_stage8_refines_stage7 :
    SchurCutSpectralTowerCriterion.stage8.conditionNumber =
      2 * SchurCutSpectralTowerCriterion.stage7.conditionNumber + 1 :=
  SchurCutSpectralTowerCriterion.stage8_condition_number_refines_stage7


theorem schur_cut_spectral_tower_symmetric_kappa_stage7 :
    SchurCutSpectralTowerCriterion.stage7.kappaPreservesSymmetricShells = true ∧
    SchurCutSpectralTowerCriterion.stage7.kappaPreservesSoftProjectorSurrogate = true :=
  SchurCutSpectralTowerCriterion.symmetric_kappa_preserves_stage7_shells


theorem schur_cut_spectral_tower_remains_finite_dtn_register :
    SchurCutSpectralTowerCriterion.schurCutSpectrumStillFiniteDtNRegister :=
  SchurCutSpectralTowerCriterion.schur_cut_spectrum_still_finite_dtn_register


theorem schur_cut_spectral_tower_remains_pre_von_neumann :
    SchurCutSpectralTowerCriterion.schurCutSpectrumStillPreVonNeumann :=
  SchurCutSpectralTowerCriterion.schur_cut_spectrum_still_pre_von_neumann


theorem schur_cut_spectral_tower_symmetric_soft_sector_kappa_blind :
    SchurCutSpectralTowerCriterion.symmetricSoftSectorStillKappaBlind :=
  SchurCutSpectralTowerCriterion.symmetric_soft_sector_still_kappa_blind


theorem ancestor_kernel_inverse_square_fails_shell_control_at_level_four :
    AncestorBackreactionKernelCriterion.shellControlledAt
      AncestorBackreactionKernelCriterion.inverseSquareDenominator 4 = false :=
  AncestorBackreactionKernelCriterion.inverse_square_fails_shell_control_at_level_four


theorem ancestor_kernel_shell_norm_controls_registered_shells :
    AncestorBackreactionKernelCriterion.shellNormInverseSquareControlProfile =
      [true, true, true, true, true, true, true, true] :=
  AncestorBackreactionKernelCriterion.shell_norm_inverse_square_controls_registered_shells


theorem ancestor_kernel_shell_norm_extra_damping_profile :
    AncestorBackreactionKernelCriterion.shellNormInverseSquareExtraDampingProfile =
      [1, 4, 9, 16, 25, 36, 49, 64] :=
  AncestorBackreactionKernelCriterion.shell_norm_inverse_square_extra_damping_profile


theorem ancestor_kernel_shell_norm_is_tower_candidate :
    (AncestorBackreactionKernelCriterion.shellNormInverseSquareKernelRecord)
        .intendedForTowerExtrapolation = true ∧
    (AncestorBackreactionKernelCriterion.shellNormInverseSquareKernelRecord)
        .controlsRegisteredRemoteShells = true ∧
    (AncestorBackreactionKernelCriterion.shellNormInverseSquareKernelRecord)
        .hasPolynomialExtraDamping = true :=
  AncestorBackreactionKernelCriterion.shell_norm_inverse_square_is_tower_candidate


theorem ancestor_kernel_remains_response_criterion :
    AncestorBackreactionKernelCriterion.ancestorKernelStillResponseCriterion :=
  AncestorBackreactionKernelCriterion.ancestor_kernel_still_response_criterion


theorem ancestor_kernel_remains_pre_operator_tower :
    AncestorBackreactionKernelCriterion.kernelCriterionStillPreOperatorTower :=
  AncestorBackreactionKernelCriterion.kernel_criterion_still_pre_operator_tower

end GeneratorSpine
