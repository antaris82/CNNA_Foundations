import CNNA.DirichletInverseWitness

/-
  ConcreteMatrixArithmetic.lean
  -----------------------------
  Erste konkrete arithmetische Matrixschicht fuer den Dirichlet-Inversen-Port.

  Diese Datei bleibt absichtlich klein: sie formalisiert konkrete 1-mal-1-
  Matrixarithmetik ueber Nat und erzeugt daraus echte algebraische
  Zwei-Seiten-Inversen-Zeugen fuer die vorhandene DirichletInverseWitness-
  Schicht.

  Kein Matrix.inv, kein freier Selector, kein freies Gewicht, kein
  J-Vorzeichen-Claim.
-/

namespace ConcreteMatrixArithmetic

abbrev Matrix (m n : Nat) := DirichletInverseWitness.Matrix m n
abbrev MatrixAlgebra (n : Nat) := DirichletInverseWitness.MatrixAlgebra n
abbrev AlgebraicTwoSidedInverse {n : Nat} (A : MatrixAlgebra n)
    (L R : Matrix n n) :=
  DirichletInverseWitness.AlgebraicTwoSidedInverse A L R
abbrev RawSchurBlocks (V : Type) := DirichletInverseWitness.RawSchurBlocks V
abbrev CertifiedSchurBlocks (V : Type) :=
  DirichletInverseWitness.CertifiedSchurBlocks V

/-- 1-mal-1-Skalarmatrix. -/
def scalar1 (a : Nat) : Matrix 1 1 :=
  fun _ _ => a

/-- 1-mal-1-Einsmatrix. -/
def one1 : Matrix 1 1 :=
  scalar1 1

/-- Konkretes 1-mal-1-Matrixprodukt. -/
def mul1 (A B : Matrix 1 1) : Matrix 1 1 :=
  fun _ _ => A 0 0 * B 0 0

/-- Konkrete 1-mal-1-Matrixalgebra. -/
def algebra1 : MatrixAlgebra 1 :=
  { mul := mul1,
    one := one1 }

/-- Produkt zweier 1-mal-1-Skalarmatrizen. -/
theorem mul1_scalar (a b : Nat) :
    mul1 (scalar1 a) (scalar1 b) = scalar1 (a * b) := rfl

/-- Die 1-mal-1-Einsmatrix ist ihr eigener beidseitiger Inverser. -/
def oneInverseWitness1 : AlgebraicTwoSidedInverse algebra1 one1 one1 :=
  { left_eq := rfl,
    right_eq := rfl }

/-- Allgemeiner 1-mal-1-Skalar-Inversenzeugnis: Wenn a*r=1 und r*a=1, dann
    sind die zugehoerigen 1-mal-1-Matrizen beidseitige Inverse. -/
def scalarInverseWitness1 (a r : Nat) (hL : a * r = 1) (hR : r * a = 1) :
    AlgebraicTwoSidedInverse algebra1 (scalar1 a) (scalar1 r) :=
  { left_eq := by
      funext i
      funext j
      exact hL,
    right_eq := by
      funext i
      funext j
      exact hR }

/-- Rohe Schur-Bloecke mit einem konkreten 1-mal-1-Interiorblock a und
    Kandidaten r. -/
def rawScalar1Blocks {V : Type} (cut : FiniteGraphLaplacianBlocks.FiniteCut V)
    (boundaryDim LBBTrace couplingTrace cutDefect a r : Nat) :
    RawSchurBlocks V :=
  { cut := cut,
    boundaryDim := boundaryDim,
    interiorDim := 1,
    LBBTrace := LBBTrace,
    couplingTrace := couplingTrace,
    cutDefect := cutDefect,
    LII := scalar1 a,
    candidateInverse := scalar1 r }

/-- Zertifizierte Schur-Bloecke aus konkreter 1-mal-1-Arithmetik. -/
def certifiedScalar1Blocks {V : Type}
    (cut : FiniteGraphLaplacianBlocks.FiniteCut V)
    (boundaryDim LBBTrace couplingTrace cutDefect a r : Nat)
    (hL : a * r = 1) (hR : r * a = 1) : CertifiedSchurBlocks V :=
  DirichletInverseWitness.fromRaw
    (rawScalar1Blocks cut boundaryDim LBBTrace couplingTrace cutDefect a r)
    algebra1
    (scalarInverseWitness1 a r hL hR)

/-- Spezialfall mit Interiorblock 1. -/
def certifiedOne1Blocks {V : Type}
    (cut : FiniteGraphLaplacianBlocks.FiniteCut V)
    (boundaryDim LBBTrace couplingTrace cutDefect : Nat) :
    CertifiedSchurBlocks V :=
  certifiedScalar1Blocks cut boundaryDim LBBTrace couplingTrace cutDefect
    1 1 rfl rfl

/-- Die zertifizierten 1-mal-1-Bloecke tragen den rohen Interior-Dimensionseintrag 1. -/
theorem certifiedScalar1_interiorDim {V : Type}
    (cut : FiniteGraphLaplacianBlocks.FiniteCut V)
    (boundaryDim LBBTrace couplingTrace cutDefect a r : Nat)
    (hL : a * r = 1) (hR : r * a = 1) :
    (certifiedScalar1Blocks cut boundaryDim LBBTrace couplingTrace cutDefect
      a r hL hR).raw.interiorDim = 1 := rfl

/-- Der algebraische Witness-Port akzeptiert den konkreten 1-mal-1-Zeugen. -/
theorem certifiedScalar1_left_certified {V : Type}
    (cut : FiniteGraphLaplacianBlocks.FiniteCut V)
    (boundaryDim LBBTrace couplingTrace cutDefect a r : Nat)
    (hL : a * r = 1) (hR : r * a = 1) :
    (DirichletInverseWitness.toInvertibleSchurBlocks
      (certifiedScalar1Blocks cut boundaryDim LBBTrace couplingTrace cutDefect
        a r hL hR)).inv.leftCertified = true := rfl

/-- Der rechte Witness-Port ist ebenfalls zertifiziert. -/
theorem certifiedScalar1_right_certified {V : Type}
    (cut : FiniteGraphLaplacianBlocks.FiniteCut V)
    (boundaryDim LBBTrace couplingTrace cutDefect a r : Nat)
    (hL : a * r = 1) (hR : r * a = 1) :
    (DirichletInverseWitness.toInvertibleSchurBlocks
      (certifiedScalar1Blocks cut boundaryDim LBBTrace couplingTrace cutDefect
        a r hL hR)).inv.rightCertified = true := rfl

/-- Der konkrete 1-mal-1-Port laeuft exakt in die vorhandene SchurSummary-Schicht. -/
theorem certifiedScalar1_toDefectVector_link {V : Type}
    (beforeCut afterCut : FiniteGraphLaplacianBlocks.FiniteCut V)
    (beforeBoundary afterBoundary : Nat)
    (beforeLBB afterLBB beforeCoupling afterCoupling : Nat)
    (beforeCutDefect afterCutDefect : Nat)
    (a₁ r₁ a₂ r₂ : Nat)
    (hL₁ : a₁ * r₁ = 1) (hR₁ : r₁ * a₁ = 1)
    (hL₂ : a₂ * r₂ = 1) (hR₂ : r₂ * a₂ = 1) :
    DirichletInverseWitness.toDefectVector
      (certifiedScalar1Blocks beforeCut beforeBoundary beforeLBB beforeCoupling
        beforeCutDefect a₁ r₁ hL₁ hR₁)
      (certifiedScalar1Blocks afterCut afterBoundary afterLBB afterCoupling
        afterCutDefect a₂ r₂ hL₂ hR₂)
    =
    FiniteMatrixSchurPort.toDefectVector
      (DirichletInverseWitness.toInvertibleSchurBlocks
        (certifiedScalar1Blocks beforeCut beforeBoundary beforeLBB beforeCoupling
          beforeCutDefect a₁ r₁ hL₁ hR₁))
      (DirichletInverseWitness.toInvertibleSchurBlocks
        (certifiedScalar1Blocks afterCut afterBoundary afterLBB afterCoupling
          afterCutDefect a₂ r₂ hL₂ hR₂)) := rfl

/-- Marker: Diese Datei liefert konkrete 1-mal-1-Arithmetik, aber noch keine
    allgemeine Matrixarithmetik und kein J-Vorzeichen. -/
def generalMatrixArithmeticStillOpen : Prop := True

theorem j_sign_gate_not_closed_here : generalMatrixArithmeticStillOpen :=
  True.intro

end ConcreteMatrixArithmetic
