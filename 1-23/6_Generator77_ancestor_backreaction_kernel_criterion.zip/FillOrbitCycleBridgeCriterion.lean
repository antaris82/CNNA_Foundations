import CNNA.FillOrbitEndpointCodeCriterion
import CNNA.Circulation

namespace FillOrbitCycleBridgeCriterion

abbrev OrbitNode := Fin 3
abbrev CurrentAddress := SchurDtnDerivedAddressSeed.Address


def orbitHeight : OrbitNode -> Int
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | _ => 0


def orbitCmp (a b : OrbitNode) : Int :=
  let d := orbitHeight b - orbitHeight a
  if d > 0 then 1 else if d < 0 then -1 else 0


theorem orbit_cmp_anti : ∀ a b : OrbitNode, orbitCmp a b = - orbitCmp b a := by
  decide


def currentNode (a : CurrentAddress) : OrbitNode :=
  FillOrbitEndpointCodeCriterion.currentNodeOfFromOrbitFlow a


theorem current_node_cut_root_zero :
    currentNode SchurDtnDerivedAddressSeed.cutRoot = 0 := rfl


theorem current_node_selected_one :
    currentNode SchurDtnDerivedAddressSeed.selectedChild = 1 := rfl


theorem current_node_frontier_two :
    currentNode SchurDtnDerivedAddressSeed.frontierPortAddress = 2 := by
  change currentNode
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) = 2
  rfl


def localOrbitFlowPath : Circulation.Edges OrbitNode :=
  [(0, 2), (2, 1)]


def currentAddressFlowPath : Circulation.Edges OrbitNode :=
  [ (currentNode SchurDtnDerivedAddressSeed.cutRoot,
      currentNode SchurDtnDerivedAddressSeed.frontierPortAddress),
    (currentNode SchurDtnDerivedAddressSeed.frontierPortAddress,
      currentNode SchurDtnDerivedAddressSeed.selectedChild) ]


theorem current_address_flow_path_eq_local_orbit_flow_path :
    currentAddressFlowPath = localOrbitFlowPath := by
  unfold currentAddressFlowPath localOrbitFlowPath currentNode
  change [(0, 2), (2, 1)] = [(0, 2), (2, 1)]
  rfl


theorem local_orbit_flow_path_circulation_zero :
    Circulation.csum orbitCmp localOrbitFlowPath = 0 := by
  decide


theorem current_address_flow_path_circulation_zero :
    Circulation.csum orbitCmp currentAddressFlowPath = 0 := by
  rw [current_address_flow_path_eq_local_orbit_flow_path]
  exact local_orbit_flow_path_circulation_zero


def returnEdgeToCutRoot : Circulation.Edges OrbitNode :=
  [(1, 0)]


def closedOrbitCycleWithReturnToZero : Circulation.Edges OrbitNode :=
  [(0, 2), (2, 1), (1, 0)]


def reversedClosedOrbitCycle : Circulation.Edges OrbitNode :=
  [(0, 1), (1, 2), (2, 0)]


def currentClosedCycleWithReturnToCutRoot : Circulation.Edges OrbitNode :=
  [ (currentNode SchurDtnDerivedAddressSeed.cutRoot,
      currentNode SchurDtnDerivedAddressSeed.frontierPortAddress),
    (currentNode SchurDtnDerivedAddressSeed.frontierPortAddress,
      currentNode SchurDtnDerivedAddressSeed.selectedChild),
    (currentNode SchurDtnDerivedAddressSeed.selectedChild,
      currentNode SchurDtnDerivedAddressSeed.cutRoot) ]


theorem current_closed_cycle_eq_return_to_zero_cycle :
    currentClosedCycleWithReturnToCutRoot = closedOrbitCycleWithReturnToZero := by
  unfold currentClosedCycleWithReturnToCutRoot closedOrbitCycleWithReturnToZero currentNode
  change [(0, 2), (2, 1), (1, 0)] = [(0, 2), (2, 1), (1, 0)]
  rfl


theorem return_edge_circulation_neg_one :
    Circulation.csum orbitCmp returnEdgeToCutRoot = -1 := by
  decide


theorem closed_orbit_cycle_with_return_circulation_neg_one :
    Circulation.csum orbitCmp closedOrbitCycleWithReturnToZero = -1 := by
  decide


theorem reversed_closed_orbit_cycle_circulation_one :
    Circulation.csum orbitCmp reversedClosedOrbitCycle = 1 := by
  decide


theorem current_closed_cycle_with_return_circulation_neg_one :
    Circulation.csum orbitCmp currentClosedCycleWithReturnToCutRoot = -1 := by
  rw [current_closed_cycle_eq_return_to_zero_cycle]
  exact closed_orbit_cycle_with_return_circulation_neg_one


def localFlowLineNotCycleOrientation : Prop :=
  Circulation.csum orbitCmp localOrbitFlowPath = 0 ∧
  Circulation.csum orbitCmp closedOrbitCycleWithReturnToZero = -1 ∧
  Circulation.csum orbitCmp reversedClosedOrbitCycle = 1


theorem local_flow_line_not_cycle_orientation :
    localFlowLineNotCycleOrientation :=
  And.intro local_orbit_flow_path_circulation_zero
    (And.intro closed_orbit_cycle_with_return_circulation_neg_one
      reversed_closed_orbit_cycle_circulation_one)


def frontierInflowAndLocalPathHaveNoCirculation : Prop :=
  FillOrbitEndpointCodeCriterion.frontierInflowDynamicSeparation ∧
  Circulation.csum orbitCmp currentAddressFlowPath = 0


theorem frontier_inflow_and_local_path_have_no_circulation :
    frontierInflowAndLocalPathHaveNoCirculation :=
  And.intro
    FillOrbitEndpointCodeCriterion.current_frontier_inflow_dynamic_separation
    current_address_flow_path_circulation_zero


def nonzeroCirculationRequiresCycleClosure : Prop :=
  Circulation.csum orbitCmp currentAddressFlowPath = 0 ∧
  Circulation.csum orbitCmp currentClosedCycleWithReturnToCutRoot = -1


theorem nonzero_circulation_requires_cycle_closure :
    nonzeroCirculationRequiresCycleClosure :=
  And.intro current_address_flow_path_circulation_zero
    current_closed_cycle_with_return_circulation_neg_one


def cycleClosureStillGlobalGluingInput : Prop := True


theorem cycle_closure_still_global_gluing_input :
    cycleClosureStillGlobalGluingInput :=
  True.intro


def fillOrbitCycleBridgeStillDiagnostic : Prop := True


theorem fill_orbit_cycle_bridge_still_diagnostic :
    fillOrbitCycleBridgeStillDiagnostic :=
  True.intro

end FillOrbitCycleBridgeCriterion
