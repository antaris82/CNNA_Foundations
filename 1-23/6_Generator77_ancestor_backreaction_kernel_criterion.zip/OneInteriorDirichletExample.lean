import CNNA.ConcreteMatrixArithmetic

/-
  OneInteriorDirichletExample.lean
  --------------------------------
  Erster vollstaendiger Mini-Pfad durch den Generator-Spine:

    konkreter endlicher Cut mit einem Interior-Knoten
      -> LII = [1], R = [1]
      -> konkreter 1-mal-1-Inversenzeuge
      -> CertifiedSchurBlocks
      -> SchurSummary
      -> CutSummary
      -> HandoffData
      -> DefectVector.

  Kein Matrix.inv, kein freier Selector, kein freies Gewicht, kein
  J-Vorzeichen-Claim. Dieser Baustein zeigt nur, dass der untere
  Dirichlet-Schur-Port in einem konkreten Mini-Fall durchlaeuft.
-/

namespace OneInteriorDirichletExample

abbrev Node := Fin 2
abbrev FiniteCut := FiniteGraphLaplacianBlocks.FiniteCut Node
abbrev CertifiedSchurBlocks := DirichletInverseWitness.CertifiedSchurBlocks Node

/-- Ungerichtete Ein-Kanten-Inzidenz zwischen Boundary-Knoten 0 und
    Interior-Knoten 1. -/
def edge01 (x y : Node) : Bool :=
  ((x == 0) && (y == 1)) || ((x == 1) && (y == 0))

/-- Konkreter Cut: ein Boundary-Knoten und ein Interior-Knoten. Die UV- und
    Environment-Loads sind hier gleich gross, damit der Balance-Defekt im
    Self-Handoff verschwindet. -/
def oneInteriorCut : FiniteCut :=
  { boundary := [0],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    complementNodes := [],
    adjacent := edge01 }

/-- Der konkrete Cut hat genau einen Interior-Knoten. -/
theorem oneInteriorCut_interior_length : oneInteriorCut.interior.length = 1 := rfl

/-- Der konkrete Cut hat genau einen Boundary-Knoten. -/
theorem oneInteriorCut_boundary_length : oneInteriorCut.boundary.length = 1 := rfl

/-- Die Kombinatorikschicht sieht keinen leeren Interior-Cut. -/
theorem oneInteriorCut_graphCutDefect_zero :
    FiniteGraphLaplacianBlocks.graphCutDefect oneInteriorCut = 0 := rfl

/-- Konkrete Schur-Bloecke mit Interiorblock [1] und Inversenkandidat [1]. -/
def oneInteriorBlocks : CertifiedSchurBlocks :=
  ConcreteMatrixArithmetic.certifiedOne1Blocks oneInteriorCut
    1 1 0 0

/-- Der konkrete 1-mal-1-Port ist links zertifiziert. -/
theorem oneInterior_left_certified :
    (DirichletInverseWitness.toInvertibleSchurBlocks oneInteriorBlocks).inv.leftCertified = true := rfl

/-- Der konkrete 1-mal-1-Port ist rechts zertifiziert. -/
theorem oneInterior_right_certified :
    (DirichletInverseWitness.toInvertibleSchurBlocks oneInteriorBlocks).inv.rightCertified = true := rfl

/-- Die CertifiedSchurBlocks tragen den rohen Interior-Dimensionseintrag 1. -/
theorem oneInterior_raw_interior_dim :
    oneInteriorBlocks.raw.interiorDim = 1 := rfl

/-- Der konkrete Mini-Port laeuft durch die Matrix-Schur-Port-Schicht. -/
theorem oneInterior_to_matrix_port_link :
    DirichletInverseWitness.toDefectVector oneInteriorBlocks oneInteriorBlocks =
      FiniteMatrixSchurPort.toDefectVector
        (DirichletInverseWitness.toInvertibleSchurBlocks oneInteriorBlocks)
        (DirichletInverseWitness.toInvertibleSchurBlocks oneInteriorBlocks) := rfl

/-- Der konkrete Mini-Port laeuft bis zur Handoff-Summary-Schicht. -/
theorem oneInterior_to_summary_link :
    DirichletInverseWitness.toDefectVector oneInteriorBlocks oneInteriorBlocks =
      FiniteHandoffSummary.toDefectVector
        (DirichletInverseWitness.toCutSummary oneInteriorBlocks)
        (DirichletInverseWitness.toCutSummary oneInteriorBlocks) := rfl

/-- Der Self-Handoff hat stabilen Schur-Trace und daher keinen DtN-Defekt. -/
theorem oneInterior_dtn_defect_zero :
    FiniteHandoffSummary.dtnDefect
      (DirichletInverseWitness.toHandoffData oneInteriorBlocks oneInteriorBlocks) = 0 :=
  DirichletInverseWitness.dtn_defect_zero_of_same_trace
    oneInteriorBlocks oneInteriorBlocks rfl

/-- Im Self-Handoff dieses Mini-Cuts ist der Defektvektor der Nullvektor. -/
theorem oneInterior_defect_vector_zero :
    DirichletInverseWitness.toDefectVector oneInteriorBlocks oneInteriorBlocks =
      [0, 0, 0, 0, 0] := rfl

/-- Marker: Der Mini-Pfad schliesst den konkreten 1-mal-1-Dirichletport, aber
    nicht das J-Vorzeichen. -/
def jSignStillOpen : Prop := True

theorem j_sign_gate_not_closed_here : jSignStillOpen := True.intro

end OneInteriorDirichletExample
