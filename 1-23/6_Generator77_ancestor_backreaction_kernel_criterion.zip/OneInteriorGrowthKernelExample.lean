import CNNA.OneInteriorDirichletExample
import CNNA.CanonicalGrowthKernel

/-
  OneInteriorGrowthKernelExample.lean
  -----------------------------------
  Verknuepft den konkreten 1-mal-1-Dirichlet-Schur-Miniport mit dem
  parameterfreien Pareto- und Sektorkernel aus CanonicalGrowthKernel.lean.

  Ziel:

    konkreter Cut -> DefectVector -> DefectSystem -> ParetoMin -> SectorKernel.

  Kein freier Selector, kein freies Gewicht, kein Tie-Break, kein
  J-Vorzeichen-Claim. Bei eindeutiger Minimierermenge entsteht der
  deterministische Spezialfall. Bei zwei gleich guten Kandidaten bleibt die
  kanonische Antwort eine Sektormenge.
-/

namespace OneInteriorGrowthKernelExample

abbrev Attachment := Unit

/-- Der einzige Attachment-Kandidat des konkreten Miniports. -/
def onlyAttachment : Attachment := ()

/-- Der konkrete Defektvektor des gruenen 1-mal-1-Dirichlet-Schur-Miniports. -/
def oneInteriorDefectVector : List Nat :=
  DirichletInverseWitness.toDefectVector
    OneInteriorDirichletExample.oneInteriorBlocks
    OneInteriorDirichletExample.oneInteriorBlocks

/-- Der konkrete Miniport liefert den Null-Defektvektor. -/
theorem oneInteriorDefectVector_zero :
    oneInteriorDefectVector = [0, 0, 0, 0, 0] :=
  OneInteriorDirichletExample.oneInterior_defect_vector_zero

/-- Defektsystem mit genau einem Attachment-Kandidaten. -/
def oneInteriorDefectSystem : CanonicalGrowthKernel.DefectSystem Attachment :=
  { candidates := [onlyAttachment],
    defect := fun _ => [0, 0, 0, 0, 0] }

/-- Die Defektfunktion des Defektsystems ist der konkrete Miniport-Defekt. -/
theorem oneInteriorDefectSystem_defect_link (a : Attachment) :
    oneInteriorDefectSystem.defect a = oneInteriorDefectVector := by
  rw [oneInteriorDefectVector_zero]
  rfl

/-- Der konkrete Miniport hat genau eine kanonische Minimierermenge. -/
theorem oneInterior_minSet_singleton :
    oneInteriorDefectSystem.minSet = [onlyAttachment] := rfl

/-- Daher hat der kanonische Growth-Kernel Masse 1. -/
theorem oneInterior_kernel_one :
    oneInteriorDefectSystem.kernel = 1 :=
  CanonicalGrowthKernel.DefectSystem.unique_kernel_one
    oneInteriorDefectSystem onlyAttachment oneInterior_minSet_singleton

/-- Der eindeutige Kandidat hat Sektorgewicht 1. -/
theorem oneInterior_sector_one :
    oneInteriorDefectSystem.sector onlyAttachment = 1 :=
  CanonicalGrowthKernel.unique_min_sector_one
    oneInteriorDefectSystem.defect oneInteriorDefectSystem.candidates
    onlyAttachment oneInterior_minSet_singleton

/-! ## Symmetrie-Kontrolle: zwei gleiche Miniport-Kandidaten -/

/-- Zwei gleichwertige Kopien desselben Miniport-Defekts. -/
def symmetricTwoDefectSystem : CanonicalGrowthKernel.DefectSystem Bool :=
  { candidates := [false, true],
    defect := fun _ => [0, 0, 0, 0, 0] }

/-- Bei zwei exakt gleichen Defekten gibt es keinen freien Tie-Break: beide
    Kandidaten bleiben in der kanonischen Sektormenge. -/
theorem symmetricTwo_minSet :
    symmetricTwoDefectSystem.minSet = [false, true] := rfl

/-- Die Sektormasse ist 2, nicht ein willkuerlich ausgewaehlter Selector. -/
theorem symmetricTwo_kernel_two :
    symmetricTwoDefectSystem.kernel = 2 :=
  CanonicalGrowthKernel.DefectSystem.two_sector_kernel
    symmetricTwoDefectSystem false true symmetricTwo_minSet

/-- Der erste gleichwertige Kandidat hat Sektorgewicht 1. -/
theorem symmetricTwo_sector_false :
    symmetricTwoDefectSystem.sector false = 1 :=
  CanonicalGrowthKernel.sectorKernel_one_of_mem
    symmetricTwoDefectSystem.defect symmetricTwoDefectSystem.candidates false
    (by
      change false ∈ symmetricTwoDefectSystem.minSet
      rw [symmetricTwo_minSet]
      simp)

/-- Der zweite gleichwertige Kandidat hat Sektorgewicht 1. -/
theorem symmetricTwo_sector_true :
    symmetricTwoDefectSystem.sector true = 1 :=
  CanonicalGrowthKernel.sectorKernel_one_of_mem
    symmetricTwoDefectSystem.defect symmetricTwoDefectSystem.candidates true
    (by
      change true ∈ symmetricTwoDefectSystem.minSet
      rw [symmetricTwo_minSet]
      simp)

/-- Marker: Dieser Baustein schliesst den konkreten Mini-Cut bis zum
    Growth-Sektorkernel. Er schliesst nicht das J-Vorzeichen. -/
def jSignStillOpen : Prop := True

theorem j_sign_gate_not_closed_here : jSignStillOpen := True.intro

end OneInteriorGrowthKernelExample
