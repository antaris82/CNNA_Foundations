import CNNA.SchurDtnStrictPreferenceCriterion

namespace SchurDtnComplementProvenance

abbrev Node := Fin 3
abbrev FiniteCut := FiniteGraphLaplacianBlocks.FiniteCut Node
abbrev CertifiedSchurBlocks := DirichletInverseWitness.CertifiedSchurBlocks Node
abbrev SchurSummary := SchurDtnSummary.SchurSummary Node
abbrev DefectSystem := SectorResolutionGate.DefectSystem

structure PortCutProvenance (V : Type) where
  supportNodes : List V
  boundary : List V
  interior : List V
  uvBoundary : List V
  envBoundary : List V
  recordNodes : List V
  adjacent : V -> V -> Bool


def contains {V : Type} [BEq V] (x : V) : List V -> Bool
  | [] => false
  | y :: ys => if x == y then true else contains x ys


def residualNodes {V : Type} (isRole : V -> Bool) : List V -> List V
  | [] => []
  | x :: xs =>
      if isRole x then residualNodes isRole xs
      else x :: residualNodes isRole xs


def roleNodes {V : Type} (p : PortCutProvenance V) : List V :=
  p.boundary ++ p.interior ++ p.uvBoundary ++ p.envBoundary ++ p.recordNodes


def isRoleNode {V : Type} [BEq V] (p : PortCutProvenance V) (x : V) : Bool :=
  contains x (roleNodes p)


def complementNodes {V : Type} [BEq V] (p : PortCutProvenance V) : List V :=
  residualNodes (isRoleNode p) p.supportNodes


def toFiniteCut {V : Type} [BEq V] (p : PortCutProvenance V) :
    FiniteCutCombinatorics.FiniteCut V :=
  { boundary := p.boundary,
    interior := p.interior,
    uvBoundary := p.uvBoundary,
    envBoundary := p.envBoundary,
    recordNodes := p.recordNodes,
    complementNodes := complementNodes p,
    adjacent := p.adjacent }


theorem toFiniteCut_complementNodes {V : Type} [BEq V]
    (p : PortCutProvenance V) :
    (toFiniteCut p).complementNodes = complementNodes p := rfl


theorem toFiniteCut_boundary {V : Type} [BEq V]
    (p : PortCutProvenance V) :
    (toFiniteCut p).boundary = p.boundary := rfl


theorem toFiniteCut_interior {V : Type} [BEq V]
    (p : PortCutProvenance V) :
    (toFiniteCut p).interior = p.interior := rfl


def edge01 (x y : Node) : Bool :=
  ((x == 0) && (y == 1)) || ((x == 1) && (y == 0))


def beforeProvenance : PortCutProvenance Node :=
  { supportNodes := [0, 1],
    boundary := [0],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    adjacent := edge01 }


def plusAfterProvenance : PortCutProvenance Node :=
  beforeProvenance


def minusAfterProvenance : PortCutProvenance Node :=
  { supportNodes := [0, 1, 2],
    boundary := [0],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    adjacent := edge01 }


theorem before_complement_nodes_empty :
    complementNodes beforeProvenance = [] := rfl


theorem plus_complement_nodes_empty :
    complementNodes plusAfterProvenance = [] := rfl


theorem minus_complement_nodes_derived :
    complementNodes minusAfterProvenance = [2] := rfl


def beforeCut : FiniteCut :=
  toFiniteCut beforeProvenance


def plusAfterCut : FiniteCut :=
  toFiniteCut plusAfterProvenance


def minusAfterCut : FiniteCut :=
  toFiniteCut minusAfterProvenance


theorem before_cut_complement_empty :
    beforeCut.complementNodes = [] := rfl


theorem plus_cut_complement_empty :
    plusAfterCut.complementNodes = [] := rfl


theorem minus_cut_complement_derived :
    minusAfterCut.complementNodes = [2] := rfl


theorem before_complement_signature_zero :
    FiniteCutCombinatorics.complementSignature beforeCut = 0 := rfl


theorem plus_complement_signature_zero :
    FiniteCutCombinatorics.complementSignature plusAfterCut = 0 := rfl


theorem minus_complement_signature_one :
    FiniteCutCombinatorics.complementSignature minusAfterCut = 1 := rfl


def certifiedBlocks (c : FiniteCut) : CertifiedSchurBlocks :=
  ConcreteMatrixArithmetic.certifiedOne1Blocks c
    c.boundary.length
    (FiniteGraphLaplacianBlocks.LBBTrace c)
    (FiniteGraphLaplacianBlocks.couplingTrace c)
    (FiniteGraphLaplacianBlocks.graphCutDefect c)


def beforeBlocks : CertifiedSchurBlocks :=
  certifiedBlocks beforeCut


def plusAfterBlocks : CertifiedSchurBlocks :=
  certifiedBlocks plusAfterCut


def minusAfterBlocks : CertifiedSchurBlocks :=
  certifiedBlocks minusAfterCut


def beforeSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary beforeBlocks


def plusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary plusAfterBlocks


def minusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary minusAfterBlocks


def plusComputedDefectVector : List Nat :=
  DirichletInverseWitness.toDefectVector beforeBlocks plusAfterBlocks


def minusComputedDefectVector : List Nat :=
  DirichletInverseWitness.toDefectVector beforeBlocks minusAfterBlocks


theorem plus_computed_defect_vector_zero :
    plusComputedDefectVector = [0, 0, 0, 0, 0] := rfl


theorem minus_computed_defect_vector_from_provenance :
    minusComputedDefectVector = [0, 0, 0, 0, 1] := rfl


def provenanceDefectSystem : DefectSystem Bool :=
  SchurStrictPreferenceBridge.schurCutHandoffDefectSystem
    beforeSummary plusAfterSummary minusAfterSummary


theorem provenance_false_defect :
    provenanceDefectSystem.defect false = [0, 0, 0, 0, 0] := rfl


theorem provenance_true_defect :
    provenanceDefectSystem.defect true = [0, 0, 0, 0, 1] := rfl


theorem provenance_minSet_singleton :
    provenanceDefectSystem.minSet = [false] := rfl


theorem provenance_kernel_one :
    provenanceDefectSystem.kernel = 1 :=
  CanonicalGrowthKernel.DefectSystem.unique_kernel_one
    provenanceDefectSystem false provenance_minSet_singleton


def provenanceSchurStrictPreference :
    SchurStrictPreferenceBridge.SchurStrictPreference
      beforeSummary plusAfterSummary minusAfterSummary :=
  { minSet_singleton := provenance_minSet_singleton }


theorem provenance_resolved_j_sign :
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      provenanceDefectSystem :=
  SchurStrictPreferenceBridge.resolved_of_schur_strict_preference
    beforeSummary plusAfterSummary minusAfterSummary
    provenanceSchurStrictPreference


theorem provenance_locks_eq_plusSector :
    SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      provenanceDefectSystem = JSignClosureCriterion.plusSector := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    SchurStrictPreferenceBridge.schurSectorMap
    CutStrictPreferenceBridge.cutSectorMap
    HandoffStrictPreferenceBridge.handoffSectorMap
    GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.plusSector
  rw [provenance_minSet_singleton]
  rfl


theorem provenance_not_flip_closed :
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        provenanceDefectSystem) := by
  intro hclosed
  rw [provenance_locks_eq_plusSector] at hclosed
  exact SymmetryBreakingClosureGate.plusSector_not_closed_under_flip hclosed


theorem provenance_closure_status :
    provenanceDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      provenanceDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        provenanceDefectSystem) :=
  And.intro provenance_kernel_one
    (And.intro provenance_resolved_j_sign provenance_not_flip_closed)


def symmetricMinusAfterProvenance : PortCutProvenance Node :=
  plusAfterProvenance


def symmetricMinusAfterCut : FiniteCut :=
  toFiniteCut symmetricMinusAfterProvenance


def symmetricMinusAfterBlocks : CertifiedSchurBlocks :=
  certifiedBlocks symmetricMinusAfterCut


def symmetricMinusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary symmetricMinusAfterBlocks


def symmetricDefectSystem : DefectSystem Bool :=
  SchurStrictPreferenceBridge.schurCutHandoffDefectSystem
    beforeSummary plusAfterSummary symmetricMinusAfterSummary


theorem symmetric_false_defect :
    symmetricDefectSystem.defect false = [0, 0, 0, 0, 0] := rfl


theorem symmetric_true_defect :
    symmetricDefectSystem.defect true = [0, 0, 0, 0, 0] := rfl


theorem symmetric_minSet_pair :
    symmetricDefectSystem.minSet = [false, true] := rfl


theorem symmetric_kernel_two :
    symmetricDefectSystem.kernel = 2 :=
  CanonicalGrowthKernel.DefectSystem.two_sector_kernel
    symmetricDefectSystem false true symmetric_minSet_pair


theorem symmetric_locks_eq_twoSectors :
    SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      symmetricDefectSystem = JSignClosureCriterion.twoSectors := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    SchurStrictPreferenceBridge.schurSectorMap
    CutStrictPreferenceBridge.cutSectorMap
    HandoffStrictPreferenceBridge.handoffSectorMap
    GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.twoSectors
  rw [symmetric_minSet_pair]
  rfl


theorem symmetric_not_resolved_j_sign :
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem := by
  change ¬ JSignClosureCriterion.hasClosedJSign
    (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      symmetricDefectSystem)
  rw [symmetric_locks_eq_twoSectors]
  exact JSignClosureCriterion.twoSectors_no_closed_j_sign


theorem symmetric_status :
    symmetricDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem :=
  And.intro symmetric_kernel_two symmetric_not_resolved_j_sign


def supportProvenanceStillNeedsDerivation : Prop := True


theorem support_provenance_still_needs_derivation :
    supportProvenanceStillNeedsDerivation :=
  True.intro

end SchurDtnComplementProvenance
