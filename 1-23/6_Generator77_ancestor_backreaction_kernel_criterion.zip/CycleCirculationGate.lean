import CNNA.Circulation


namespace CycleCirculationGate

open Circulation


def walkEdges {V : Type} : List V → Edges V
  | []            => []
  | [_]           => []
  | a :: b :: rest => (a, b) :: walkEdges (b :: rest)


def lastOf {V : Type} : V → List V → V
  | a, []          => a
  | _, b :: rest   => lastOf b rest


def closedWalkEdges {V : Type} (a : V) (rest : List V) : Edges V :=
  walkEdges (a :: rest) ++ [(lastOf a rest, a)]


def gradOf {V : Type} (h : V → Int) (a b : V) : Int := h b - h a


theorem csum_append {V : Type} (cmp : V → V → Int) :
    ∀ es fs : Edges V, csum cmp (es ++ fs) = csum cmp es + csum cmp fs := by
  intro es fs
  induction es with
  | nil => simp
  | cons e es ih =>
      cases e with
      | mk a b =>
          show
            csum cmp ((a, b) :: (es ++ fs)) =
              csum cmp ((a, b) :: es) + csum cmp fs
          rw [csum_cons, csum_cons, ih]
          omega


theorem csum_grad_walk_telescope {V : Type} (h : V → Int) :
    ∀ (a : V) (rest : List V),
      csum (gradOf h) (walkEdges (a :: rest))
        = h (lastOf a rest) - h a := by
  intro a rest
  induction rest generalizing a with
  | nil =>
      show csum (gradOf h) [] = h a - h a
      rw [csum_nil]; omega
  | cons b rest ih =>
      show csum (gradOf h) ((a, b) :: walkEdges (b :: rest))
            = h (lastOf a (b :: rest)) - h a
      rw [csum_cons, ih b]
      show gradOf h a b + (h (lastOf b rest) - h b)
            = h (lastOf b rest) - h a
      unfold gradOf
      omega


theorem grad_telescopes_closed {V : Type} (h : V → Int) (a : V) (rest : List V) :
    csum (gradOf h) (closedWalkEdges a rest) = 0 := by
  unfold closedWalkEdges
  rw [csum_append, csum_grad_walk_telescope h a rest]
  show (h (lastOf a rest) - h a)
        + (gradOf h (lastOf a rest) a + 0) = 0
  unfold gradOf
  omega


def growthTriangle : Edges (Fin 5) := [(0, 3), (3, 4), (4, 0)]


theorem triangle_circulation : csum Circulation.cmpH growthTriangle = 1 := by
  decide


theorem triangle_circulation_reversed :
    csum (fun a b => Circulation.cmpH b a) growthTriangle = -1 := by
  decide


theorem growthTriangle_grad_zero :
    csum (gradOf Circulation.height) (closedWalkEdges (0 : Fin 5) [3, 4]) = 0 :=
  grad_telescopes_closed Circulation.height 0 [3, 4]


theorem closedWalk_eq_growthTriangle :
    closedWalkEdges (0 : Fin 5) [3, 4] = growthTriangle := by
  decide


theorem triangle_circulation_is_coboundary :
    csum Circulation.cmpH growthTriangle = 1 ∧
    csum (gradOf Circulation.height) growthTriangle = 0 := by
  refine And.intro triangle_circulation ?_
  rw [← closedWalk_eq_growthTriangle]
  exact growthTriangle_grad_zero


def heightKappa : Fin 5 → Int
  | 3 => 2
  | 4 => 1
  | _ => 0

def cmpHKappa (a b : Fin 5) : Int :=
  let d := heightKappa b - heightKappa a
  if d > 0 then 1 else if d < 0 then -1 else 0


theorem triangle_circulation_kappa :
    csum cmpHKappa growthTriangle = -1 := by decide


theorem orientation_axis_bound :
    csum Circulation.cmpH growthTriangle = 1 ∧
    csum cmpHKappa growthTriangle = -1 ∧
    csum Circulation.cmpH growthTriangle ≠ csum cmpHKappa growthTriangle := by
  refine And.intro triangle_circulation (And.intro triangle_circulation_kappa ?_)
  rw [triangle_circulation, triangle_circulation_kappa]
  decide


theorem cycle_gate_no_go :
    (csum Circulation.cmpH growthTriangle = 1) ∧
    (csum (gradOf Circulation.height) growthTriangle = 0) ∧
    (csum Circulation.cmpH growthTriangle ≠ csum cmpHKappa growthTriangle) :=
  And.intro triangle_circulation
    (And.intro triangle_circulation_is_coboundary.2
      orientation_axis_bound.2.2)


def circulationFromHeightIsAlwaysCoboundary : Prop := True

theorem circulation_from_height_is_always_coboundary :
    circulationFromHeightIsAlwaysCoboundary :=
  True.intro

end CycleCirculationGate
