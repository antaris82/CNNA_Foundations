import CNNA.FillDynamicsRankCriterion

namespace FrontierRankProfileCriterion

abbrev Node := Fin 3
abbrev CurrentAddress := SchurDtnDerivedAddressSeed.Address
abbrev FillEndpoint := CanonicalFillOrderCriterion.FillEndpoint
abbrev CutFillEndpointData :=
  FillEndpointDerivationCriterion.CutFillEndpointData
abbrev AbstractAddressSeed := AbstractAddressTypeGrowthCriterion.AbstractAddressSeed
abbrev CurrentSeedCriterion :=
  AbstractAddressTypeGrowthCriterion.CurrentSeedCriterion

inductive FillPhase where
  | source
  | transit
  | activeFrontier
  deriving DecidableEq

structure FrontierRankProfile (A : Type) where
  sourceAddress : A
  selectedAddress : A
  targetAddress : A
  visibleRoles : List A
  beforeRank : Nat
  afterRank : Nat


def toCutFillEndpointData {A : Type}
    (p : FrontierRankProfile A) : CutFillEndpointData A :=
  { sourceAddress := p.sourceAddress,
    selectedAddress := p.selectedAddress,
    targetAddress := p.targetAddress,
    visibleRoles := p.visibleRoles,
    beforeRank := p.beforeRank,
    afterRank := p.afterRank }


def sourcePhase {A : Type} [BEq A]
    (p : FrontierRankProfile A) (a : A) : Bool :=
  a == p.sourceAddress


def activeFrontierPhase {A : Type} [BEq A]
    (p : FrontierRankProfile A) (a : A) : Bool :=
  (a == p.targetAddress) &&
    decide (p.beforeRank < p.afterRank) &&
    AbstractAddressTypeGrowthCriterion.outsideVisible p.visibleRoles a


def phaseFromFrontierProfile {A : Type} [BEq A]
    (p : FrontierRankProfile A) (a : A) : FillPhase :=
  if sourcePhase p a then
    FillPhase.source
  else if activeFrontierPhase p a then
    FillPhase.activeFrontier
  else
    FillPhase.transit


def rankOfPhase {A : Type}
    (p : FrontierRankProfile A) : FillPhase -> Nat
  | FillPhase.source => p.beforeRank
  | FillPhase.transit => p.afterRank
  | FillPhase.activeFrontier => p.afterRank + 1


def rankFromFrontierProfile {A : Type} [BEq A]
    (p : FrontierRankProfile A) (a : A) : Nat :=
  rankOfPhase p (phaseFromFrontierProfile p a)


def endpointFromFrontierProfile {A : Type} [BEq A]
    (p : FrontierRankProfile A) (a : A) : FillEndpoint :=
  FillDynamicsRankCriterion.endpointOfNatRank
    (rankFromFrontierProfile p a)


def nodeOfFromFrontierProfile {A : Type} [BEq A]
    (p : FrontierRankProfile A) (a : A) : Node :=
  CanonicalFillOrderCriterion.fillEndpointRank
    (endpointFromFrontierProfile p a)


theorem rank_from_frontier_profile_eq_dynamic_rank
    {A : Type} [BEq A] (p : FrontierRankProfile A) (a : A) :
    rankFromFrontierProfile p a =
      FillDynamicsRankCriterion.dynamicRankFromCutFillData
        (toCutFillEndpointData p) a := by
  unfold rankFromFrontierProfile phaseFromFrontierProfile rankOfPhase
  unfold sourcePhase activeFrontierPhase
  unfold FillDynamicsRankCriterion.dynamicRankFromCutFillData
  unfold toCutFillEndpointData
  cases hsource : (a == p.sourceAddress) <;>
    cases hfrontier : ((a == p.targetAddress) &&
      decide (p.beforeRank < p.afterRank) &&
      AbstractAddressTypeGrowthCriterion.outsideVisible p.visibleRoles a) <;>
    rfl


theorem endpoint_from_frontier_profile_eq_dynamic_endpoint
    {A : Type} [BEq A] (p : FrontierRankProfile A) (a : A) :
    endpointFromFrontierProfile p a =
      FillDynamicsRankCriterion.dynamicEndpointFromCutFillData
        (toCutFillEndpointData p) a := by
  unfold endpointFromFrontierProfile
  unfold FillDynamicsRankCriterion.dynamicEndpointFromCutFillData
  rw [rank_from_frontier_profile_eq_dynamic_rank]


theorem nodeOf_from_frontier_profile_eq_dynamic_nodeOf
    {A : Type} [BEq A] (p : FrontierRankProfile A) (a : A) :
    nodeOfFromFrontierProfile p a =
      FillDynamicsRankCriterion.dynamicFillRankNodeOf
        (toCutFillEndpointData p) a := by
  unfold nodeOfFromFrontierProfile
  unfold FillDynamicsRankCriterion.dynamicFillRankNodeOf
  rw [endpoint_from_frontier_profile_eq_dynamic_endpoint]


def currentFrontierRankProfile : FrontierRankProfile CurrentAddress :=
  { sourceAddress := SchurDtnDerivedAddressSeed.cutRoot,
    selectedAddress := SchurDtnDerivedAddressSeed.selectedChild,
    targetAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    visibleRoles := SchurDtnDerivedAddressSeed.roleAddresses,
    beforeRank := 0,
    afterRank := 1 }


theorem current_profile_to_cut_fill_endpoint_data :
    toCutFillEndpointData currentFrontierRankProfile =
      FillEndpointDerivationCriterion.currentCutFillEndpointData := rfl


theorem current_source_phase_cut_root :
    sourcePhase currentFrontierRankProfile
      SchurDtnDerivedAddressSeed.cutRoot = true := rfl


theorem current_source_phase_selected_false :
    sourcePhase currentFrontierRankProfile
      SchurDtnDerivedAddressSeed.selectedChild = false := rfl


theorem current_source_phase_frontier_false :
    sourcePhase currentFrontierRankProfile
      SchurDtnDerivedAddressSeed.frontierPortAddress = false := by
  change sourcePhase currentFrontierRankProfile
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) = false
  rfl


theorem current_active_frontier_phase_cut_root_false :
    activeFrontierPhase currentFrontierRankProfile
      SchurDtnDerivedAddressSeed.cutRoot = false := rfl


theorem current_active_frontier_phase_selected_false :
    activeFrontierPhase currentFrontierRankProfile
      SchurDtnDerivedAddressSeed.selectedChild = false := rfl


theorem current_active_frontier_phase_frontier_true :
    activeFrontierPhase currentFrontierRankProfile
      SchurDtnDerivedAddressSeed.frontierPortAddress = true := by
  change activeFrontierPhase currentFrontierRankProfile
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) = true
  rfl


theorem current_phase_cut_root_source :
    phaseFromFrontierProfile currentFrontierRankProfile
      SchurDtnDerivedAddressSeed.cutRoot = FillPhase.source := rfl


theorem current_phase_selected_transit :
    phaseFromFrontierProfile currentFrontierRankProfile
      SchurDtnDerivedAddressSeed.selectedChild = FillPhase.transit := rfl


theorem current_phase_frontier_active :
    phaseFromFrontierProfile currentFrontierRankProfile
      SchurDtnDerivedAddressSeed.frontierPortAddress =
      FillPhase.activeFrontier := by
  change phaseFromFrontierProfile currentFrontierRankProfile
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) = FillPhase.activeFrontier
  rfl


def currentFrontierProfileRank : CurrentAddress -> Nat :=
  rankFromFrontierProfile currentFrontierRankProfile


theorem current_frontier_profile_rank_eq_dynamic_rank :
    currentFrontierProfileRank =
      FillDynamicsRankCriterion.dynamicRankFromCutFillData
        FillEndpointDerivationCriterion.currentCutFillEndpointData := by
  funext a
  rw [← current_profile_to_cut_fill_endpoint_data]
  exact rank_from_frontier_profile_eq_dynamic_rank
    currentFrontierRankProfile a


theorem current_frontier_profile_rank_cut_root_zero :
    currentFrontierProfileRank
      SchurDtnDerivedAddressSeed.cutRoot = 0 := rfl


theorem current_frontier_profile_rank_selected_one :
    currentFrontierProfileRank
      SchurDtnDerivedAddressSeed.selectedChild = 1 := rfl


theorem current_frontier_profile_rank_frontier_two :
    currentFrontierProfileRank
      SchurDtnDerivedAddressSeed.frontierPortAddress = 2 := by
  change currentFrontierProfileRank
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) = 2
  rfl


def currentFrontierProfileEndpoint : CurrentAddress -> FillEndpoint :=
  endpointFromFrontierProfile currentFrontierRankProfile


theorem current_frontier_profile_endpoint_eq_dynamic_endpoint :
    currentFrontierProfileEndpoint =
      FillDynamicsRankCriterion.dynamicEndpointFromCutFillData
        FillEndpointDerivationCriterion.currentCutFillEndpointData := by
  funext a
  rw [← current_profile_to_cut_fill_endpoint_data]
  exact endpoint_from_frontier_profile_eq_dynamic_endpoint
    currentFrontierRankProfile a


theorem current_frontier_profile_endpoint_cut_root_repeller :
    currentFrontierProfileEndpoint
      SchurDtnDerivedAddressSeed.cutRoot =
      CanonicalFillOrderCriterion.FillEndpoint.repeller := rfl


theorem current_frontier_profile_endpoint_selected_transit :
    currentFrontierProfileEndpoint
      SchurDtnDerivedAddressSeed.selectedChild =
      CanonicalFillOrderCriterion.FillEndpoint.transit := rfl


theorem current_frontier_profile_endpoint_frontier_attractor :
    currentFrontierProfileEndpoint
      SchurDtnDerivedAddressSeed.frontierPortAddress =
      CanonicalFillOrderCriterion.FillEndpoint.attractor := by
  change currentFrontierProfileEndpoint
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) =
      CanonicalFillOrderCriterion.FillEndpoint.attractor
  rfl


def currentFrontierProfileNodeOf : CurrentAddress -> Node :=
  nodeOfFromFrontierProfile currentFrontierRankProfile


theorem current_frontier_profile_nodeOf_eq_dynamic_nodeOf :
    currentFrontierProfileNodeOf =
      FillDynamicsRankCriterion.currentDynamicFillRankNodeOf := by
  funext a
  unfold currentFrontierProfileNodeOf
  unfold FillDynamicsRankCriterion.currentDynamicFillRankNodeOf
  rw [← current_profile_to_cut_fill_endpoint_data]
  exact nodeOf_from_frontier_profile_eq_dynamic_nodeOf
    currentFrontierRankProfile a


theorem current_frontier_profile_nodeOf_eq_fill_order_nodeOf :
    currentFrontierProfileNodeOf =
      CanonicalFillOrderCriterion.currentFillRankNodeOf := by
  rw [current_frontier_profile_nodeOf_eq_dynamic_nodeOf]
  exact FillDynamicsRankCriterion.current_dynamic_fill_nodeOf_eq_fill_order_nodeOf


theorem current_frontier_profile_cut_root_node_zero :
    currentFrontierProfileNodeOf
      SchurDtnDerivedAddressSeed.cutRoot = 0 := rfl


theorem current_frontier_profile_selected_node_one :
    currentFrontierProfileNodeOf
      SchurDtnDerivedAddressSeed.selectedChild = 1 := rfl


theorem current_frontier_profile_frontier_node_two :
    currentFrontierProfileNodeOf
      SchurDtnDerivedAddressSeed.frontierPortAddress = 2 := by
  change currentFrontierProfileNodeOf
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) = 2
  rfl


def currentFrontierProfileAbstractSeed : AbstractAddressSeed CurrentAddress :=
  { cutRoot := SchurDtnDerivedAddressSeed.cutRoot,
    selectedAddress := SchurDtnDerivedAddressSeed.selectedChild,
    frontierAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    sourceAddress := SchurDtnDerivedAddressSeed.cutRoot,
    targetAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    visibleRoles := SchurDtnDerivedAddressSeed.roleAddresses,
    beforeRank := 0,
    afterRank := 1,
    nodeOf := currentFrontierProfileNodeOf }


theorem current_frontier_profile_frontier_outside_visible :
    AbstractAddressTypeGrowthCriterion.outsideVisible
      currentFrontierProfileAbstractSeed.visibleRoles
      currentFrontierProfileAbstractSeed.frontierAddress = true := rfl


def currentFrontierProfileSeedCriterion :
    CurrentSeedCriterion currentFrontierProfileAbstractSeed :=
  { source_is_cut_root := rfl,
    target_is_frontier := rfl,
    rank_increases := rfl,
    frontier_outside_visible :=
      current_frontier_profile_frontier_outside_visible,
    source_node_zero := current_frontier_profile_cut_root_node_zero,
    frontier_node_two := current_frontier_profile_frontier_node_two,
    cut_root_is_local := rfl,
    frontier_is_local := rfl }


theorem current_frontier_profile_seed_to_local_rule :
    AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
      currentFrontierProfileAbstractSeed =
      GrowthEdgeProvenance.activeAddressGrowthRule := rfl


theorem frontier_profile_growth_active :
    GrowthEdgeProvenance.growthActive
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentFrontierProfileAbstractSeed) = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_growth_active
    currentFrontierProfileSeedCriterion


theorem frontier_profile_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentFrontierProfileAbstractSeed) 0 2 = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_forward_edge
    currentFrontierProfileSeedCriterion


theorem frontier_profile_backward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentFrontierProfileAbstractSeed) 2 0 = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_backward_edge
    currentFrontierProfileSeedCriterion


theorem frontier_profile_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  GrowthEdgeProvenance.derived_growth_status


def frontierProfileReversalRejectsFrontierZero : Prop :=
  CanonicalRoleOrderCriterion.roleNumberFromOrder
    CanonicalFillOrderCriterion.reversedInterfaceRoleOrder
    CanonicalRoleOrderCriterion.InterfaceRole.frontierResidual = 0 ∧
  currentFrontierProfileNodeOf
    SchurDtnDerivedAddressSeed.frontierPortAddress = 2


theorem frontier_profile_reversal_rejects_frontier_zero :
    frontierProfileReversalRejectsFrontierZero :=
  And.intro
    CanonicalFillOrderCriterion.reversed_order_frontier_zero
    current_frontier_profile_frontier_node_two


def frontierProfileStillLocalPhaseClassifier : Prop := True


theorem frontier_profile_still_local_phase_classifier :
    frontierProfileStillLocalPhaseClassifier :=
  True.intro

end FrontierRankProfileCriterion
