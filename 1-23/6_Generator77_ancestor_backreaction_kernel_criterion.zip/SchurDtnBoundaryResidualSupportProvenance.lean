import CNNA.SchurDtnCutCandidateLoadProvenance

namespace SchurDtnBoundaryResidualSupportProvenance

abbrev Node := Fin 3
abbrev CutCandidateLoadSupportData :=
  SchurDtnCutCandidateLoadProvenance.CutCandidateLoadSupportData
abbrev GraphPortLoadCutData :=
  SchurDtnGraphPortLoadProvenance.GraphPortLoadCutData
abbrev DefectSystem := SectorResolutionGate.DefectSystem

structure BoundaryResidualSupportData where
  universeNodes : List Node
  boundaryRoleNodes : List Node
  interiorRoleNodes : List Node
  uvBoundaryRoleNodes : List Node
  envBoundaryRoleNodes : List Node
  recordRoleNodes : List Node
  boundaryPort : Node
  interiorPort : Node
  interiorLoadNode : Node
  loadAdjacent : Node -> Node -> Bool
  adjacent : Node -> Node -> Bool


def containsNode (x : Node) : List Node -> Bool
  | [] => false
  | y :: ys => if x == y then true else containsNode x ys


def visibleRoleNodes (p : BoundaryResidualSupportData) : List Node :=
  p.boundaryRoleNodes ++ p.interiorRoleNodes ++
    p.uvBoundaryRoleNodes ++ p.envBoundaryRoleNodes ++ p.recordRoleNodes


def isVisibleRoleNode (p : BoundaryResidualSupportData) (x : Node) : Bool :=
  containsNode x (visibleRoleNodes p)


def residualSupportFromUniverse (p : BoundaryResidualSupportData) :
    List Node -> List Node
  | [] => []
  | x :: xs =>
      if isVisibleRoleNode p x then residualSupportFromUniverse p xs
      else x :: residualSupportFromUniverse p xs


def residualSupportNodes (p : BoundaryResidualSupportData) : List Node :=
  residualSupportFromUniverse p p.universeNodes


def toCutCandidateLoadSupportData (p : BoundaryResidualSupportData) :
    CutCandidateLoadSupportData :=
  { boundaryPort := p.boundaryPort,
    interiorPort := p.interiorPort,
    interiorLoadNode := p.interiorLoadNode,
    residualSupportNodes := residualSupportNodes p,
    loadAdjacent := p.loadAdjacent,
    adjacent := p.adjacent }


theorem toCutCandidateLoadSupportData_residualSupportNodes
    (p : BoundaryResidualSupportData) :
    (toCutCandidateLoadSupportData p).residualSupportNodes =
      residualSupportNodes p := rfl


def eqAdj : Node -> Node -> Bool :=
  SchurDtnCutCandidateLoadProvenance.eqAdj


def edge01 : Node -> Node -> Bool :=
  SchurDtnCutCandidateLoadProvenance.edge01


def zeroBoundarySupportAt (x : Node) : BoundaryResidualSupportData :=
  { universeNodes := [0, 1],
    boundaryRoleNodes := [0],
    interiorRoleNodes := [1],
    uvBoundaryRoleNodes := [1],
    envBoundaryRoleNodes := [0],
    recordRoleNodes := [],
    boundaryPort := x,
    interiorPort := 1,
    interiorLoadNode := 1,
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


def residualBoundarySupportNode2 : BoundaryResidualSupportData :=
  { universeNodes := [0, 1, 2],
    boundaryRoleNodes := [0],
    interiorRoleNodes := [1],
    uvBoundaryRoleNodes := [1],
    envBoundaryRoleNodes := [0],
    recordRoleNodes := [],
    boundaryPort := 2,
    interiorPort := 1,
    interiorLoadNode := 1,
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


theorem zero_boundary_visible_role_nodes_node2 :
    visibleRoleNodes (zeroBoundarySupportAt 2) = [0, 1, 1, 0] := rfl


theorem residual_boundary_visible_role_nodes_node2 :
    visibleRoleNodes residualBoundarySupportNode2 = [0, 1, 1, 0] := rfl


theorem zero_residual_support_nodes_node2 :
    residualSupportNodes (zeroBoundarySupportAt 2) = [] := rfl


theorem residual_support_nodes_node2_from_boundary_universe :
    residualSupportNodes residualBoundarySupportNode2 = [2] := rfl


def zeroCandidateLoadSupportAt (x : Node) : CutCandidateLoadSupportData :=
  toCutCandidateLoadSupportData (zeroBoundarySupportAt x)


def residualCandidateLoadSupportNode2 : CutCandidateLoadSupportData :=
  toCutCandidateLoadSupportData residualBoundarySupportNode2


theorem zero_candidate_load_support_eq_previous_node2 :
    zeroCandidateLoadSupportAt 2 =
      SchurDtnCutCandidateLoadProvenance.zeroCandidateLoadSupportAt 2 := rfl


theorem residual_candidate_load_support_eq_previous_node2 :
    residualCandidateLoadSupportNode2 =
      SchurDtnCutCandidateLoadProvenance.residualCandidateLoadSupportNode2 := rfl


theorem residual_candidate_load_nodes_node2_from_boundary_universe :
    SchurDtnCutCandidateLoadProvenance.candidateLoadNodes
      residualCandidateLoadSupportNode2 = [1, 2] := rfl


def zeroLoadCutBlockAt (x : Node) : GraphPortLoadCutData :=
  SchurDtnCutCandidateLoadProvenance.toGraphPortLoadCutData
    (zeroCandidateLoadSupportAt x)


def residualLoadCutBlockNode2 : GraphPortLoadCutData :=
  SchurDtnCutCandidateLoadProvenance.toGraphPortLoadCutData
    residualCandidateLoadSupportNode2


theorem zero_load_cut_block_eq_previous_node2 :
    zeroLoadCutBlockAt 2 =
      SchurDtnCutCandidateLoadProvenance.zeroLoadCutBlockAt 2 := rfl


theorem residual_load_cut_block_eq_previous_node2 :
    residualLoadCutBlockNode2 =
      SchurDtnCutCandidateLoadProvenance.residualLoadCutBlockNode2 := rfl


theorem residual_boundary_load_nodes_node2_from_boundary_universe :
    SchurDtnGraphPortLoadProvenance.boundaryLoadNodes
      residualLoadCutBlockNode2 = [2] := rfl


def boundaryResidualSupportDefectSystem : DefectSystem Bool :=
  SchurDtnCutCandidateLoadProvenance.candidateLoadDefectSystem


theorem boundary_residual_support_closure_status :
    boundaryResidualSupportDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      boundaryResidualSupportDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        boundaryResidualSupportDefectSystem) :=
  SchurDtnCutCandidateLoadProvenance.candidate_load_closure_status


def symmetricDefectSystem : DefectSystem Bool :=
  SchurDtnCutCandidateLoadProvenance.symmetricDefectSystem


theorem symmetric_boundary_residual_support_status :
    symmetricDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem :=
  SchurDtnCutCandidateLoadProvenance.symmetric_candidate_load_status


def boundaryUniverseStillNeedsCutGraphDerivation : Prop := True


theorem boundary_universe_still_needs_cut_graph_derivation :
    boundaryUniverseStillNeedsCutGraphDerivation :=
  True.intro

end SchurDtnBoundaryResidualSupportProvenance
