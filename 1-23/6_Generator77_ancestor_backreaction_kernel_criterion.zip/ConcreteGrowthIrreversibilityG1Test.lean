import CNNA.ConcreteSymmetricCutG1Test

namespace ConcreteGrowthIrreversibilityG1Test

abbrev Node := Fin 3
abbrev FiniteCut := FiniteCutCombinatorics.FiniteCut Node
abbrev CertifiedSchurBlocks := DirichletInverseWitness.CertifiedSchurBlocks Node
abbrev SchurSummary := SchurDtnSummary.SchurSummary Node
abbrev DefectSystem := SectorResolutionGate.DefectSystem


def edge01 (x y : Node) : Bool :=
  ((x == 0) && (y == 1)) || ((x == 1) && (y == 0))


def reversibleGrowthEdge (x y : Node) : Bool :=
  ((x == 0) && (y == 1)) || ((x == 1) && (y == 0)) ||
  ((x == 2) && (y == 1)) || ((x == 1) && (y == 2))


def boundaryFrontierGrowthEdge (x y : Node) : Bool :=
  ((x == 0) && (y == 1)) || ((x == 1) && (y == 0)) ||
  ((x == 0) && (y == 2)) || ((x == 2) && (y == 0))


def beforeCut : FiniteCut :=
  { boundary := [0],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    complementNodes := [],
    adjacent := edge01 }


def reversibleGrowthCut : FiniteCut :=
  { boundary := [0, 2],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    complementNodes := [],
    adjacent := reversibleGrowthEdge }


def boundaryFrontierGrowthCut : FiniteCut :=
  { boundary := [0, 2],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    complementNodes := [],
    adjacent := boundaryFrontierGrowthEdge }


theorem before_lbb_trace_one :
    FiniteGraphLaplacianBlocks.LBBTrace beforeCut = 1 := rfl


theorem before_coupling_trace_one :
    FiniteGraphLaplacianBlocks.couplingTrace beforeCut = 1 := rfl


theorem before_graph_cut_defect_zero :
    FiniteGraphLaplacianBlocks.graphCutDefect beforeCut = 0 := rfl


theorem reversible_lbb_trace_two :
    FiniteGraphLaplacianBlocks.LBBTrace reversibleGrowthCut = 2 := rfl


theorem reversible_coupling_trace_two :
    FiniteGraphLaplacianBlocks.couplingTrace reversibleGrowthCut = 2 := rfl


theorem reversible_graph_cut_defect_zero :
    FiniteGraphLaplacianBlocks.graphCutDefect reversibleGrowthCut = 0 := rfl


theorem boundary_frontier_lbb_trace_three :
    FiniteGraphLaplacianBlocks.LBBTrace boundaryFrontierGrowthCut = 3 := rfl


theorem boundary_frontier_coupling_trace_one :
    FiniteGraphLaplacianBlocks.couplingTrace boundaryFrontierGrowthCut = 1 := rfl


theorem boundary_frontier_graph_cut_defect_zero :
    FiniteGraphLaplacianBlocks.graphCutDefect boundaryFrontierGrowthCut = 0 := rfl


def certifiedBlocks (c : FiniteCut) : CertifiedSchurBlocks :=
  ConcreteMatrixArithmetic.certifiedOne1Blocks c
    c.boundary.length
    (FiniteGraphLaplacianBlocks.LBBTrace c)
    (FiniteGraphLaplacianBlocks.couplingTrace c)
    (FiniteGraphLaplacianBlocks.graphCutDefect c)


def beforeBlocks : CertifiedSchurBlocks :=
  certifiedBlocks beforeCut


def reversibleGrowthBlocks : CertifiedSchurBlocks :=
  certifiedBlocks reversibleGrowthCut


def boundaryFrontierGrowthBlocks : CertifiedSchurBlocks :=
  certifiedBlocks boundaryFrontierGrowthCut


theorem before_concrete_schur_trace_zero :
    FiniteMatrixSchurPort.schurTrace
      (DirichletInverseWitness.toInvertibleSchurBlocks beforeBlocks) = 0 := rfl


theorem reversible_concrete_schur_trace_zero :
    FiniteMatrixSchurPort.schurTrace
      (DirichletInverseWitness.toInvertibleSchurBlocks reversibleGrowthBlocks) = 0 := rfl


theorem boundary_frontier_concrete_schur_trace_two :
    FiniteMatrixSchurPort.schurTrace
      (DirichletInverseWitness.toInvertibleSchurBlocks
        boundaryFrontierGrowthBlocks) = 2 := rfl


def beforeSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary beforeBlocks


def reversibleGrowthSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary reversibleGrowthBlocks


def boundaryFrontierGrowthSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary boundaryFrontierGrowthBlocks


def growthIrreversibilityDefectSystem : DefectSystem Bool :=
  SchurStrictPreferenceBridge.schurCutHandoffDefectSystem
    beforeSummary reversibleGrowthSummary boundaryFrontierGrowthSummary


theorem growth_irreversibility_false_defect_zero :
    growthIrreversibilityDefectSystem.defect false = [0, 0, 0, 0, 0] := rfl


theorem growth_irreversibility_true_defect_dtn_two :
    growthIrreversibilityDefectSystem.defect true = [0, 2, 0, 0, 0] := rfl


theorem growth_irreversibility_minSet_singleton :
    growthIrreversibilityDefectSystem.minSet = [false] := rfl


theorem growth_irreversibility_kernel_one :
    growthIrreversibilityDefectSystem.kernel = 1 :=
  CanonicalGrowthKernel.DefectSystem.unique_kernel_one
    growthIrreversibilityDefectSystem false
    growth_irreversibility_minSet_singleton


def growthIrreversibilitySchurStrictPreference :
    SchurStrictPreferenceBridge.SchurStrictPreference
      beforeSummary reversibleGrowthSummary boundaryFrontierGrowthSummary :=
  { minSet_singleton := growth_irreversibility_minSet_singleton }


theorem growth_irreversibility_resolved_j_sign :
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      growthIrreversibilityDefectSystem :=
  SchurStrictPreferenceBridge.resolved_of_schur_strict_preference
    beforeSummary reversibleGrowthSummary boundaryFrontierGrowthSummary
    growthIrreversibilitySchurStrictPreference


theorem growth_irreversibility_locks_eq_plusSector :
    SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      growthIrreversibilityDefectSystem = JSignClosureCriterion.plusSector := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    SchurStrictPreferenceBridge.schurSectorMap
    CutStrictPreferenceBridge.cutSectorMap
    HandoffStrictPreferenceBridge.handoffSectorMap
    GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.plusSector
  rw [growth_irreversibility_minSet_singleton]
  rfl


theorem growth_irreversibility_not_flip_closed :
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        growthIrreversibilityDefectSystem) := by
  intro hclosed
  rw [growth_irreversibility_locks_eq_plusSector] at hclosed
  exact SymmetryBreakingClosureGate.plusSector_not_closed_under_flip hclosed


theorem growth_irreversibility_status :
    growthIrreversibilityDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      growthIrreversibilityDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        growthIrreversibilityDefectSystem) :=
  And.intro growth_irreversibility_kernel_one
    (And.intro growth_irreversibility_resolved_j_sign
      growth_irreversibility_not_flip_closed)


def reversibleControlDefectSystem : DefectSystem Bool :=
  SchurStrictPreferenceBridge.schurCutHandoffDefectSystem
    beforeSummary reversibleGrowthSummary reversibleGrowthSummary


theorem reversible_control_false_defect_zero :
    reversibleControlDefectSystem.defect false = [0, 0, 0, 0, 0] := rfl


theorem reversible_control_true_defect_zero :
    reversibleControlDefectSystem.defect true = [0, 0, 0, 0, 0] := rfl


theorem reversible_control_minSet_pair :
    reversibleControlDefectSystem.minSet = [false, true] := rfl


theorem reversible_control_kernel_two :
    reversibleControlDefectSystem.kernel = 2 :=
  CanonicalGrowthKernel.DefectSystem.two_sector_kernel
    reversibleControlDefectSystem false true reversible_control_minSet_pair


theorem reversible_control_locks_eq_twoSectors :
    SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      reversibleControlDefectSystem = JSignClosureCriterion.twoSectors := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    SchurStrictPreferenceBridge.schurSectorMap
    CutStrictPreferenceBridge.cutSectorMap
    HandoffStrictPreferenceBridge.handoffSectorMap
    GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.twoSectors
  rw [reversible_control_minSet_pair]
  rfl


theorem reversible_control_not_resolved_j_sign :
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      reversibleControlDefectSystem := by
  change ¬ JSignClosureCriterion.hasClosedJSign
    (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      reversibleControlDefectSystem)
  rw [reversible_control_locks_eq_twoSectors]
  exact JSignClosureCriterion.twoSectors_no_closed_j_sign


theorem reversible_control_status :
    reversibleControlDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      reversibleControlDefectSystem :=
  And.intro reversible_control_kernel_two
    reversible_control_not_resolved_j_sign


def growthIrreversibilityG1TestClosesConditionally : Prop :=
  growthIrreversibilityDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      growthIrreversibilityDefectSystem


def reversibleGrowthG1TestDoesNotBreakSign : Prop :=
  reversibleControlDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      reversibleControlDefectSystem


theorem growth_irreversibility_g1_test_closes_conditionally :
    growthIrreversibilityG1TestClosesConditionally :=
  And.intro growth_irreversibility_kernel_one
    growth_irreversibility_resolved_j_sign


theorem reversible_growth_g1_test_does_not_break_sign :
    reversibleGrowthG1TestDoesNotBreakSign :=
  reversible_control_status


def growthEdgeProvenanceStillOpen : Prop := True


theorem growth_edge_provenance_still_open :
    growthEdgeProvenanceStillOpen :=
  True.intro

end ConcreteGrowthIrreversibilityG1Test
