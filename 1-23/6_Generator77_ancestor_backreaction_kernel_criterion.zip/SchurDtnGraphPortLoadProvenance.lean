import CNNA.SchurDtnGraphPortBlockProvenance

namespace SchurDtnGraphPortLoadProvenance

abbrev Node := Fin 3
abbrev DefectSystem := SectorResolutionGate.DefectSystem

structure GraphPortLoadCutData where
  boundaryPort : Node
  interiorPort : Node
  candidateLoadNodes : List Node
  loadAdjacent : Node -> Node -> Bool
  adjacent : Node -> Node -> Bool


def selectedLoadNodes (p : Node -> Bool) : List Node -> List Node
  | [] => []
  | x :: xs =>
      if p x then x :: selectedLoadNodes p xs else selectedLoadNodes p xs


def loadNodesAt (p : GraphPortLoadCutData) (x : Node) : List Node :=
  selectedLoadNodes (p.loadAdjacent x) p.candidateLoadNodes


def boundaryLoadNodes (p : GraphPortLoadCutData) : List Node :=
  loadNodesAt p p.boundaryPort


def interiorLoadNodes (p : GraphPortLoadCutData) : List Node :=
  loadNodesAt p p.interiorPort


def eqAdj (x y : Node) : Bool :=
  x == y


def zeroLoadCutBlockAt (x : Node) : GraphPortLoadCutData :=
  { boundaryPort := x,
    interiorPort := 1,
    candidateLoadNodes := [1],
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


def residualLoadCutBlockNode2 : GraphPortLoadCutData :=
  { boundaryPort := 2,
    interiorPort := 1,
    candidateLoadNodes := [1, 2],
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


theorem residual_node2_boundary_load_nodes_singleton :
    boundaryLoadNodes residualLoadCutBlockNode2 = [2] := rfl


theorem residual_node2_interior_load_nodes_singleton :
    interiorLoadNodes residualLoadCutBlockNode2 = [1] := rfl


structure SchurDtnGraphPortLoadTraceData where
  boundary : List Node
  interior : List Node
  uvBoundary : List Node
  envBoundary : List Node
  recordNodes : List Node
  candidatePortNodes : List Node
  beforeLoadCutBlock : Node -> GraphPortLoadCutData
  afterLoadCutBlock : Node -> GraphPortLoadCutData
  adjacent : Node -> Node -> Bool


def edge01 (x y : Node) : Bool :=
  ((x == 0) && (y == 1)) || ((x == 1) && (y == 0))


def zeroLoadBlockAt (x : Node) : GraphPortLoadCutData :=
  zeroLoadCutBlockAt x


def beforeLoadTraceData : SchurDtnGraphPortLoadTraceData :=
  { boundary := [0],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    candidatePortNodes := [0, 1, 2],
    beforeLoadCutBlock := zeroLoadBlockAt,
    afterLoadCutBlock := zeroLoadBlockAt,
    adjacent := edge01 }


def plusAfterLoadTraceData : SchurDtnGraphPortLoadTraceData :=
  beforeLoadTraceData


def minusAfterLoadTraceData : SchurDtnGraphPortLoadTraceData :=
  { boundary := [0],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    candidatePortNodes := [0, 1, 2],
    beforeLoadCutBlock := zeroLoadBlockAt,
    afterLoadCutBlock := fun _ => residualLoadCutBlockNode2,
    adjacent := edge01 }


theorem minus_after_boundary_load_node2_from_cut_port_incidence :
    boundaryLoadNodes (minusAfterLoadTraceData.afterLoadCutBlock 2) = [2] :=
  residual_node2_boundary_load_nodes_singleton


def cutPortLoadDefectSystem : DefectSystem Bool :=
  SchurDtnGraphPortBlockProvenance.graphSchurProvenanceDefectSystem


theorem cut_port_load_closure_status :
    cutPortLoadDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      cutPortLoadDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        cutPortLoadDefectSystem) :=
  SchurDtnGraphPortBlockProvenance.graph_schur_provenance_closure_status


def symmetricDefectSystem : DefectSystem Bool :=
  SchurDtnGraphPortBlockProvenance.symmetricDefectSystem


theorem symmetric_cut_port_load_status :
    symmetricDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem :=
  SchurDtnGraphPortBlockProvenance.symmetric_graph_schur_status


def cutPortCandidateLoadStillNeedsDerivation : Prop := True


theorem cut_port_candidate_load_still_needs_derivation :
    cutPortCandidateLoadStillNeedsDerivation :=
  True.intro

end SchurDtnGraphPortLoadProvenance
