import CNNA.SchurDtnStrictPreferenceCriterion

namespace SchurDtnDefectArithmetic

abbrev Node := Fin 3
abbrev FiniteCut := FiniteGraphLaplacianBlocks.FiniteCut Node
abbrev CertifiedSchurBlocks := DirichletInverseWitness.CertifiedSchurBlocks Node
abbrev SchurSummary := SchurDtnSummary.SchurSummary Node
abbrev DefectSystem := SectorResolutionGate.DefectSystem

def edge01 (x y : Node) : Bool :=
  ((x == 0) && (y == 1)) || ((x == 1) && (y == 0))


def beforeCut : FiniteCut :=
  { boundary := [0],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    complementNodes := [],
    adjacent := edge01 }


def plusAfterCut : FiniteCut :=
  beforeCut


def minusAfterComplementCut : FiniteCut :=
  { boundary := [0],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    complementNodes := [2],
    adjacent := edge01 }


def certifiedBlocks (c : FiniteCut) : CertifiedSchurBlocks :=
  ConcreteMatrixArithmetic.certifiedOne1Blocks c
    c.boundary.length
    (FiniteGraphLaplacianBlocks.LBBTrace c)
    (FiniteGraphLaplacianBlocks.couplingTrace c)
    (FiniteGraphLaplacianBlocks.graphCutDefect c)


def beforeBlocks : CertifiedSchurBlocks :=
  certifiedBlocks beforeCut


def plusAfterBlocks : CertifiedSchurBlocks :=
  certifiedBlocks plusAfterCut


def minusAfterBlocks : CertifiedSchurBlocks :=
  certifiedBlocks minusAfterComplementCut


def beforeSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary beforeBlocks


def plusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary plusAfterBlocks


def minusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary minusAfterBlocks


theorem before_complement_signature_zero :
    FiniteCutCombinatorics.complementSignature beforeCut = 0 := rfl


theorem plus_complement_signature_zero :
    FiniteCutCombinatorics.complementSignature plusAfterCut = 0 := rfl


theorem minus_complement_signature_one :
    FiniteCutCombinatorics.complementSignature minusAfterComplementCut = 1 := rfl


theorem before_schur_trace_zero :
    beforeSummary.schurDtnTrace = 0 := rfl


theorem plus_schur_trace_zero :
    plusAfterSummary.schurDtnTrace = 0 := rfl


theorem minus_schur_trace_zero :
    minusAfterSummary.schurDtnTrace = 0 := rfl


theorem before_cut_defect_zero :
    beforeSummary.schurCutDefect = 0 := rfl


theorem plus_cut_defect_zero :
    plusAfterSummary.schurCutDefect = 0 := rfl


theorem minus_cut_defect_zero :
    minusAfterSummary.schurCutDefect = 0 := rfl


def plusComputedDefectVector : List Nat :=
  DirichletInverseWitness.toDefectVector beforeBlocks plusAfterBlocks


def minusComputedDefectVector : List Nat :=
  DirichletInverseWitness.toDefectVector beforeBlocks minusAfterBlocks


theorem plus_computed_defect_vector_zero :
    plusComputedDefectVector = [0, 0, 0, 0, 0] := rfl


theorem minus_computed_defect_vector_complement_one :
    minusComputedDefectVector = [0, 0, 0, 0, 1] := rfl


def arithmeticDefectSystem : DefectSystem Bool :=
  SchurStrictPreferenceBridge.schurCutHandoffDefectSystem
    beforeSummary plusAfterSummary minusAfterSummary


theorem arithmetic_false_defect :
    arithmeticDefectSystem.defect false = [0, 0, 0, 0, 0] := rfl


theorem arithmetic_true_defect :
    arithmeticDefectSystem.defect true = [0, 0, 0, 0, 1] := rfl


theorem arithmetic_minSet_singleton :
    arithmeticDefectSystem.minSet = [false] := rfl


theorem arithmetic_kernel_one :
    arithmeticDefectSystem.kernel = 1 :=
  CanonicalGrowthKernel.DefectSystem.unique_kernel_one
    arithmeticDefectSystem false arithmetic_minSet_singleton


def arithmeticSchurStrictPreference :
    SchurStrictPreferenceBridge.SchurStrictPreference
      beforeSummary plusAfterSummary minusAfterSummary :=
  { minSet_singleton := arithmetic_minSet_singleton }


theorem arithmetic_resolved_j_sign :
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      arithmeticDefectSystem :=
  SchurStrictPreferenceBridge.resolved_of_schur_strict_preference
    beforeSummary plusAfterSummary minusAfterSummary
    arithmeticSchurStrictPreference


theorem arithmetic_locks_eq_plusSector :
    SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      arithmeticDefectSystem = JSignClosureCriterion.plusSector := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    SchurStrictPreferenceBridge.schurSectorMap
    CutStrictPreferenceBridge.cutSectorMap
    HandoffStrictPreferenceBridge.handoffSectorMap
    GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.plusSector
  rw [arithmetic_minSet_singleton]
  rfl


theorem arithmetic_not_flip_closed :
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        arithmeticDefectSystem) := by
  intro hclosed
  rw [arithmetic_locks_eq_plusSector] at hclosed
  exact SymmetryBreakingClosureGate.plusSector_not_closed_under_flip hclosed


theorem arithmetic_closure_status :
    arithmeticDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      arithmeticDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        arithmeticDefectSystem) :=
  And.intro arithmetic_kernel_one
    (And.intro arithmetic_resolved_j_sign arithmetic_not_flip_closed)


def symmetricMinusAfterCut : FiniteCut :=
  plusAfterCut


def symmetricMinusAfterBlocks : CertifiedSchurBlocks :=
  certifiedBlocks symmetricMinusAfterCut


def symmetricMinusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary symmetricMinusAfterBlocks


def symmetricDefectSystem : DefectSystem Bool :=
  SchurStrictPreferenceBridge.schurCutHandoffDefectSystem
    beforeSummary plusAfterSummary symmetricMinusAfterSummary


theorem symmetric_false_defect :
    symmetricDefectSystem.defect false = [0, 0, 0, 0, 0] := rfl


theorem symmetric_true_defect :
    symmetricDefectSystem.defect true = [0, 0, 0, 0, 0] := rfl


theorem symmetric_minSet_pair :
    symmetricDefectSystem.minSet = [false, true] := rfl


theorem symmetric_kernel_two :
    symmetricDefectSystem.kernel = 2 :=
  CanonicalGrowthKernel.DefectSystem.two_sector_kernel
    symmetricDefectSystem false true symmetric_minSet_pair


theorem symmetric_locks_eq_twoSectors :
    SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      symmetricDefectSystem = JSignClosureCriterion.twoSectors := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    SchurStrictPreferenceBridge.schurSectorMap
    CutStrictPreferenceBridge.cutSectorMap
    HandoffStrictPreferenceBridge.handoffSectorMap
    GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.twoSectors
  rw [symmetric_minSet_pair]
  rfl


theorem symmetric_not_resolved_j_sign :
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem := by
  change ¬ JSignClosureCriterion.hasClosedJSign
    (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      symmetricDefectSystem)
  rw [symmetric_locks_eq_twoSectors]
  exact JSignClosureCriterion.twoSectors_no_closed_j_sign


theorem symmetric_status :
    symmetricDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem :=
  And.intro symmetric_kernel_two symmetric_not_resolved_j_sign


def fullSchurDtnArithmeticStillOpen : Prop := True


theorem full_schur_dtn_arithmetic_still_open :
    fullSchurDtnArithmeticStillOpen :=
  True.intro

end SchurDtnDefectArithmetic
