import CNNA.FiniteGraphLaplacianBlocks

/-
  DirichletInverseWitness.lean
  ----------------------------
  Algebraische Zeugen-Schicht fuer den Interior-Dirichlet-Inversenanteil.

  Die vorherige Matrix-Schur-Port-Schicht akzeptiert einen expliziten
  TwoSidedInverseWitness. Diese Datei haertet diesen Port: ein Zeuge kann nun
  aus zwei echten Gleichungen in einer angegebenen endlichen Matrixalgebra
  erzeugt werden.

  Wichtig:
    * keine freie Matrixinverse,
    * kein Matrix.inv,
    * kein numerischer Orakelzugriff,
    * kein J-Vorzeichen-Claim.

  Diese Schicht beweist noch keine konkrete arithmetische Inversenrechnung.
  Sie kapselt nur das saubere Interface:

      Matrixalgebra + LII * R = 1 + R * LII = 1
        -> TwoSidedInverseWitness
        -> InvertibleSchurBlocks
        -> SchurSummary
        -> DefectVector.

  Eine spaetere arithmetische Schicht muss die konkrete Matrixmultiplikation
  und die beiden Gleichungen fuer echte endliche Dirichletbloeke liefern.
-/

namespace DirichletInverseWitness

abbrev Matrix (m n : Nat) := FiniteMatrixSchurPort.Matrix m n
abbrev RawSchurBlocks (V : Type) := FiniteMatrixSchurPort.RawSchurBlocks V
abbrev InvertibleSchurBlocks (V : Type) :=
  FiniteMatrixSchurPort.InvertibleSchurBlocks V

/-- Eine angegebene endliche Matrixalgebra auf quadratischen n-mal-n Matrizen.
    Diese Struktur enthaelt nur Produkt und Einselement; keine Inverse. -/
structure MatrixAlgebra (n : Nat) where
  mul : Matrix n n -> Matrix n n -> Matrix n n
  one : Matrix n n

/-- Algebraischer Zwei-Seiten-Inversen-Zeuge. Der Kandidat R wird nur akzeptiert,
    wenn beide Gleichungen relativ zur angegebenen Matrixalgebra bewiesen sind. -/
structure AlgebraicTwoSidedInverse {n : Nat} (A : MatrixAlgebra n)
    (L R : Matrix n n) where
  left_eq : A.mul L R = A.one
  right_eq : A.mul R L = A.one

/-- Aus einem algebraischen Zeugen wird der boolsche Portzeuge der bestehenden
    FiniteMatrixSchurPort-Schicht. Die bools sind hier nicht frei: sie werden
    durch die vorhandenen Gleichungsbeweise getragen und nur nach true
    projiziert. -/
def toBooleanWitness {n : Nat} {A : MatrixAlgebra n} {L R : Matrix n n}
    (_h : AlgebraicTwoSidedInverse A L R) :
    FiniteMatrixSchurPort.TwoSidedInverseWitness n L R :=
  { leftCertified := true,
    rightCertified := true,
    left_ok := rfl,
    right_ok := rfl }

/-- RawSchurBlocks plus algebraisch bewiesener Interior-Inversenkandidat. -/
structure CertifiedSchurBlocks (V : Type) where
  raw : RawSchurBlocks V
  algebra : MatrixAlgebra raw.interiorDim
  inverse : AlgebraicTwoSidedInverse algebra raw.LII raw.candidateInverse

/-- Uebersetzung in den bereits gruenen Matrix-Schur-Port. -/
def toInvertibleSchurBlocks {V : Type} (b : CertifiedSchurBlocks V) :
    InvertibleSchurBlocks V :=
  { raw := b.raw,
    inv := toBooleanWitness b.inverse }

/-- Direkter SchurSummary-Port. -/
def toSchurSummary {V : Type} (b : CertifiedSchurBlocks V) :
    SchurDtnSummary.SchurSummary V :=
  FiniteMatrixSchurPort.toSchurSummary (toInvertibleSchurBlocks b)

/-- Direkter CutSummary-Port. -/
def toCutSummary {V : Type} (b : CertifiedSchurBlocks V) :
    FiniteHandoffSummary.CutSummary :=
  FiniteMatrixSchurPort.toCutSummary (toInvertibleSchurBlocks b)

/-- Direkter HandoffData-Port. -/
def toHandoffData {V : Type} (before after : CertifiedSchurBlocks V) :
    FiniteHandoffSummary.HandoffData :=
  FiniteMatrixSchurPort.toHandoffData
    (toInvertibleSchurBlocks before) (toInvertibleSchurBlocks after)

/-- Direkter Defektvektor-Port. -/
def toDefectVector {V : Type} (before after : CertifiedSchurBlocks V) :
    List Nat :=
  FiniteMatrixSchurPort.toDefectVector
    (toInvertibleSchurBlocks before) (toInvertibleSchurBlocks after)

/-- Konstruktion aus rohen Bloecken und einem algebraischen Inversenbeweis. -/
def fromRaw {V : Type} (raw : RawSchurBlocks V)
    (A : MatrixAlgebra raw.interiorDim)
    (h : AlgebraicTwoSidedInverse A raw.LII raw.candidateInverse) :
    CertifiedSchurBlocks V :=
  { raw := raw,
    algebra := A,
    inverse := h }

/-- Konstruktion aus dem Graph-Laplace-Blockport. Auch hier bleibt der
    Inversenanteil ein algebraischer Gleichungszeuge, nicht eine freie Wahl. -/
def fromFiniteCut {V : Type} (c : FiniteGraphLaplacianBlocks.FiniteCut V)
    (A : MatrixAlgebra c.interior.length)
    (h : AlgebraicTwoSidedInverse A
      (FiniteGraphLaplacianBlocks.zeroMatrix
        c.interior.length c.interior.length)
      (FiniteGraphLaplacianBlocks.zeroMatrix
        c.interior.length c.interior.length)) :
    CertifiedSchurBlocks V :=
  fromRaw (FiniteGraphLaplacianBlocks.toRawSchurBlocks c) A h

/-! ## Link-Saetze -/

theorem toInvertible_raw {V : Type} (b : CertifiedSchurBlocks V) :
    (toInvertibleSchurBlocks b).raw = b.raw := rfl

theorem toInvertible_left_certified {V : Type} (b : CertifiedSchurBlocks V) :
    (toInvertibleSchurBlocks b).inv.leftCertified = true := rfl

theorem toInvertible_right_certified {V : Type} (b : CertifiedSchurBlocks V) :
    (toInvertibleSchurBlocks b).inv.rightCertified = true := rfl

/-- Der algebraische Port laeuft exakt durch FiniteMatrixSchurPort. -/
theorem toDefectVector_link {V : Type}
    (before after : CertifiedSchurBlocks V) :
    toDefectVector before after =
      FiniteMatrixSchurPort.toDefectVector
        (toInvertibleSchurBlocks before)
        (toInvertibleSchurBlocks after) := rfl

/-- Der SchurSummary-Trace ist weiterhin derjenige des Matrix-Schur-Ports. -/
theorem toSchurSummary_trace {V : Type} (b : CertifiedSchurBlocks V) :
    (toSchurSummary b).schurDtnTrace =
      FiniteMatrixSchurPort.schurTrace (toInvertibleSchurBlocks b) := rfl

/-- Der Cut-Defekt wird unveraendert durchgereicht. -/
theorem toSchurSummary_cutDefect {V : Type} (b : CertifiedSchurBlocks V) :
    (toSchurSummary b).schurCutDefect = b.raw.cutDefect := rfl

/-- Gleiche Schur-Traces erzeugen keinen DtN-Defekt. -/
theorem dtn_defect_zero_of_same_trace {V : Type}
    (before after : CertifiedSchurBlocks V)
    (h : FiniteMatrixSchurPort.schurTrace (toInvertibleSchurBlocks before) =
         FiniteMatrixSchurPort.schurTrace (toInvertibleSchurBlocks after)) :
    FiniteHandoffSummary.dtnDefect (toHandoffData before after) = 0 := by
  exact FiniteMatrixSchurPort.dtn_defect_zero_of_same_trace
    (toInvertibleSchurBlocks before) (toInvertibleSchurBlocks after) h

/-- Marker: Diese Datei schliesst den algebraischen Witness-Port, aber nicht die
    konkrete arithmetische Dirichlet-Inversenrechnung und nicht das J-Vorzeichen. -/
def arithmeticDirichletInverseStillOpen : Prop := True

theorem arithmetic_gate_not_closed_here : arithmeticDirichletInverseStillOpen :=
  True.intro

end DirichletInverseWitness
