import CNNA.FillOrbitBasinCriterion

namespace FillOrbitEndpointCodeCriterion

abbrev CurrentAddress := SchurDtnDerivedAddressSeed.Address
abbrev Node := Fin 3
abbrev FillEndpoint := CanonicalFillOrderCriterion.FillEndpoint
abbrev AbstractAddressSeed :=
  AbstractAddressTypeGrowthCriterion.AbstractAddressSeed
abbrev CurrentSeedCriterion :=
  AbstractAddressTypeGrowthCriterion.CurrentSeedCriterion

inductive LocalOrbitFlowRole where
  | fixedZeroBase
  | fixedOneSelected
  | frontierInflowToSelected
  | uncheckedOther
  deriving BEq, DecidableEq


def orbitFlowRoleOfValue : Nat -> LocalOrbitFlowRole
  | 0 => LocalOrbitFlowRole.fixedZeroBase
  | 1 => LocalOrbitFlowRole.fixedOneSelected
  | 2 => LocalOrbitFlowRole.frontierInflowToSelected
  | _ => LocalOrbitFlowRole.uncheckedOther


def currentOrbitFlowRole (a : CurrentAddress) : LocalOrbitFlowRole :=
  orbitFlowRoleOfValue (FillOrbitBasinCriterion.currentFillValue a)


def endpointCodeOfOrbitFlowRole : LocalOrbitFlowRole -> FillEndpoint
  | LocalOrbitFlowRole.fixedZeroBase =>
      CanonicalFillOrderCriterion.FillEndpoint.repeller
  | LocalOrbitFlowRole.fixedOneSelected =>
      CanonicalFillOrderCriterion.FillEndpoint.transit
  | LocalOrbitFlowRole.frontierInflowToSelected =>
      CanonicalFillOrderCriterion.FillEndpoint.attractor
  | LocalOrbitFlowRole.uncheckedOther =>
      CanonicalFillOrderCriterion.FillEndpoint.transit


def currentEndpointCodeFromOrbitFlow (a : CurrentAddress) : FillEndpoint :=
  endpointCodeOfOrbitFlowRole (currentOrbitFlowRole a)


def currentNodeOfFromOrbitFlow (a : CurrentAddress) : Node :=
  CanonicalFillOrderCriterion.fillEndpointRank
    (currentEndpointCodeFromOrbitFlow a)


theorem fixed_zero_base_is_fill_map_fixed :
    CanonicalFillOrderCriterion.localFillMap 2 0 = 0 := rfl


theorem fixed_one_selected_is_fill_map_fixed :
    CanonicalFillOrderCriterion.localFillMap 2 1 = 1 := rfl


theorem frontier_inflow_value_flows_to_selected_value :
    CanonicalFillOrderCriterion.localFillMap 2 2 = 1 := rfl


theorem frontier_inflow_value_not_selected_value :
    2 ≠ 1 := by
  intro h
  cases h


theorem current_flow_role_cut_root_fixed_zero_base :
    currentOrbitFlowRole SchurDtnDerivedAddressSeed.cutRoot =
      LocalOrbitFlowRole.fixedZeroBase := rfl


theorem current_flow_role_selected_fixed_one_selected :
    currentOrbitFlowRole SchurDtnDerivedAddressSeed.selectedChild =
      LocalOrbitFlowRole.fixedOneSelected := rfl


theorem current_flow_role_frontier_inflow_to_selected :
    currentOrbitFlowRole SchurDtnDerivedAddressSeed.frontierPortAddress =
      LocalOrbitFlowRole.frontierInflowToSelected := by
  change currentOrbitFlowRole
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) =
      LocalOrbitFlowRole.frontierInflowToSelected
  rfl


def frontierInflowDynamicSeparation : Prop :=
  CanonicalFillOrderCriterion.localFillMap 2
      (FillOrbitBasinCriterion.currentFillValue
        SchurDtnDerivedAddressSeed.frontierPortAddress) =
    FillOrbitBasinCriterion.currentFillValue
      SchurDtnDerivedAddressSeed.selectedChild ∧
  FillOrbitBasinCriterion.currentFillValue
      SchurDtnDerivedAddressSeed.frontierPortAddress ≠
    FillOrbitBasinCriterion.currentFillValue
      SchurDtnDerivedAddressSeed.selectedChild


theorem current_frontier_inflow_dynamic_separation :
    frontierInflowDynamicSeparation := by
  constructor
  · exact FillOrbitBasinCriterion.current_frontier_fill_value_flows_to_selected_value
  · change 2 ≠ 1
    exact frontier_inflow_value_not_selected_value


theorem current_endpoint_code_cut_root_repeller :
    currentEndpointCodeFromOrbitFlow SchurDtnDerivedAddressSeed.cutRoot =
      CanonicalFillOrderCriterion.FillEndpoint.repeller := rfl


theorem current_endpoint_code_selected_transit :
    currentEndpointCodeFromOrbitFlow SchurDtnDerivedAddressSeed.selectedChild =
      CanonicalFillOrderCriterion.FillEndpoint.transit := rfl


theorem current_endpoint_code_frontier_legacy_attractor_code :
    currentEndpointCodeFromOrbitFlow
      SchurDtnDerivedAddressSeed.frontierPortAddress =
      CanonicalFillOrderCriterion.FillEndpoint.attractor := by
  change currentEndpointCodeFromOrbitFlow
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) =
      CanonicalFillOrderCriterion.FillEndpoint.attractor
  rfl


def frontierInflowUsesLegacyAttractorCode : Prop :=
  currentOrbitFlowRole SchurDtnDerivedAddressSeed.frontierPortAddress =
      LocalOrbitFlowRole.frontierInflowToSelected ∧
  currentEndpointCodeFromOrbitFlow
      SchurDtnDerivedAddressSeed.frontierPortAddress =
      CanonicalFillOrderCriterion.FillEndpoint.attractor ∧
  CanonicalFillOrderCriterion.localFillMap 2
      (FillOrbitBasinCriterion.currentFillValue
        SchurDtnDerivedAddressSeed.frontierPortAddress) =
      FillOrbitBasinCriterion.currentFillValue
        SchurDtnDerivedAddressSeed.selectedChild


theorem frontier_inflow_uses_legacy_attractor_code :
    frontierInflowUsesLegacyAttractorCode :=
  And.intro
    current_flow_role_frontier_inflow_to_selected
    (And.intro
      current_endpoint_code_frontier_legacy_attractor_code
      FillOrbitBasinCriterion.current_frontier_fill_value_flows_to_selected_value)


theorem current_endpoint_code_eq_orbit_endpoint_diagnostic :
    currentEndpointCodeFromOrbitFlow =
      FillOrbitBasinCriterion.currentOrbitEndpointDiagnostic := by
  funext a
  cases a with
  | root => rfl
  | child b =>
      cases b <;> rfl


theorem current_orbit_flow_nodeOf_eq_orbit_nodeOf :
    currentNodeOfFromOrbitFlow =
      FillOrbitBasinCriterion.currentOrbitNodeOf := by
  funext a
  cases a with
  | root => rfl
  | child b =>
      cases b <;> rfl


theorem current_orbit_flow_nodeOf_eq_fill_order_nodeOf :
    currentNodeOfFromOrbitFlow =
      CanonicalFillOrderCriterion.currentFillRankNodeOf := by
  rw [current_orbit_flow_nodeOf_eq_orbit_nodeOf]
  exact FillOrbitBasinCriterion.current_orbit_nodeOf_eq_fill_order_nodeOf


theorem current_orbit_flow_cut_root_node_zero :
    currentNodeOfFromOrbitFlow SchurDtnDerivedAddressSeed.cutRoot = 0 := rfl


theorem current_orbit_flow_selected_node_one :
    currentNodeOfFromOrbitFlow SchurDtnDerivedAddressSeed.selectedChild = 1 := rfl


theorem current_orbit_flow_frontier_node_two :
    currentNodeOfFromOrbitFlow
      SchurDtnDerivedAddressSeed.frontierPortAddress = 2 := by
  change currentNodeOfFromOrbitFlow
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) = 2
  rfl


def currentOrbitFlowAbstractSeed : AbstractAddressSeed CurrentAddress :=
  { cutRoot := SchurDtnDerivedAddressSeed.cutRoot,
    selectedAddress := SchurDtnDerivedAddressSeed.selectedChild,
    frontierAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    sourceAddress := SchurDtnDerivedAddressSeed.cutRoot,
    targetAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    visibleRoles := SchurDtnDerivedAddressSeed.roleAddresses,
    beforeRank := 0,
    afterRank := 1,
    nodeOf := currentNodeOfFromOrbitFlow }


theorem current_orbit_flow_frontier_outside_visible :
    AbstractAddressTypeGrowthCriterion.outsideVisible
      currentOrbitFlowAbstractSeed.visibleRoles
      currentOrbitFlowAbstractSeed.frontierAddress = true := rfl


def currentOrbitFlowSeedCriterion :
    CurrentSeedCriterion currentOrbitFlowAbstractSeed :=
  { source_is_cut_root := rfl,
    target_is_frontier := rfl,
    rank_increases := rfl,
    frontier_outside_visible := current_orbit_flow_frontier_outside_visible,
    source_node_zero := current_orbit_flow_cut_root_node_zero,
    frontier_node_two := current_orbit_flow_frontier_node_two,
    cut_root_is_local := rfl,
    frontier_is_local := rfl }


theorem orbit_flow_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentOrbitFlowAbstractSeed) 0 2 = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_forward_edge
    currentOrbitFlowSeedCriterion


theorem orbit_flow_closes_g1_path :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  GrowthEdgeProvenance.derived_growth_status


def fillOrbitEndpointCodeStillLocalSemanticsBridge : Prop := True


theorem fill_orbit_endpoint_code_still_local_semantics_bridge :
    fillOrbitEndpointCodeStillLocalSemanticsBridge :=
  True.intro

end FillOrbitEndpointCodeCriterion
