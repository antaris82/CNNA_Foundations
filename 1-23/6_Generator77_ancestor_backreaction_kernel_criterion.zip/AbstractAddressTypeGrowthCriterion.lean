import CNNA.GenericAddressGrowthCriterion

namespace AbstractAddressTypeGrowthCriterion

abbrev Node := Fin 3
abbrev CurrentAddress := SchurDtnDerivedAddressSeed.Address
abbrev GenericLocalSeed := GenericAddressGrowthCriterion.GenericLocalSeed
abbrev LocalGrowthRule := GrowthEdgeProvenance.LocalGrowthRule

structure AbstractAddressSeed (A : Type) where
  cutRoot : A
  selectedAddress : A
  frontierAddress : A
  sourceAddress : A
  targetAddress : A
  visibleRoles : List A
  beforeRank : Nat
  afterRank : Nat
  nodeOf : A -> Node


def contains {A : Type} [BEq A] (x : A) : List A -> Bool
  | [] => false
  | y :: ys => if x == y then true else contains x ys


def outsideVisible {A : Type} [BEq A] (visible : List A) (x : A) : Bool :=
  if contains x visible then false else true


structure AbstractSeedCriterion {A : Type} [BEq A]
    (s : AbstractAddressSeed A) where
  source_is_cut_root : s.sourceAddress = s.cutRoot
  target_is_frontier : s.targetAddress = s.frontierAddress
  rank_increases : decide (s.beforeRank < s.afterRank) = true
  frontier_outside_visible : outsideVisible s.visibleRoles s.frontierAddress = true
  source_node_zero : s.nodeOf s.cutRoot = 0
  frontier_node_two : s.nodeOf s.frontierAddress = 2


structure CurrentSeedCriterion (s : AbstractAddressSeed CurrentAddress) where
  source_is_cut_root : s.sourceAddress = s.cutRoot
  target_is_frontier : s.targetAddress = s.frontierAddress
  rank_increases : decide (s.beforeRank < s.afterRank) = true
  frontier_outside_visible : outsideVisible s.visibleRoles s.frontierAddress = true
  source_node_zero : s.nodeOf s.cutRoot = 0
  frontier_node_two : s.nodeOf s.frontierAddress = 2
  cut_root_is_local : s.cutRoot = SchurDtnDerivedAddressSeed.cutRoot
  frontier_is_local :
    s.frontierAddress = SchurDtnDerivedAddressSeed.frontierPortAddress


def toGenericLocalSeed (s : AbstractAddressSeed CurrentAddress) :
    GenericLocalSeed :=
  { cutRoot := s.cutRoot,
    selectedAddress := s.selectedAddress,
    frontierAddress := s.frontierAddress,
    sourceAddress := s.sourceAddress,
    targetAddress := s.targetAddress,
    beforeRank := s.beforeRank,
    afterRank := s.afterRank }


def toLocalGrowthRule (s : AbstractAddressSeed CurrentAddress) :
    LocalGrowthRule :=
  GenericAddressGrowthCriterion.toLocalGrowthRule (toGenericLocalSeed s)


def toGenericSeedCriterion {s : AbstractAddressSeed CurrentAddress}
    (c : CurrentSeedCriterion s) :
    GenericAddressGrowthCriterion.SeedCriterion (toGenericLocalSeed s) :=
  { cut_root_is_local := c.cut_root_is_local,
    frontier_is_local := c.frontier_is_local,
    source_is_cut_root := c.source_is_cut_root,
    target_is_frontier := c.target_is_frontier,
    rank_increases := c.rank_increases }


theorem generic_seed_growth_active {s : AbstractAddressSeed CurrentAddress}
    (c : CurrentSeedCriterion s) :
    GrowthEdgeProvenance.growthActive (toLocalGrowthRule s) = true :=
  GenericAddressGrowthCriterion.growth_active_of_seed_criterion
    (toGenericSeedCriterion c)


theorem generic_seed_forward_edge {s : AbstractAddressSeed CurrentAddress}
    (c : CurrentSeedCriterion s) :
    GrowthEdgeProvenance.growthAdjacent (toLocalGrowthRule s) 0 2 = true :=
  GenericAddressGrowthCriterion.growth_edge_forward_of_seed_criterion
    (toGenericSeedCriterion c)


theorem generic_seed_backward_edge {s : AbstractAddressSeed CurrentAddress}
    (c : CurrentSeedCriterion s) :
    GrowthEdgeProvenance.growthAdjacent (toLocalGrowthRule s) 2 0 = true :=
  GenericAddressGrowthCriterion.growth_edge_backward_of_seed_criterion
    (toGenericSeedCriterion c)


def currentAbstractSeed : AbstractAddressSeed CurrentAddress :=
  { cutRoot := SchurDtnDerivedAddressSeed.cutRoot,
    selectedAddress := SchurDtnDerivedAddressSeed.selectedChild,
    frontierAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    sourceAddress := SchurDtnDerivedAddressSeed.cutRoot,
    targetAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    visibleRoles := SchurDtnDerivedAddressSeed.roleAddresses,
    beforeRank := 0,
    afterRank := 1,
    nodeOf := SchurDtnDerivedAddressSeed.addressNode }


theorem current_frontier_outside_visible :
    outsideVisible currentAbstractSeed.visibleRoles
      currentAbstractSeed.frontierAddress = true := rfl


theorem current_source_node_zero :
    currentAbstractSeed.nodeOf currentAbstractSeed.cutRoot = 0 := rfl


theorem current_frontier_node_two :
    currentAbstractSeed.nodeOf currentAbstractSeed.frontierAddress = 2 := by
  change SchurDtnDerivedAddressSeed.frontierPortNode = 2
  exact SchurDtnDerivedAddressSeed.frontier_port_node_derived


def currentSeedCriterion : CurrentSeedCriterion currentAbstractSeed :=
  { source_is_cut_root := rfl,
    target_is_frontier := rfl,
    rank_increases := rfl,
    frontier_outside_visible := current_frontier_outside_visible,
    source_node_zero := current_source_node_zero,
    frontier_node_two := current_frontier_node_two,
    cut_root_is_local := rfl,
    frontier_is_local := rfl }


theorem current_abstract_seed_to_generic_seed :
    toGenericLocalSeed currentAbstractSeed =
      GenericAddressGrowthCriterion.activeGenericSeed := rfl


theorem current_abstract_seed_to_local_rule :
    toLocalGrowthRule currentAbstractSeed =
      GrowthEdgeProvenance.activeAddressGrowthRule := rfl


theorem current_abstract_seed_growth_active :
    GrowthEdgeProvenance.growthActive
      (toLocalGrowthRule currentAbstractSeed) = true :=
  generic_seed_growth_active currentSeedCriterion


theorem current_abstract_seed_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (toLocalGrowthRule currentAbstractSeed) 0 2 = true :=
  generic_seed_forward_edge currentSeedCriterion


theorem current_abstract_seed_backward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (toLocalGrowthRule currentAbstractSeed) 2 0 = true :=
  generic_seed_backward_edge currentSeedCriterion


theorem current_abstract_seed_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  GrowthEdgeProvenance.derived_growth_status


def abstractCriterionStillNodeNumbered : Prop := True


theorem abstract_criterion_still_node_numbered :
    abstractCriterionStillNodeNumbered :=
  True.intro


end AbstractAddressTypeGrowthCriterion
