import CNNA.AddressGrowthEdgeCriterion

namespace GenericAddressGrowthCriterion

abbrev LocalGrowthRule := GrowthEdgeProvenance.LocalGrowthRule
abbrev Address := SchurDtnDerivedAddressSeed.Address
abbrev Node := Fin 3

structure GenericLocalSeed where
  cutRoot : Address
  selectedAddress : Address
  frontierAddress : Address
  sourceAddress : Address
  targetAddress : Address
  beforeRank : Nat
  afterRank : Nat


def toLocalGrowthRule (s : GenericLocalSeed) : LocalGrowthRule :=
  { sourceAddress := s.sourceAddress,
    targetAddress := s.targetAddress,
    beforeRank := s.beforeRank,
    afterRank := s.afterRank }


structure SeedCriterion (s : GenericLocalSeed) where
  cut_root_is_local : s.cutRoot = SchurDtnDerivedAddressSeed.cutRoot
  frontier_is_local :
    s.frontierAddress = SchurDtnDerivedAddressSeed.frontierPortAddress
  source_is_cut_root : s.sourceAddress = s.cutRoot
  target_is_frontier : s.targetAddress = s.frontierAddress
  rank_increases : decide (s.beforeRank < s.afterRank) = true


theorem source_is_local_cut_root {s : GenericLocalSeed}
    (c : SeedCriterion s) :
    (toLocalGrowthRule s).sourceAddress =
      SchurDtnDerivedAddressSeed.cutRoot := by
  unfold toLocalGrowthRule
  rw [c.source_is_cut_root, c.cut_root_is_local]


theorem target_is_local_frontier {s : GenericLocalSeed}
    (c : SeedCriterion s) :
    (toLocalGrowthRule s).targetAddress =
      SchurDtnDerivedAddressSeed.frontierPortAddress := by
  unfold toLocalGrowthRule
  rw [c.target_is_frontier, c.frontier_is_local]


theorem rank_increases_of_seed_criterion {s : GenericLocalSeed}
    (c : SeedCriterion s) :
    GrowthEdgeProvenance.rankIncreases (toLocalGrowthRule s) = true := by
  unfold GrowthEdgeProvenance.rankIncreases toLocalGrowthRule
  exact c.rank_increases


theorem target_outside_roles_of_seed_criterion {s : GenericLocalSeed}
    (c : SeedCriterion s) :
    GrowthEdgeProvenance.targetOutsideRoles (toLocalGrowthRule s) = true := by
  unfold GrowthEdgeProvenance.targetOutsideRoles toLocalGrowthRule
  rw [c.target_is_frontier, c.frontier_is_local]
  rfl


def toAddressCriterion {s : GenericLocalSeed}
    (c : SeedCriterion s) :
    AddressGrowthEdgeCriterion.AddressCriterion (toLocalGrowthRule s) :=
  { source_is_cut_root := source_is_local_cut_root c,
    target_is_frontier := target_is_local_frontier c,
    rank_increases := rank_increases_of_seed_criterion c,
    target_outside_roles := target_outside_roles_of_seed_criterion c }


theorem growth_active_of_seed_criterion {s : GenericLocalSeed}
    (c : SeedCriterion s) :
    GrowthEdgeProvenance.growthActive (toLocalGrowthRule s) = true :=
  AddressGrowthEdgeCriterion.growth_active_of_address_criterion
    (toAddressCriterion c)


theorem source_node_zero_of_seed_criterion {s : GenericLocalSeed}
    (c : SeedCriterion s) :
    GrowthEdgeProvenance.sourceNode (toLocalGrowthRule s) = 0 :=
  AddressGrowthEdgeCriterion.source_zero_of_address_criterion
    (toAddressCriterion c)


theorem target_node_two_of_seed_criterion {s : GenericLocalSeed}
    (c : SeedCriterion s) :
    GrowthEdgeProvenance.targetNode (toLocalGrowthRule s) = 2 :=
  AddressGrowthEdgeCriterion.target_two_of_address_criterion
    (toAddressCriterion c)


theorem growth_edge_forward_of_seed_criterion {s : GenericLocalSeed}
    (c : SeedCriterion s) :
    GrowthEdgeProvenance.growthAdjacent (toLocalGrowthRule s) 0 2 = true :=
  AddressGrowthEdgeCriterion.growth_edge_forward_of_address_criterion
    (toAddressCriterion c)


theorem growth_edge_backward_of_seed_criterion {s : GenericLocalSeed}
    (c : SeedCriterion s) :
    GrowthEdgeProvenance.growthAdjacent (toLocalGrowthRule s) 2 0 = true :=
  AddressGrowthEdgeCriterion.growth_edge_backward_of_address_criterion
    (toAddressCriterion c)


def activeGenericSeed : GenericLocalSeed :=
  { cutRoot := SchurDtnDerivedAddressSeed.cutRoot,
    selectedAddress := SchurDtnDerivedAddressSeed.selectedChild,
    frontierAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    sourceAddress := SchurDtnDerivedAddressSeed.cutRoot,
    targetAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    beforeRank := 0,
    afterRank := 1 }


theorem active_generic_seed_rule_eq_current :
    toLocalGrowthRule activeGenericSeed =
      GrowthEdgeProvenance.activeAddressGrowthRule := rfl


def activeSeedCriterion : SeedCriterion activeGenericSeed :=
  { cut_root_is_local := rfl,
    frontier_is_local := rfl,
    source_is_cut_root := rfl,
    target_is_frontier := rfl,
    rank_increases := rfl }


theorem active_seed_criterion_to_address_criterion :
    toAddressCriterion activeSeedCriterion =
      AddressGrowthEdgeCriterion.activeAddressCriterion := rfl


theorem active_generic_seed_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (toLocalGrowthRule activeGenericSeed) 0 2 = true :=
  growth_edge_forward_of_seed_criterion activeSeedCriterion


theorem active_generic_seed_backward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (toLocalGrowthRule activeGenericSeed) 2 0 = true :=
  growth_edge_backward_of_seed_criterion activeSeedCriterion


theorem active_generic_seed_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  GrowthEdgeProvenance.derived_growth_status


def genericCriterionStillCurrentAddressType : Prop := True


theorem generic_criterion_still_current_address_type :
    genericCriterionStillCurrentAddressType :=
  True.intro

end GenericAddressGrowthCriterion
