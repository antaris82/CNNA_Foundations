import CNNA.OppositeSectorNoGo

/-
  UniqueLockSectorClosure.lean
  ----------------------------
  Positives Gegenstueck zum OppositeSectorNoGo.

  Diese Datei kapselt die allgemeine positive Closure-Seite:

    Wenn alle kohärenten Lock-Kandidaten einer Liste dasselbe J-Sign tragen,
    dann ist das J-Sign im formalen Closure-Kriterium geschlossen.

  Speziell: Wenn ein DefectSystem-Minset ein Singleton ist, dann erzeugt jeder
  Growth-to-Lock-Pushforward eine singleton Lock-Liste und damit ein resolved
  J-Sign. Keine freie Orientierung, kein Tie-Break.
-/

namespace UniqueLockSectorClosure

abbrev LockCandidate := JLockingGate.LockCandidate
abbrev Sign := JLockingGate.Sign
abbrev DefectSystem := SectorResolutionGate.DefectSystem

/-- Alle kohärenten Kandidaten einer Liste tragen dasselbe J-Sign. -/
def allCoherentHaveSign (cs : List LockCandidate) (s : Sign) : Prop :=
  ∀ c, c ∈ cs -> JLockingGate.coherent c -> c.j = s

/-- Wenn alle kohärenten Kandidaten einer Liste dasselbe J-Sign tragen, ist das
    formale J-Sign-Closure-Kriterium erfuellt. -/
theorem has_closed_of_all_coherent_have_sign (cs : List LockCandidate)
    (s : Sign) (h : allCoherentHaveSign cs s) :
    JSignClosureCriterion.hasClosedJSign cs := by
  unfold JSignClosureCriterion.hasClosedJSign
  exact Exists.intro s h

/-- Ein einzelner kohärenter Sektor, relativ zu einer Kandidatenliste. -/
def uniqueCoherentSector (cs : List LockCandidate) (c : LockCandidate) : Prop :=
  c ∈ cs ∧ JLockingGate.coherent c ∧
    ∀ d, d ∈ cs -> JLockingGate.coherent d -> d.j = c.j

/-- Ein eindeutiger kohärenter Sektor schliesst das J-Sign. -/
theorem has_closed_of_unique_coherent_sector (cs : List LockCandidate)
    (c : LockCandidate) (h : uniqueCoherentSector cs c) :
    JSignClosureCriterion.hasClosedJSign cs :=
  has_closed_of_all_coherent_have_sign cs c.j h.right.right

/-- Eine singleton Lock-Liste hat ein geschlossenes J-Sign. -/
theorem singleton_has_closed_j_sign (c : LockCandidate) :
    JSignClosureCriterion.hasClosedJSign [c] := by
  unfold JSignClosureCriterion.hasClosedJSign
    JSignClosureCriterion.closesJSign
  exact Exists.intro c.j (by
    intro d hd _
    simp at hd
    rw [hd])

/-- Wenn der Lock-Pushforward eines DefectSystems eine singleton Liste ist,
    dann ist das DefectSystem resolved. -/
theorem resolved_of_singleton_lockCandidates {A : Type} (D : DefectSystem A)
    (lockOf : A -> LockCandidate) (c : LockCandidate)
    (hlist : SectorResolutionGate.lockCandidates D lockOf = [c]) :
    SectorResolutionGate.hasResolvedJSign D lockOf := by
  unfold SectorResolutionGate.hasResolvedJSign
  rw [hlist]
  exact singleton_has_closed_j_sign c

/-- Wenn das kanonische Minset eines DefectSystems ein Singleton ist, dann ist
    der Lock-Pushforward resolved. Das ist die formale Fassung von
    MinSet = {alpha} -> resolved J-Sign. -/
theorem resolved_of_minSet_singleton {A : Type} (D : DefectSystem A)
    (lockOf : A -> LockCandidate) (a : A) (hmin : D.minSet = [a]) :
    SectorResolutionGate.hasResolvedJSign D lockOf := by
  apply resolved_of_singleton_lockCandidates D lockOf (lockOf a)
  unfold SectorResolutionGate.lockCandidates
  rw [hmin]
  rfl

/-- Growth-Sector-Variante des singleton-Minset-Gates. -/
theorem growth_resolved_of_minSet_singleton {A : Type}
    (M : GrowthSectorResolutionBridge.GrowthSectorMap A)
    (D : DefectSystem A) (a : A) (hmin : D.minSet = [a]) :
    M.hasResolvedJSign D := by
  change SectorResolutionGate.hasResolvedJSign D M.lockOf
  exact resolved_of_minSet_singleton D M.lockOf a hmin

/-! ## Instanzen aus dem aktuellen Generator-Spine -/

/-- Der eindeutige Miniport-Pushforward ist eine singleton Lock-Liste. -/
theorem oneInterior_lockCandidates_singleton :
    GrowthSectorResolutionBridge.oneInteriorSectorMap.lockCandidates
      OneInteriorGrowthKernelExample.oneInteriorDefectSystem =
      [JLockingGate.plusLock] := by
  rw [GrowthSectorResolutionBridge.oneInterior_growth_locks_eq_plusSector]
  rfl

/-- Der eindeutige Miniport-Fall ist durch das singleton-Minset-Gate resolved. -/
theorem oneInterior_resolved_by_unique_lock :
    GrowthSectorResolutionBridge.oneInteriorSectorMap.hasResolvedJSign
      OneInteriorGrowthKernelExample.oneInteriorDefectSystem :=
  resolved_of_singleton_lockCandidates
    OneInteriorGrowthKernelExample.oneInteriorDefectSystem
    GrowthSectorResolutionBridge.oneInteriorSectorMap.lockOf
    JLockingGate.plusLock
    oneInterior_lockCandidates_singleton

/-- Positives Gegenstueck zum Opposite-No-Go im aktuellen Spine: Der eindeutige
    Lock-Sektor schliesst, weil die Lock-Kandidatenliste ein Singleton ist. -/
theorem oneInterior_kernel_and_unique_lock_closure :
    OneInteriorGrowthKernelExample.oneInteriorDefectSystem.kernel = 1 ∧
    GrowthSectorResolutionBridge.oneInteriorSectorMap.hasResolvedJSign
      OneInteriorGrowthKernelExample.oneInteriorDefectSystem :=
  And.intro OneInteriorGrowthKernelExample.oneInterior_kernel_one
    oneInterior_resolved_by_unique_lock

/-- Statusmarker: eindeutige kohärente Lock-Sektoren sind der positive
    Closure-Fall, entgegengesetzte Paare der negative Fall. -/
def uniqueSectorIsClosureCase : Prop := True

theorem unique_sector_is_closure_case : uniqueSectorIsClosureCase :=
  True.intro

end UniqueLockSectorClosure
