import CNNA.CanonicalRoleOrderCriterion

namespace CanonicalFillOrderCriterion

abbrev Node := Fin 3
abbrev CurrentAddress := SchurDtnDerivedAddressSeed.Address
abbrev InterfaceRole := CanonicalRoleOrderCriterion.InterfaceRole
abbrev InterfaceRoleOrder := CanonicalRoleOrderCriterion.InterfaceRoleOrder
abbrev CurrentSeedCriterion := AbstractAddressTypeGrowthCriterion.CurrentSeedCriterion
abbrev AbstractAddressSeed := AbstractAddressTypeGrowthCriterion.AbstractAddressSeed

inductive FillEndpoint where
  | repeller
  | transit
  | attractor
  deriving BEq, DecidableEq


def localFillMap (b c : Nat) : Nat :=
  (b * c) / (1 + c)


theorem local_fill_map_zero_fixed :
    localFillMap 2 0 = 0 := rfl


theorem local_fill_map_one_fixed :
    localFillMap 2 1 = 1 := rfl


def fillEndpointOfRole : InterfaceRole -> FillEndpoint
  | CanonicalRoleOrderCriterion.InterfaceRole.boundaryAnchor =>
      FillEndpoint.repeller
  | CanonicalRoleOrderCriterion.InterfaceRole.brightSelected =>
      FillEndpoint.transit
  | CanonicalRoleOrderCriterion.InterfaceRole.frontierResidual =>
      FillEndpoint.attractor


def fillEndpointRank : FillEndpoint -> Node
  | FillEndpoint.repeller => 0
  | FillEndpoint.transit => 1
  | FillEndpoint.attractor => 2


def fillRankOfRole (r : InterfaceRole) : Node :=
  fillEndpointRank (fillEndpointOfRole r)


theorem fill_rank_boundary_zero :
    fillRankOfRole
      CanonicalRoleOrderCriterion.InterfaceRole.boundaryAnchor = 0 := rfl


theorem fill_rank_bright_one :
    fillRankOfRole
      CanonicalRoleOrderCriterion.InterfaceRole.brightSelected = 1 := rfl


theorem fill_rank_frontier_two :
    fillRankOfRole
      CanonicalRoleOrderCriterion.InterfaceRole.frontierResidual = 2 := rfl


theorem fill_rank_matches_canonical_role_order
    (r : InterfaceRole) :
    fillRankOfRole r =
      CanonicalRoleOrderCriterion.roleNumberFromOrder
        CanonicalRoleOrderCriterion.canonicalInterfaceRoleOrder r := by
  cases r <;> rfl


def nodeOfFromFillRank {A : Type} [BEq A]
    (r : CanonicalRoleOrderCriterion.InterfaceRoleAssignment A)
    (a : A) : Node :=
  fillRankOfRole (CanonicalRoleOrderCriterion.roleOfAddress r a)


def currentFillRankNodeOf : CurrentAddress -> Node :=
  nodeOfFromFillRank
    CanonicalRoleOrderCriterion.currentInterfaceRoleAssignment


theorem current_fill_rank_nodeOf_eq_role_order_nodeOf :
    currentFillRankNodeOf =
      CanonicalRoleOrderCriterion.currentRoleOrderNodeOf := by
  funext a
  unfold currentFillRankNodeOf
    CanonicalRoleOrderCriterion.currentRoleOrderNodeOf
    nodeOfFromFillRank
    CanonicalRoleOrderCriterion.nodeOfFromInterfaceRoles
  exact fill_rank_matches_canonical_role_order
    (CanonicalRoleOrderCriterion.roleOfAddress
      CanonicalRoleOrderCriterion.currentInterfaceRoleAssignment a)


theorem current_fill_cut_root_node_zero :
    currentFillRankNodeOf SchurDtnDerivedAddressSeed.cutRoot = 0 := rfl


theorem current_fill_selected_node_one :
    currentFillRankNodeOf SchurDtnDerivedAddressSeed.selectedChild = 1 := rfl


theorem current_fill_frontier_node_two :
    currentFillRankNodeOf
      SchurDtnDerivedAddressSeed.frontierPortAddress = 2 := by
  change currentFillRankNodeOf
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) = 2
  rfl


def currentFillAbstractSeed : AbstractAddressSeed CurrentAddress :=
  { cutRoot := SchurDtnDerivedAddressSeed.cutRoot,
    selectedAddress := SchurDtnDerivedAddressSeed.selectedChild,
    frontierAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    sourceAddress := SchurDtnDerivedAddressSeed.cutRoot,
    targetAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    visibleRoles := SchurDtnDerivedAddressSeed.roleAddresses,
    beforeRank := 0,
    afterRank := 1,
    nodeOf := currentFillRankNodeOf }


theorem current_fill_frontier_outside_visible :
    AbstractAddressTypeGrowthCriterion.outsideVisible
      currentFillAbstractSeed.visibleRoles
      currentFillAbstractSeed.frontierAddress = true := rfl


theorem current_fill_source_node_zero :
    currentFillAbstractSeed.nodeOf
      currentFillAbstractSeed.cutRoot = 0 :=
  current_fill_cut_root_node_zero


theorem current_fill_frontier_node_two_in_seed :
    currentFillAbstractSeed.nodeOf
      currentFillAbstractSeed.frontierAddress = 2 :=
  current_fill_frontier_node_two


def currentFillSeedCriterion :
    CurrentSeedCriterion currentFillAbstractSeed :=
  { source_is_cut_root := rfl,
    target_is_frontier := rfl,
    rank_increases := rfl,
    frontier_outside_visible := current_fill_frontier_outside_visible,
    source_node_zero := current_fill_source_node_zero,
    frontier_node_two := current_fill_frontier_node_two_in_seed,
    cut_root_is_local := rfl,
    frontier_is_local := rfl }


theorem current_fill_seed_to_local_rule :
    AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
      currentFillAbstractSeed =
      GrowthEdgeProvenance.activeAddressGrowthRule := rfl


theorem canonical_fill_order_growth_active :
    GrowthEdgeProvenance.growthActive
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentFillAbstractSeed) = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_growth_active
    currentFillSeedCriterion


theorem canonical_fill_order_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentFillAbstractSeed) 0 2 = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_forward_edge
    currentFillSeedCriterion


theorem canonical_fill_order_backward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentFillAbstractSeed) 2 0 = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_backward_edge
    currentFillSeedCriterion


theorem canonical_fill_order_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  GrowthEdgeProvenance.derived_growth_status


def reversedInterfaceRoleOrder : InterfaceRoleOrder :=
  { first := CanonicalRoleOrderCriterion.InterfaceRole.frontierResidual,
    second := CanonicalRoleOrderCriterion.InterfaceRole.brightSelected,
    third := CanonicalRoleOrderCriterion.InterfaceRole.boundaryAnchor }


theorem reversed_order_boundary_two :
    CanonicalRoleOrderCriterion.roleNumberFromOrder
      reversedInterfaceRoleOrder
      CanonicalRoleOrderCriterion.InterfaceRole.boundaryAnchor = 2 := rfl


theorem reversed_order_bright_one :
    CanonicalRoleOrderCriterion.roleNumberFromOrder
      reversedInterfaceRoleOrder
      CanonicalRoleOrderCriterion.InterfaceRole.brightSelected = 1 := rfl


theorem reversed_order_frontier_zero :
    CanonicalRoleOrderCriterion.roleNumberFromOrder
      reversedInterfaceRoleOrder
      CanonicalRoleOrderCriterion.InterfaceRole.frontierResidual = 0 := rfl


def reversalChangesFillFrontierRank : Prop :=
  CanonicalRoleOrderCriterion.roleNumberFromOrder
    reversedInterfaceRoleOrder
    CanonicalRoleOrderCriterion.InterfaceRole.frontierResidual = 0 ∧
  fillRankOfRole
    CanonicalRoleOrderCriterion.InterfaceRole.frontierResidual = 2


theorem reversal_changes_fill_frontier_rank :
    reversalChangesFillFrontierRank :=
  And.intro reversed_order_frontier_zero fill_rank_frontier_two


def fillOrderStillLocalEndpointClassification : Prop := True


theorem fill_order_still_local_endpoint_classification :
    fillOrderStillLocalEndpointClassification :=
  True.intro

end CanonicalFillOrderCriterion
