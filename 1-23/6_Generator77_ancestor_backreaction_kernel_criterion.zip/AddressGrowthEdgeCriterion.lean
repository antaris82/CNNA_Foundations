import CNNA.LocalGrowthEdgeCriterion

namespace AddressGrowthEdgeCriterion

abbrev LocalGrowthRule := GrowthEdgeProvenance.LocalGrowthRule
abbrev Address := SchurDtnDerivedAddressSeed.Address

structure AddressCriterion (r : LocalGrowthRule) where
  source_is_cut_root :
    r.sourceAddress = SchurDtnDerivedAddressSeed.cutRoot
  target_is_frontier :
    r.targetAddress = SchurDtnDerivedAddressSeed.frontierPortAddress
  rank_increases : GrowthEdgeProvenance.rankIncreases r = true
  target_outside_roles :
    GrowthEdgeProvenance.targetOutsideRoles r = true


theorem source_zero_of_address_criterion {r : LocalGrowthRule}
    (c : AddressCriterion r) :
    GrowthEdgeProvenance.sourceNode r = 0 := by
  unfold GrowthEdgeProvenance.sourceNode GrowthEdgeProvenance.addressNode
  rw [c.source_is_cut_root]
  rfl


theorem target_two_of_address_criterion {r : LocalGrowthRule}
    (c : AddressCriterion r) :
    GrowthEdgeProvenance.targetNode r = 2 := by
  unfold GrowthEdgeProvenance.targetNode GrowthEdgeProvenance.addressNode
  rw [c.target_is_frontier]
  change SchurDtnDerivedAddressSeed.frontierPortNode = 2
  exact SchurDtnDerivedAddressSeed.frontier_port_node_derived


def toNodeCriterion {r : LocalGrowthRule}
    (c : AddressCriterion r) : LocalGrowthEdgeCriterion.Criterion r :=
  { source_zero := source_zero_of_address_criterion c,
    target_two := target_two_of_address_criterion c,
    rank_increases := c.rank_increases,
    target_outside_roles := c.target_outside_roles }


theorem growth_active_of_address_criterion {r : LocalGrowthRule}
    (c : AddressCriterion r) :
    GrowthEdgeProvenance.growthActive r = true :=
  LocalGrowthEdgeCriterion.growth_active_of_criterion
    (toNodeCriterion c)


theorem frontier_edge_forward_of_address_criterion {r : LocalGrowthRule}
    (c : AddressCriterion r) :
    GrowthEdgeProvenance.frontierGrowthEdge r 0 2 = true :=
  LocalGrowthEdgeCriterion.frontier_edge_forward_of_criterion
    (toNodeCriterion c)


theorem frontier_edge_backward_of_address_criterion {r : LocalGrowthRule}
    (c : AddressCriterion r) :
    GrowthEdgeProvenance.frontierGrowthEdge r 2 0 = true :=
  LocalGrowthEdgeCriterion.frontier_edge_backward_of_criterion
    (toNodeCriterion c)


theorem growth_edge_forward_of_address_criterion {r : LocalGrowthRule}
    (c : AddressCriterion r) :
    GrowthEdgeProvenance.growthAdjacent r 0 2 = true :=
  LocalGrowthEdgeCriterion.growth_edge_forward_of_criterion
    (toNodeCriterion c)


theorem growth_edge_backward_of_address_criterion {r : LocalGrowthRule}
    (c : AddressCriterion r) :
    GrowthEdgeProvenance.growthAdjacent r 2 0 = true :=
  LocalGrowthEdgeCriterion.growth_edge_backward_of_criterion
    (toNodeCriterion c)


def activeAddressCriterion :
    AddressCriterion GrowthEdgeProvenance.activeAddressGrowthRule :=
  { source_is_cut_root := rfl,
    target_is_frontier := rfl,
    rank_increases := GrowthEdgeProvenance.active_rule_rank_increases,
    target_outside_roles :=
      GrowthEdgeProvenance.active_rule_target_outside_roles }


theorem active_address_criterion_to_node_criterion :
    toNodeCriterion activeAddressCriterion =
      LocalGrowthEdgeCriterion.activeCriterion := rfl


theorem active_address_criterion_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      GrowthEdgeProvenance.activeAddressGrowthRule 0 2 = true :=
  growth_edge_forward_of_address_criterion activeAddressCriterion


theorem active_address_criterion_backward_edge :
    GrowthEdgeProvenance.growthAdjacent
      GrowthEdgeProvenance.activeAddressGrowthRule 2 0 = true :=
  growth_edge_backward_of_address_criterion activeAddressCriterion


theorem active_address_criterion_recovers_local_growth_edge :
    GrowthEdgeProvenance.localGrowthEdgeDerivedFromAddressRule :=
  And.intro GrowthEdgeProvenance.active_rule_rank_increases
    (And.intro GrowthEdgeProvenance.active_rule_target_outside_roles
      (And.intro active_address_criterion_forward_edge
        active_address_criterion_backward_edge))


theorem active_address_criterion_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  GrowthEdgeProvenance.derived_growth_status


def addressCriterionStillLocalSeed : Prop := True


theorem address_criterion_still_local_seed :
    addressCriterionStillLocalSeed :=
  True.intro

end AddressGrowthEdgeCriterion
