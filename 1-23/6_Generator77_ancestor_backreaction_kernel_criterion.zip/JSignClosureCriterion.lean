import CNNA.JLockingGate

/-
  JSignClosureCriterion.lean
  --------------------------
  Formales Kriterium, wann ein J-Vorzeichen im aktuellen Locking-Gate als
  geschlossen gelten darf.

  Diese Datei schliesst das absolute J-Vorzeichen NICHT allgemein. Sie kapselt
  nur das No-Free-Parameter-Kriterium:

    * Ein eindeutiger kohärenter Lock-Sektor traegt ein geschlossenes Sign.
    * Ein Paar aus plusLock und minusLock traegt kein einzelnes geschlossenes
      Sign.

  Damit wird der Status des J-Problems explizit als Kriterium und nicht als
  heimlicher Tie-Break formuliert.
-/

namespace JSignClosureCriterion

abbrev Sign := JLockingGate.Sign
abbrev LockCandidate := JLockingGate.LockCandidate

/-- Ein Sign `s` schliesst eine gegebene Kandidatenliste, wenn jeder in der
    Liste vorkommende kohärente Kandidat dieses J-Sign traegt. -/
def closesJSign (cs : List LockCandidate) (s : Sign) : Prop :=
  ∀ c, c ∈ cs -> JLockingGate.coherent c -> c.j = s

/-- Eine Kandidatenliste hat ein geschlossenes J-Sign, wenn ein Sign alle
    kohärenten Kandidaten der Liste schliesst. -/
def hasClosedJSign (cs : List LockCandidate) : Prop :=
  ∃ s, closesJSign cs s

/-- Der eindeutige positive Lock-Sektor. -/
def plusSector : List LockCandidate :=
  [JLockingGate.plusLock]

/-- Der symmetrische Zwei-Sektorenfall. -/
def twoSectors : List LockCandidate :=
  [JLockingGate.plusLock, JLockingGate.minusLock]

/-- Im eindeutigen positiven Sektor ist das J-Sign geschlossen. -/
theorem plusSector_has_closed_j_sign : hasClosedJSign plusSector := by
  unfold hasClosedJSign closesJSign plusSector
  exact Exists.intro JLockingGate.Sign.plus (by
    intro c hc _
    simp at hc
    rw [hc]
    rfl)

/-- Im symmetrischen Zwei-Sektorenfall kann kein einzelnes Sign beide
    kohärenten Lock-Kandidaten schliessen. -/
theorem twoSectors_no_closed_j_sign : ¬ hasClosedJSign twoSectors := by
  intro h
  unfold hasClosedJSign closesJSign twoSectors at h
  cases h with
  | intro s hs =>
      have hpMem : JLockingGate.plusLock ∈
          [JLockingGate.plusLock, JLockingGate.minusLock] := by
        simp
      have hmMem : JLockingGate.minusLock ∈
          [JLockingGate.plusLock, JLockingGate.minusLock] := by
        simp
      have hp : JLockingGate.plusLock.j = s :=
        hs JLockingGate.plusLock hpMem JLockingGate.plusLock_coherent
      have hm : JLockingGate.minusLock.j = s :=
        hs JLockingGate.minusLock hmMem JLockingGate.minusLock_coherent
      have hpm : JLockingGate.Sign.plus = JLockingGate.Sign.minus := Eq.trans hp (Eq.symm hm)
      cases hpm

/-- Der eindeutige Miniport-Fall des Generator-Spines liegt im geschlossenen
    positiven Sektor. -/
theorem oneInterior_closed_j_sign :
    OneInteriorGrowthKernelExample.oneInteriorDefectSystem.kernel = 1 ∧
    hasClosedJSign plusSector :=
  And.intro OneInteriorGrowthKernelExample.oneInterior_kernel_one
    plusSector_has_closed_j_sign

/-- Der symmetrische Zwei-Sektorenfall des Generator-Spines bleibt offen im
    Sinn eines absoluten einzelnen J-Signs. -/
theorem symmetric_two_not_closed_j_sign :
    OneInteriorGrowthKernelExample.symmetricTwoDefectSystem.kernel = 2 ∧
    ¬ hasClosedJSign twoSectors :=
  And.intro OneInteriorGrowthKernelExample.symmetricTwo_kernel_two
    twoSectors_no_closed_j_sign

/-- Statusmarker: Das J-Sign ist genau dann geschlossen, wenn die Locking-Daten
    auf eine eindeutige kohärente Sign-Klasse kollabieren. -/
def closureRequiresSingleSignClass : Prop := True

theorem closure_requires_single_sign_class : closureRequiresSingleSignClass :=
  True.intro

end JSignClosureCriterion
