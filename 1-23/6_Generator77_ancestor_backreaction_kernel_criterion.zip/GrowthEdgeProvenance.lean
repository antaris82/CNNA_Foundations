import CNNA.SchurDtnDerivedAddressSeed
import CNNA.ConcreteGrowthIrreversibilityG1Test

namespace GrowthEdgeProvenance

abbrev Node := Fin 3
abbrev Address := SchurDtnDerivedAddressSeed.Address
abbrev Branch := SchurDtnDerivedAddressSeed.Branch
abbrev FiniteCut := FiniteCutCombinatorics.FiniteCut Node
abbrev CertifiedSchurBlocks := DirichletInverseWitness.CertifiedSchurBlocks Node
abbrev SchurSummary := SchurDtnSummary.SchurSummary Node
abbrev DefectSystem := SectorResolutionGate.DefectSystem

structure LocalGrowthRule where
  sourceAddress : Address
  targetAddress : Address
  beforeRank : Nat
  afterRank : Nat


def addressNode : Address -> Node :=
  SchurDtnDerivedAddressSeed.addressNode


def sourceNode (r : LocalGrowthRule) : Node :=
  addressNode r.sourceAddress


def targetNode (r : LocalGrowthRule) : Node :=
  addressNode r.targetAddress


def rankIncreases (r : LocalGrowthRule) : Bool :=
  decide (r.beforeRank < r.afterRank)


def targetOutsideRoles (r : LocalGrowthRule) : Bool :=
  SchurDtnDerivedAddressSeed.outsideRoleAddress r.targetAddress


def growthActive (r : LocalGrowthRule) : Bool :=
  rankIncreases r && targetOutsideRoles r


def baseEdge : Node -> Node -> Bool :=
  ConcreteGrowthIrreversibilityG1Test.edge01


def frontierGrowthEdge (r : LocalGrowthRule) (x y : Node) : Bool :=
  growthActive r &&
    (((x == sourceNode r) && (y == targetNode r)) ||
      ((x == targetNode r) && (y == sourceNode r)))


def growthAdjacent (r : LocalGrowthRule) (x y : Node) : Bool :=
  baseEdge x y || frontierGrowthEdge r x y


def activeAddressGrowthRule : LocalGrowthRule :=
  { sourceAddress := SchurDtnDerivedAddressSeed.cutRoot,
    targetAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    beforeRank := 0,
    afterRank := 1 }


def inactiveAddressGrowthRule : LocalGrowthRule :=
  { sourceAddress := SchurDtnDerivedAddressSeed.cutRoot,
    targetAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    beforeRank := 0,
    afterRank := 0 }


def insideTargetGrowthRule : LocalGrowthRule :=
  { sourceAddress := SchurDtnDerivedAddressSeed.cutRoot,
    targetAddress := SchurDtnDerivedAddressSeed.selectedChild,
    beforeRank := 0,
    afterRank := 1 }


theorem active_rule_source_node_zero :
    sourceNode activeAddressGrowthRule = 0 := rfl


theorem active_rule_target_node_two :
    targetNode activeAddressGrowthRule = 2 := rfl


theorem active_rule_rank_increases :
    rankIncreases activeAddressGrowthRule = true := rfl


theorem active_rule_target_outside_roles :
    targetOutsideRoles activeAddressGrowthRule = true := rfl


theorem active_rule_growth_active :
    growthActive activeAddressGrowthRule = true := rfl


theorem inactive_rule_growth_not_active :
    growthActive inactiveAddressGrowthRule = false := rfl


theorem inside_target_growth_not_active :
    growthActive insideTargetGrowthRule = false := rfl


theorem active_rule_edge_forward :
    growthAdjacent activeAddressGrowthRule 0 2 = true := rfl


theorem active_rule_edge_backward :
    growthAdjacent activeAddressGrowthRule 2 0 = true := rfl


theorem inactive_rule_no_frontier_edge_forward :
    growthAdjacent inactiveAddressGrowthRule 0 2 = false := rfl


theorem inside_target_no_frontier_edge_forward :
    frontierGrowthEdge insideTargetGrowthRule 0 1 = false := rfl


def beforeCut : FiniteCut :=
  { boundary := [addressNode SchurDtnDerivedAddressSeed.cutRoot],
    interior := [addressNode SchurDtnDerivedAddressSeed.selectedChild],
    uvBoundary := [addressNode SchurDtnDerivedAddressSeed.selectedChild],
    envBoundary := [addressNode SchurDtnDerivedAddressSeed.cutRoot],
    recordNodes := [],
    complementNodes := [],
    adjacent := baseEdge }


def afterCut (r : LocalGrowthRule) : FiniteCut :=
  { boundary := [sourceNode r, targetNode r],
    interior := [addressNode SchurDtnDerivedAddressSeed.selectedChild],
    uvBoundary := [addressNode SchurDtnDerivedAddressSeed.selectedChild],
    envBoundary := [addressNode SchurDtnDerivedAddressSeed.cutRoot],
    recordNodes := [],
    complementNodes := [],
    adjacent := growthAdjacent r }


def activeGrowthCut : FiniteCut :=
  afterCut activeAddressGrowthRule


def inactiveGrowthCut : FiniteCut :=
  afterCut inactiveAddressGrowthRule


theorem before_lbb_trace_one :
    FiniteGraphLaplacianBlocks.LBBTrace beforeCut = 1 := rfl


theorem before_coupling_trace_one :
    FiniteGraphLaplacianBlocks.couplingTrace beforeCut = 1 := rfl


theorem before_graph_cut_defect_zero :
    FiniteGraphLaplacianBlocks.graphCutDefect beforeCut = 0 := rfl


theorem inactive_lbb_trace_one :
    FiniteGraphLaplacianBlocks.LBBTrace inactiveGrowthCut = 1 := rfl


theorem inactive_coupling_trace_one :
    FiniteGraphLaplacianBlocks.couplingTrace inactiveGrowthCut = 1 := rfl


theorem inactive_graph_cut_defect_zero :
    FiniteGraphLaplacianBlocks.graphCutDefect inactiveGrowthCut = 0 := rfl


theorem active_lbb_trace_three :
    FiniteGraphLaplacianBlocks.LBBTrace activeGrowthCut = 3 := rfl


theorem active_coupling_trace_one :
    FiniteGraphLaplacianBlocks.couplingTrace activeGrowthCut = 1 := rfl


theorem active_graph_cut_defect_zero :
    FiniteGraphLaplacianBlocks.graphCutDefect activeGrowthCut = 0 := rfl


def certifiedBlocks (c : FiniteCut) : CertifiedSchurBlocks :=
  ConcreteMatrixArithmetic.certifiedOne1Blocks c
    c.boundary.length
    (FiniteGraphLaplacianBlocks.LBBTrace c)
    (FiniteGraphLaplacianBlocks.couplingTrace c)
    (FiniteGraphLaplacianBlocks.graphCutDefect c)


def beforeBlocks : CertifiedSchurBlocks :=
  certifiedBlocks beforeCut


def inactiveGrowthBlocks : CertifiedSchurBlocks :=
  certifiedBlocks inactiveGrowthCut


def activeGrowthBlocks : CertifiedSchurBlocks :=
  certifiedBlocks activeGrowthCut


theorem before_schur_trace_zero :
    FiniteMatrixSchurPort.schurTrace
      (DirichletInverseWitness.toInvertibleSchurBlocks beforeBlocks) = 0 := rfl


theorem inactive_schur_trace_zero :
    FiniteMatrixSchurPort.schurTrace
      (DirichletInverseWitness.toInvertibleSchurBlocks
        inactiveGrowthBlocks) = 0 := rfl


theorem active_schur_trace_two :
    FiniteMatrixSchurPort.schurTrace
      (DirichletInverseWitness.toInvertibleSchurBlocks
        activeGrowthBlocks) = 2 := rfl


theorem active_schur_trace_matches_generator58 :
    FiniteMatrixSchurPort.schurTrace
      (DirichletInverseWitness.toInvertibleSchurBlocks
        activeGrowthBlocks) =
    FiniteMatrixSchurPort.schurTrace
      (DirichletInverseWitness.toInvertibleSchurBlocks
        ConcreteGrowthIrreversibilityG1Test.boundaryFrontierGrowthBlocks) := by
  rw [active_schur_trace_two,
    ConcreteGrowthIrreversibilityG1Test.boundary_frontier_concrete_schur_trace_two]


def beforeSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary beforeBlocks


def inactiveGrowthSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary inactiveGrowthBlocks


def activeGrowthSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary activeGrowthBlocks


def derivedGrowthDefectSystem : DefectSystem Bool :=
  SchurStrictPreferenceBridge.schurCutHandoffDefectSystem
    beforeSummary inactiveGrowthSummary activeGrowthSummary


theorem derived_growth_false_defect_zero :
    derivedGrowthDefectSystem.defect false = [0, 0, 0, 0, 0] := rfl


theorem derived_growth_true_defect_dtn_two :
    derivedGrowthDefectSystem.defect true = [0, 2, 0, 0, 0] := rfl


theorem derived_growth_minSet_singleton :
    derivedGrowthDefectSystem.minSet = [false] := rfl


theorem derived_growth_kernel_one :
    derivedGrowthDefectSystem.kernel = 1 :=
  CanonicalGrowthKernel.DefectSystem.unique_kernel_one
    derivedGrowthDefectSystem false derived_growth_minSet_singleton


def derivedGrowthSchurStrictPreference :
    SchurStrictPreferenceBridge.SchurStrictPreference
      beforeSummary inactiveGrowthSummary activeGrowthSummary :=
  { minSet_singleton := derived_growth_minSet_singleton }


theorem derived_growth_resolved_j_sign :
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      derivedGrowthDefectSystem :=
  SchurStrictPreferenceBridge.resolved_of_schur_strict_preference
    beforeSummary inactiveGrowthSummary activeGrowthSummary
    derivedGrowthSchurStrictPreference


theorem derived_growth_locks_eq_plusSector :
    SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      derivedGrowthDefectSystem = JSignClosureCriterion.plusSector := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    SchurStrictPreferenceBridge.schurSectorMap
    CutStrictPreferenceBridge.cutSectorMap
    HandoffStrictPreferenceBridge.handoffSectorMap
    GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.plusSector
  rw [derived_growth_minSet_singleton]
  rfl


theorem derived_growth_not_flip_closed :
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        derivedGrowthDefectSystem) := by
  intro hclosed
  rw [derived_growth_locks_eq_plusSector] at hclosed
  exact SymmetryBreakingClosureGate.plusSector_not_closed_under_flip hclosed


theorem derived_growth_status :
    derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        derivedGrowthDefectSystem) :=
  And.intro derived_growth_kernel_one
    (And.intro derived_growth_resolved_j_sign derived_growth_not_flip_closed)


def inactiveControlDefectSystem : DefectSystem Bool :=
  SchurStrictPreferenceBridge.schurCutHandoffDefectSystem
    beforeSummary inactiveGrowthSummary inactiveGrowthSummary


theorem inactive_control_false_defect_zero :
    inactiveControlDefectSystem.defect false = [0, 0, 0, 0, 0] := rfl


theorem inactive_control_true_defect_zero :
    inactiveControlDefectSystem.defect true = [0, 0, 0, 0, 0] := rfl


theorem inactive_control_minSet_pair :
    inactiveControlDefectSystem.minSet = [false, true] := rfl


theorem inactive_control_kernel_two :
    inactiveControlDefectSystem.kernel = 2 :=
  CanonicalGrowthKernel.DefectSystem.two_sector_kernel
    inactiveControlDefectSystem false true inactive_control_minSet_pair


theorem inactive_control_locks_eq_twoSectors :
    SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      inactiveControlDefectSystem = JSignClosureCriterion.twoSectors := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    SchurStrictPreferenceBridge.schurSectorMap
    CutStrictPreferenceBridge.cutSectorMap
    HandoffStrictPreferenceBridge.handoffSectorMap
    GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.twoSectors
  rw [inactive_control_minSet_pair]
  rfl


theorem inactive_control_not_resolved_j_sign :
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      inactiveControlDefectSystem := by
  change ¬ JSignClosureCriterion.hasClosedJSign
    (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      inactiveControlDefectSystem)
  rw [inactive_control_locks_eq_twoSectors]
  exact JSignClosureCriterion.twoSectors_no_closed_j_sign


theorem inactive_control_status :
    inactiveControlDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      inactiveControlDefectSystem :=
  And.intro inactive_control_kernel_two inactive_control_not_resolved_j_sign


def localGrowthEdgeDerivedFromAddressRule : Prop :=
  rankIncreases activeAddressGrowthRule = true ∧
    targetOutsideRoles activeAddressGrowthRule = true ∧
    growthAdjacent activeAddressGrowthRule 0 2 = true ∧
    growthAdjacent activeAddressGrowthRule 2 0 = true


theorem local_growth_edge_derived_from_address_rule :
    localGrowthEdgeDerivedFromAddressRule :=
  And.intro active_rule_rank_increases
    (And.intro active_rule_target_outside_roles
      (And.intro active_rule_edge_forward active_rule_edge_backward))

end GrowthEdgeProvenance
