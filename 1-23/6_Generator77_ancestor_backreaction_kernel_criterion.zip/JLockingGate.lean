import CNNA.GrowthToCirculationBridge

/-
  JLockingGate.lean
  -----------------
  Erstes formales Locking-Gate nach der grünen Bridge
  Growth -> Zirkulationszeuge.

  Diese Datei beweist bewusst nicht das absolute J-Vorzeichen.
  Sie trennt zwei Aussagen:

  1. Ein eindeutiger Growth-Sektor kann mit einem kohärenten Lock-Kandidaten
     verbunden werden.
  2. Ein symmetrischer Zwei-Sektoren-Fall bleibt ein Paar entgegengesetzter
     Lock-Kandidaten; daraus folgt kein globaler einzelner J-Sign.

  Das ist der gewuenschte No-Free-Parameter-Status: kein Tie-Break,
  keine freie Orientierung, kein versteckter Zufall.
-/

namespace JLockingGate

inductive Sign where
  | plus
  | minus
  deriving DecidableEq

/-- Formaler Vorzeichenflip. -/
def flip : Sign -> Sign
  | Sign.plus => Sign.minus
  | Sign.minus => Sign.plus

theorem flip_involutive (s : Sign) : flip (flip s) = s := by
  cases s <;> rfl

/-- Ein Lock-Kandidat besteht aus einem J-Sign, einem F2-Sign und einem
    Zeit- oder Provenienzpfeil-Sign. -/
structure LockCandidate where
  j : Sign
  f2 : Sign
  tau : Sign

/-- Ein kohärenter Lock verlangt, dass J, F2 und tau nicht unabhängig
    gesetzt werden, sondern zusammenfallen. -/
def coherent (c : LockCandidate) : Prop :=
  c.j = c.f2 ∧ c.f2 = c.tau

/-- Positiver Lock-Kandidat. -/
def plusLock : LockCandidate :=
  { j := Sign.plus, f2 := Sign.plus, tau := Sign.plus }

/-- Negativer Lock-Kandidat. -/
def minusLock : LockCandidate :=
  { j := Sign.minus, f2 := Sign.minus, tau := Sign.minus }

theorem plusLock_coherent : coherent plusLock := by
  unfold coherent plusLock
  exact And.intro rfl rfl

theorem minusLock_coherent : coherent minusLock := by
  unfold coherent minusLock
  exact And.intro rfl rfl

theorem plusLock_j_ne_minusLock_j : plusLock.j ≠ minusLock.j := by
  decide

/-- Ein eindeutiger Miniport-Growth-Kernel kann an einen positiven
    Lock-Kandidaten gekoppelt werden. Das ist noch kein absoluter J-Beweis,
    sondern nur der eindeutige Sektorfall. -/
theorem oneInterior_kernel_and_plus_lock :
    OneInteriorGrowthKernelExample.oneInteriorDefectSystem.kernel = 1 ∧
    coherent plusLock :=
  And.intro OneInteriorGrowthKernelExample.oneInterior_kernel_one
    plusLock_coherent

/-- Der symmetrische Zwei-Sektoren-Kernel traegt beide kohärenten
    Lock-Kandidaten. Es gibt keinen kanonischen Tie-Break zwischen ihnen. -/
theorem symmetric_two_kernel_and_two_locks :
    OneInteriorGrowthKernelExample.symmetricTwoDefectSystem.kernel = 2 ∧
    coherent plusLock ∧ coherent minusLock ∧ plusLock.j ≠ minusLock.j :=
  And.intro OneInteriorGrowthKernelExample.symmetricTwo_kernel_two
    (And.intro plusLock_coherent
      (And.intro minusLock_coherent plusLock_j_ne_minusLock_j))

/-- Wenn beide Lock-Sektoren als zulässig betrachtet werden, gibt es kein
    globales einzelnes J-Vorzeichen, das alle kohärenten Lock-Kandidaten
    erzwingt. -/
theorem no_absolute_lock_over_both_sectors :
    ¬ ∃ s : Sign, ∀ c : LockCandidate, coherent c -> c.j = s := by
  intro h
  cases h with
  | intro s hs =>
      have hp : Sign.plus = s := hs plusLock plusLock_coherent
      have hm : Sign.minus = s := hs minusLock minusLock_coherent
      have hpm : Sign.plus = Sign.minus := Eq.trans hp (Eq.symm hm)
      cases hpm

/-- Die gruene Bridge liefert im Zwei-Sektorenfall entgegengesetzte
    Zirkulationszeichen; dieses Gate koppelt das an den No-Go fuer ein
    globales einzelnes J-Vorzeichen. -/
theorem symmetric_two_circulation_pair_and_no_absolute_lock :
    OneInteriorGrowthKernelExample.symmetricTwoDefectSystem.kernel = 2 ∧
    Circulation.csum Circulation.cmpH
      (GrowthToCirculationBridge.symmetricSectorEdges false) = 1 ∧
    Circulation.csum Circulation.cmpH
      (GrowthToCirculationBridge.symmetricSectorEdges true) = -1 ∧
    ¬ ∃ s : Sign, ∀ c : LockCandidate, coherent c -> c.j = s :=
  And.intro OneInteriorGrowthKernelExample.symmetricTwo_kernel_two
    (And.intro GrowthToCirculationBridge.symmetric_false_circulation
      (And.intro GrowthToCirculationBridge.symmetric_true_circulation
        no_absolute_lock_over_both_sectors))

/-- Marker: Das Locking-Gate ist gebaut, aber das absolute J-Vorzeichen ist
    nur im eindeutigen Sektorfall representierbar. Im symmetrischen Fall ist
    die korrekte kanonische Antwort weiterhin ein Paar. -/
def jSignClosedOnlyForUniqueSector : Prop := True

theorem j_sign_closed_only_for_unique_sector :
    jSignClosedOnlyForUniqueSector :=
  True.intro

end JLockingGate
