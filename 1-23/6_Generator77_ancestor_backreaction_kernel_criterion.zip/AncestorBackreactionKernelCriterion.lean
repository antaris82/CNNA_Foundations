namespace AncestorBackreactionKernelCriterion

structure KernelScalingRecord where
  name : String
  branch : Nat
  controlsRegisteredRemoteShells : Bool
  hasPolynomialExtraDamping : Bool
  intendedForTowerExtrapolation : Bool
deriving DecidableEq, Repr

def registeredBranch : Nat := 3

def registeredLevels : List Nat := [1, 2, 3, 4, 5, 6, 7, 8]

def remoteShellGrowth (branch level : Nat) : Nat :=
  branch ^ (level - 1)

def inverseSquareDenominator (level : Nat) : Nat :=
  level * level

def criticalExponentialDenominator (branch level : Nat) : Nat :=
  branch ^ (level - 1)

def expQuarterDenominator (level : Nat) : Nat :=
  4 ^ (level - 1)

def shellNormInverseSquareDenominator (branch level : Nat) : Nat :=
  branch ^ (level - 1) * (level * level)

def shellControlledAt (denominator : Nat → Nat) (level : Nat) : Bool :=
  decide (remoteShellGrowth registeredBranch level ≤ denominator level)

def controlProfile (denominator : Nat → Nat) : List Bool :=
  registeredLevels.map (fun level => shellControlledAt denominator level)

def extraDampingProfile (denominator : Nat → Nat) : List Nat :=
  registeredLevels.map
    (fun level => denominator level / remoteShellGrowth registeredBranch level)

def inverseSquareControlProfile : List Bool :=
  controlProfile inverseSquareDenominator

def criticalExpControlProfile : List Bool :=
  controlProfile (criticalExponentialDenominator registeredBranch)

def expQuarterControlProfile : List Bool :=
  controlProfile expQuarterDenominator

def shellNormInverseSquareControlProfile : List Bool :=
  controlProfile (shellNormInverseSquareDenominator registeredBranch)

def criticalExpExtraDampingProfile : List Nat :=
  extraDampingProfile (criticalExponentialDenominator registeredBranch)

def shellNormInverseSquareExtraDampingProfile : List Nat :=
  extraDampingProfile (shellNormInverseSquareDenominator registeredBranch)

def inverseSquareKernelRecord : KernelScalingRecord :=
  { name := "inverse_square"
    branch := registeredBranch
    controlsRegisteredRemoteShells := false
    hasPolynomialExtraDamping := false
    intendedForTowerExtrapolation := false }

def criticalExpKernelRecord : KernelScalingRecord :=
  { name := "critical_exp_1over3"
    branch := registeredBranch
    controlsRegisteredRemoteShells := true
    hasPolynomialExtraDamping := false
    intendedForTowerExtrapolation := false }

def expQuarterKernelRecord : KernelScalingRecord :=
  { name := "exp_0p25"
    branch := registeredBranch
    controlsRegisteredRemoteShells := true
    hasPolynomialExtraDamping := false
    intendedForTowerExtrapolation := true }

def shellNormInverseSquareKernelRecord : KernelScalingRecord :=
  { name := "shell_norm_inverse_square"
    branch := registeredBranch
    controlsRegisteredRemoteShells := true
    hasPolynomialExtraDamping := true
    intendedForTowerExtrapolation := true }

def candidateTowerKernelRecords : List KernelScalingRecord :=
  [criticalExpKernelRecord, expQuarterKernelRecord,
   shellNormInverseSquareKernelRecord]

theorem inverse_square_control_profile_register :
    inverseSquareControlProfile =
      [true, true, true, false, false, false, false, false] := by
  decide

theorem inverse_square_fails_shell_control_at_level_four :
    shellControlledAt inverseSquareDenominator 4 = false := by
  decide

theorem critical_exp_controls_registered_shells :
    criticalExpControlProfile =
      [true, true, true, true, true, true, true, true] := by
  decide

theorem exp_quarter_controls_registered_shells :
    expQuarterControlProfile =
      [true, true, true, true, true, true, true, true] := by
  decide

theorem shell_norm_inverse_square_controls_registered_shells :
    shellNormInverseSquareControlProfile =
      [true, true, true, true, true, true, true, true] := by
  decide

theorem critical_exp_has_no_extra_polynomial_damping :
    criticalExpExtraDampingProfile = [1, 1, 1, 1, 1, 1, 1, 1] := by
  decide

theorem shell_norm_inverse_square_extra_damping_profile :
    shellNormInverseSquareExtraDampingProfile = [1, 4, 9, 16, 25, 36, 49, 64] := by
  decide

theorem inverse_square_not_intended_for_tower_extrapolation :
    inverseSquareKernelRecord.intendedForTowerExtrapolation = false := by
  decide

theorem shell_norm_inverse_square_is_tower_candidate :
    shellNormInverseSquareKernelRecord.intendedForTowerExtrapolation = true ∧
    shellNormInverseSquareKernelRecord.controlsRegisteredRemoteShells = true ∧
    shellNormInverseSquareKernelRecord.hasPolynomialExtraDamping = true := by
  decide

def ancestorKernelStillResponseCriterion : Prop := True

theorem ancestor_kernel_still_response_criterion :
    ancestorKernelStillResponseCriterion :=
  trivial

def kernelCriterionStillPreOperatorTower : Prop := True

theorem kernel_criterion_still_pre_operator_tower :
    kernelCriterionStillPreOperatorTower :=
  trivial

end AncestorBackreactionKernelCriterion
