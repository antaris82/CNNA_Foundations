# SUMMARY

Test package: `test_cqnm_non_shelling_provenance_face_pairing_gate.py`

## What was tested

The test audits the allowed growth moves rather than merely rerunning larger levels. It starts from the current inward-root/outward-NGF complex generated from Script-1/2-style provenance growth and then enumerates possible closure moves:

- `shelling_disk_move`: one tetrahedron attached to one boundary face.
- `cap_move`: local multi-face cap/filling move.
- `handle_candidate`: non-shelling bridge between two separated boundary faces using a triangular-prism-like 3-tet bridge.
- `quotient_candidate`: orientation-reversing identification of two separated boundary faces.
- `illegal`: rejected by occupancy/dependency/quotient degeneracy checks.

## Main run: real_growth, L=3

Base topology:

```json
{
  "vertices": 40,
  "edges": 114,
  "faces": 112,
  "tets": 37,
  "euler": 1,
  "beta0": 1,
  "beta1": 0,
  "beta2": 0,
  "beta3": 0,
  "boundary_faces": 76,
  "saturated_faces": 36,
  "overfull_faces": 0,
  "boundary_fraction": 0.6785714285714225,
  "saturated_fraction": 0.32142857142856857,
  "manifold_face_fraction": 0.9999999999999911
}
```

Base operator/exactness diagnostic:

```json
{
  "K_mean": 0.9095255451534915,
  "K_p95": 2.6180612220504247,
  "closed_ratio": 0.4688740304791123,
  "exact_residual_ratio": 0.26722530405981093,
  "harmonic_ratio": 0.0
}
```

Candidate counts:

```json
{
  "cap_move": 30,
  "illegal": 123,
  "shelling_disk_move": 88,
  "quotient_candidate": 218,
  "handle_candidate": 188
}
```

Best handle candidate:

```json
{
  "candidate_id": 151,
  "move_class": "handle_candidate",
  "status": "ok",
  "response_score": 8.8967002185004,
  "response_rank_legal": 3,
  "face_a": "3 4 7",
  "face_b": "8 10 11",
  "attach_components": 2,
  "delta_beta1": 0,
  "delta_beta2": 1,
  "delta_boundary_faces": 2,
  "new_beta1": 0,
  "new_beta2": 1,
  "new_boundary_fraction": 0.6554621848739441,
  "K_pair_norm": 6.022329665366499,
  "directed_coupling": 0.8215530711006684,
  "directed_imbalance": 0.3772953915118258,
  "transverse_complementarity": 0.2891184979677439,
  "address_similarity": 0.4,
  "radial_shell_match": 0.698274174616505,
  "centroid_distance": 1.0275739885861783
}
```

Best quotient candidate:

```json
{
  "candidate_id": 148,
  "move_class": "quotient_candidate",
  "status": "ok",
  "response_score": 9.552116678038697,
  "response_rank_legal": 1,
  "face_a": "3 8 11",
  "face_b": "12 34 37 perm=(0, 2, 1)",
  "attach_components": 2,
  "delta_beta1": 0,
  "delta_beta2": 0,
  "delta_boundary_faces": -8,
  "new_beta1": 0,
  "new_beta2": 0,
  "new_boundary_fraction": 0.6799999999999933,
  "K_pair_norm": 5.346941363662439,
  "directed_coupling": 1.1171072953608603,
  "directed_imbalance": 0.4865504659733609,
  "transverse_complementarity": 1.1643257325440397,
  "address_similarity": 0.4,
  "radial_shell_match": 0.49862964638463186,
  "centroid_distance": 1.052037775579619
}
```

## Short conclusion

The current base growth is still ball-like: beta1=beta2=0. But the boundary already contains many non-shelling candidates. In the real-growth run, the best quotient candidate is response-rank 1 and the best handle candidate is response-rank 3. The best handle candidate would produce delta_beta2=1 in this audit model.

This means the current failure is not that no local K exists and not that no non-shelling boundary opportunities exist. The failure is that the growth law never applies a complementary boundary-pairing/handle move.

## Important control warning

The symmetrized and no-backreaction controls also produce top-ranked non-shelling candidates. Therefore this package does not prove that the non-shelling move is already CNNA-derived from response/backreaction. It proves a more precise negative/diagnostic statement: the present growth operation is too poor. A separate rule is needed to decide when a candidate non-shelling move is genuinely forced by provenance rather than merely available combinatorially.
