# SUMMARY — birth-phase antisymmetric operator regression gate

This package tests the implementation-level objection that the existing vertex operator encodes the ternary birth phase in a symmetric metric channel and then returns `sym(M)`.  The target is not a J derivation.  The target is a falsifiable operator regression:

```text
legacy_sym_metric
  M = metric terms using q⊗q and h⊗h, then sym(M)

legacy_raw_metric_no_final_sym
  same metric terms, no final sym(M)

antisym_birth_transport
  same metric terms plus a real birth-order-derived antisymmetric transport term
  η · s · (q⊗h - h⊗q)

antisym_then_sym_control
  antisymmetric term inserted but immediately symmetrized away
```

| variant | mode | beta | Hdim | K total | harmonic axial | kappa birth | mirror signed sum | Δ vs legacy | used Δβ? |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| real_growth_live | legacy_sym_metric | (1,0,2,0) | 2 | 2.3416 | 1.67224e-16 | 0.221532 | 5.10665e-05 | 0 | False |
| real_growth_live | legacy_raw_metric_no_final_sym | (1,0,2,0) | 2 | 2.3416 | 1.67224e-16 | 0.221532 | 5.10665e-05 | 0 | False |
| real_growth_live | antisym_birth_transport | (1,0,2,0) | 2 | 2.94275 | 1.50776e-16 | 0.208862 | 2.15422e-05 | 0.52855 | False |
| real_growth_live | antisym_then_sym_control | (1,0,2,0) | 2 | 2.3416 | 1.68858e-16 | 0.205395 | 4.98284e-05 | 1.00392e-16 | False |
| strict_symmetrized_control | legacy_sym_metric | (1,0,0,0) | 0 | 0.155088 | 0 | 0 | 0 | 0 | False |
| strict_symmetrized_control | legacy_raw_metric_no_final_sym | (1,0,0,0) | 0 | 0.155088 | 0 | 0 | 0 | 0 | False |
| strict_symmetrized_control | antisym_birth_transport | (1,0,0,0) | 0 | 0.138871 | 0 | 0 | 0 | 0.138945 | False |
| strict_symmetrized_control | antisym_then_sym_control | (1,0,0,0) | 0 | 0.155088 | 0 | 0 | 0 | 4.64494e-16 | False |
| no_backreaction_live | legacy_sym_metric | (1,0,2,0) | 2 | 1.87751 | 1.59061e-16 | 0.0215526 | 5.30985e-07 | 0 | False |
| no_backreaction_live | legacy_raw_metric_no_final_sym | (1,0,2,0) | 2 | 1.87751 | 1.59061e-16 | 0.0215526 | 5.30985e-07 | 0 | False |
| no_backreaction_live | antisym_birth_transport | (1,0,2,0) | 2 | 2.34763 | 1.72005e-16 | 0.408453 | 5.4758e-05 | 0.532832 | False |
| no_backreaction_live | antisym_then_sym_control | (1,0,2,0) | 2 | 1.87751 | 1.70813e-16 | 0.00486972 | 2.70662e-07 | 1.68463e-16 | False |

Conservative reading: a positive result is only meaningful if the antisymmetric birth-transport mode differs from legacy, while strict symmetrization remains zero or trivial.  The antisymmetric term is not a complex structure; it is a real directed transport diagnostic derived from birth order.


## Next test after this run

Because the antisymmetric birth-transport branch changes the total axial field but still projects to an approximately zero harmonic axial ratio, the next test should not assume operator closure yet.  The next falsification/localization gate is:

```text
test_directed_transport_harmonic_obstruction_localization_gate.py
```

Goal: separate whether the harmonic cancellation is caused by (1) the commutator definition `skew([A_ab,A_bc])`, (2) the H² carrier/cap geometry, (3) face-normal/birth-normal projection, or (4) global exact/coboundary cancellation of a locally directed transport field.
